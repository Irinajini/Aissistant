# BoltFire AI — V1 Offline

Prototype Android d'un copilote visuel local.

## Fonction prévue

- observation périodique de l'écran via MediaProjection ;
- analyse locale hors ligne ;
- overlay visuel non interactif ;
- recommandations contextuelles ;
- fréquence d'analyse configurable dans les prochaines versions.

## Limite importante

Cette V1 ne contient aucun mécanisme d'injection de clics, de gestes, de touches,
d'actions Accessibility ou de contrôle automatique d'un jeu tiers.

## Build avec GitHub Actions

1. Crée un dépôt GitHub.
2. Envoie le contenu de ce projet sur la branche `main`.
3. Ouvre **Actions**.
4. Lance **Build BoltFire AI**.
5. Récupère l'APK dans **Artifacts → BoltFire-AI-debug**.

Le workflow utilise Java 17 et Gradle 8.7.
