package com.boltfire.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * V1 scaffold for offline screen observation.
 *
 * This service intentionally does NOT inject taps, swipes, key events,
 * accessibility actions, or game controls into another application.
 * The future vision pipeline can consume periodic frames and render
 * non-interactive recommendations in an overlay.
 */
class ScreenAnalysisService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            "analysis",
            "BoltFire AI",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = Notification.Builder(this, "analysis")
            .setContentTitle("BoltFire AI")
            .setContentText("Observation locale active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()

        startForeground(7, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // ScreenCapture/MediaProjection and the local model pipeline are
        // intentionally left as the next implementation step.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
