# BoltFire AI V7

Assistant Android hors ligne pour observation d'écran.

## V7
- Overlay compact et déplaçable par son en-tête.
- Bouton Pause/Reprendre pour désactiver l'analyse sans arrêter la capture.
- Masquer retire réellement la vue d'overlay ; la notification permet de la réafficher.
- Arrêter supprime l'overlay et libère MediaProjection/ImageReader/VirtualDisplay.
- Notification persistante avec action « Arrêter BoltFire ».
- Analyse adaptative : environ 2 échantillons/s au lieu de traiter chaque frame comme une analyse complète.
- Le compteur affiche les échantillons réellement analysés, pas toutes les images reçues.
- Détection légère de signaux rouges/orangés fortement contrastés dans la scène.
- Marqueurs graphiques non tactiles directement aux coordonnées détectées.
- Indication directionnelle simple : GAUCHE / CENTRE / DROITE + HAUT / MILIEU / BAS.
- Le marqueur est une indication visuelle à vérifier, pas une reconnaissance fiable d'ennemi.

## Limite importante
Cette V7 ne contient toujours pas de modèle de vision entraîné capable d'identifier de façon fiable ennemis, armes, coffres, zone ou boutons de Free Fire. Les indications visuelles sont donc heuristiques et ne doivent pas être présentées comme une reconnaissance d'objets.

## Lancement
1. Autoriser l'affichage par-dessus les autres applications.
2. Appuyer sur Démarrer.
3. Autoriser la capture de l'écran.
4. Ouvrir Free Fire.
5. Utiliser l'en-tête pour déplacer le panneau, Pause pour suspendre l'analyse, Masquer pour le cacher, ou Arrêter pour terminer BoltFire.
