# HTML Images vers PDF v4

Application statique compatible GitHub Pages.

## Formats de pages détectés
- .html
- .htm
- .xhtml
- .mht
- .mhtml

Sur Android, les fichiers MHT/MHTML peuvent être affichés comme « Fichier BIN » par le sélecteur de fichiers. L'application les détecte d'après leur extension et les traite comme des pages Web.

## Fonctionnement
- 1 fichier ou dossier complet
- inspection récursive des sous-dossiers via le sélecteur de dossier
- extraction des images des pages HTML
- extraction des images intégrées dans MHT/MHTML
- 1 PDF par page
- classement et renommage automatiques
- vérification Internet optionnelle pour les images HTTP/HTTPS
