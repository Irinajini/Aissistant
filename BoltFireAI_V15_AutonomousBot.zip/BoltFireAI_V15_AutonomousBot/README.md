# BoltFire AI V15 — Autonomous Bot

Prototype Android de bot autonome destiné à un jeu hors ligne à commandes tactiles de type battle royale.

## Principe

`capture écran -> détection -> direction -> geste automatique`

V15 peut exécuter automatiquement des swipes de caméra, des appuis sur le bouton de tir calibré et de courts déplacements au joystick.

## Installation et activation

1. Installe l'APK construit par GitHub Actions.
2. Ouvre BoltFire et autorise l'overlay.
3. Active **BoltFire AI V15** dans les paramètres Android **Accessibilité**.
4. Lance BoltFire et autorise la capture écran.
5. Ouvre ton jeu hors ligne.
6. Dans la bulle `BF15`, choisis `Map` et calibre le centre puis le bord de la mini-carte.
7. Choisis `HUD` et touche successivement: joystick, tir, accroupi, saut, gloo.
8. Avec le jeu toujours au premier plan, ouvre la bulle et touche `BIND`.
9. Active `AUTO ON`.

## Sécurité d'exécution

BoltFire mémorise le package de l'application présente au premier plan au moment de `BIND`. Les gestes automatiques sont refusés dès qu'une autre application passe au premier plan.

## Comportement AUTO

- cible visible hors centre: swipe caméra automatique
- cible visible centrée: appui automatique sur TIR
- menace mini-carte sans cible visible: rotation automatique vers la menace
- aucune menace: courte poussée du joystick vers l'avant pour rechercher

## Limite importante

La détection actuelle n'est pas encore un vrai détecteur neuronal de personnages. Elle repose encore sur les signaux visuels heuristiques hérités des versions précédentes. V15 rend l'exécution automatique, mais une future version devra remplacer cette perception par un modèle de vision entraîné pour obtenir un bot réellement fiable.

## Build

Le workflow `.github/workflows/build.yml` compile `app-debug.apk` avec Java 17, Gradle 8.7 et Android Gradle Plugin 8.6.1.
