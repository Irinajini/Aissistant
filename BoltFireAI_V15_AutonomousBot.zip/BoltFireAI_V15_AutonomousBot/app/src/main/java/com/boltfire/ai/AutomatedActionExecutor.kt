package com.boltfire.ai

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Executes calibrated gestures only while the explicitly bound target app is
 * the foreground application. This keeps BoltFire from touching Settings,
 * the launcher, or unrelated apps.
 */
class AutomatedActionExecutor(private val context: Context) {

    companion object {
        private const val PREFS = "boltfire_autobot"
        private const val TARGET_PACKAGE = "target_package"
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val controlPrefs = context.getSharedPreferences("boltfire_control_layout", Context.MODE_PRIVATE)

    private var lastRotateAt = 0L
    private var lastFireAt = 0L
    private var lastMoveAt = 0L

    fun bindForegroundTarget(): String? {
        val pkg = BotAccessibilityService.currentForegroundPackage()
            ?.takeIf { it != context.packageName && it.isNotBlank() }
            ?: return null
        prefs.edit().putString(TARGET_PACKAGE, pkg).apply()
        return pkg
    }

    fun targetPackage(): String? = prefs.getString(TARGET_PACKAGE, null)

    fun isReady(): Boolean {
        val target = targetPackage() ?: return false
        return BotAccessibilityService.isConnected() &&
            BotAccessibilityService.currentForegroundPackage() == target
    }

    fun rotate(dx: Float, dy: Float): Boolean {
        if (!isReady()) return false
        val now = SystemClock.uptimeMillis()
        if (now - lastRotateAt < 155L) return false
        lastRotateAt = now

        val mag = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val nx = (dx / mag).coerceIn(-1f, 1f)
        val ny = (dy / mag).coerceIn(-0.70f, 0.70f)

        // Camera gesture zone: intentionally away from the calibrated fire button.
        val sx = 0.68f
        val sy = 0.50f
        val amplitude = (0.075f + 0.11f * mag.coerceIn(0f, 1f))
        val ex = (sx + nx * amplitude).coerceIn(0.48f, 0.93f)
        val ey = (sy + ny * amplitude * 0.80f).coerceIn(0.24f, 0.78f)
        return BotAccessibilityService.swipeNormalized(sx, sy, ex, ey, 105L)
    }

    fun fire(): Boolean {
        if (!isReady()) return false
        val now = SystemClock.uptimeMillis()
        if (now - lastFireAt < 235L) return false
        lastFireAt = now
        val x = controlPrefs.getFloat("fire_x", 0.90f)
        val y = controlPrefs.getFloat("fire_y", 0.58f)
        return BotAccessibilityService.tapNormalized(x, y, 48L)
    }

    fun move(dx: Float, dy: Float, durationMs: Long = 520L): Boolean {
        if (!isReady()) return false
        val now = SystemClock.uptimeMillis()
        if (now - lastMoveAt < 700L) return false
        lastMoveAt = now

        val jx = controlPrefs.getFloat("joy_x", 0.15f)
        val jy = controlPrefs.getFloat("joy_y", 0.74f)
        val mag = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val nx = (dx / mag).coerceIn(-1f, 1f)
        val ny = (dy / mag).coerceIn(-1f, 1f)
        val radius = 0.065f
        return BotAccessibilityService.swipeNormalized(
            jx,
            jy,
            (jx + nx * radius).coerceIn(0.03f, 0.34f),
            (jy + ny * radius).coerceIn(0.48f, 0.95f),
            durationMs
        )
    }

    fun step(primaryX: Float?, primaryY: Float?, mapDx: Float?, mapDy: Float?): String {
        if (!isReady()) return "WAIT"

        if (primaryX != null && primaryY != null) {
            val dx = ((primaryX - 0.5f) * 2f).coerceIn(-1f, 1f)
            val dy = ((primaryY - 0.52f) * 2f).coerceIn(-1f, 1f)
            val aligned = abs(primaryX - 0.5f) <= 0.085f && abs(primaryY - 0.52f) <= 0.17f
            return if (aligned) {
                if (fire()) "FIRE" else "TRACK"
            } else {
                if (rotate(dx, dy)) "ROTATE" else "TRACK"
            }
        }

        if (mapDx != null && mapDy != null) {
            return if (rotate(mapDx, mapDy)) "ROTATE_MAP" else "TRACK_MAP"
        }

        // Search movement: brief forward push, then release. It is throttled.
        return if (move(0f, -1f, 420L)) "SEARCH" else "OBSERVE"
    }
}
