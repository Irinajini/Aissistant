# BoltFire AI V10 – Map + Touch Guide

Cette version ajoute un guide visuel plus explicite :
- surbrillance des zones correspondant aux touches de tir/visée/saut/accroupi/déplacement ;
- flèche directement au niveau du joystick indiquant la direction de déplacement ;
- lecture heuristique de la mini-carte (zone en haut à gauche) pour produire une direction et un niveau de déplacement ;
- indication « MAPA → ... » ;
- conservation du pipeline de capture locale et de l'échantillonnage limité.

Limite importante : l'analyse de mini-carte est heuristique. Elle ne constitue pas encore un modèle de vision capable de comprendre sémantiquement toute la carte ou de reconnaître une destination précise. Les indications doivent donc être vérifiées à l'écran.

Le projet n'a pas pu être compilé dans cet environnement car aucun Gradle/Gradle Wrapper n'est installé. Le workflow GitHub Actions reste le moyen de compiler l'APK.
