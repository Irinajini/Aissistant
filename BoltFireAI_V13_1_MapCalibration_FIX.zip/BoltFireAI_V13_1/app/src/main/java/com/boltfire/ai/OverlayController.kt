package com.boltfire.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * V13.1: minimal gameplay overlay + two-tap minimap calibration.
 * No input is injected into the game.
 */
class OverlayController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onAnalysisEnabledChanged(enabled: Boolean)
        fun onStopRequested()
        fun onMapCalibrationChanged(cx: Float, cy: Float, halfW: Float, halfH: Float)
    }

    data class Marker(val x: Float, val y: Float, val label: String = "SIGNAL")
    data class ActionHint(val text: String, val x: Float, val y: Float)
    data class MovementHint(val dx: Float, val dy: Float, val text: String)
    data class MapHint(val direction: String, val distance: String)
    data class TargetGuide(val x: Float, val y: Float, val text: String)
    data class RotationHint(val dx: Float, val dy: Float, val text: String)
    data class MapRegion(val cx: Float, val cy: Float, val halfW: Float, val halfH: Float)

    data class MapThreatIndicator(
        val dx: Float,
        val dy: Float,
        val mapDx: Float,
        val mapDy: Float,
        val direction: String,
        val distance: String,
        val confidence: Int,
        val index: Int
    )

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var controls: LinearLayout? = null
    private var bubbleText: TextView? = null
    private var markerView: MarkerView? = null
    private var calibrationView: CalibrationView? = null
    private var analysisEnabled = true
    private var currentRegion = MapRegion(0.13f, 0.145f, 0.115f, 0.125f)

    fun show() {
        if (root != null) return
        showMarkerLayer()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }

        bubbleText = TextView(context).apply {
            text = "⚡ BF13.1  MAP"
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(6), dp(9), dp(6))
            setBackgroundColor(Color.argb(220, 10, 13, 18))
            setOnClickListener {
                controls?.visibility = if (controls?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }

        controls = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            setPadding(0, dp(3), 0, 0)
        }

        val pause = Button(context).apply {
            text = "Pause"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                analysisEnabled = !analysisEnabled
                text = if (analysisEnabled) "Pause" else "Reprendre"
                if (!analysisEnabled) clearGuidance()
                bubbleText?.text = if (analysisEnabled) "⚡ BF13.1  MAP" else "⚡ BF13.1  PAUSE"
                listener.onAnalysisEnabledChanged(analysisEnabled)
            }
        }

        val calibrate = Button(context).apply {
            text = "Calibrer"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { beginCalibration() }
        }

        val test = Button(context).apply {
            text = "Test flèche"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                controls?.visibility = View.GONE
                markerView?.setRotationHint(RotationHint(0.85f, -0.20f, "→ TEST DIRECTION"))
                postDelayed({ markerView?.setRotationHint(null) }, 2200L)
            }
        }

        val stop = Button(context).apply {
            text = "Stop"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { listener.onStopRequested() }
        }

        controls?.addView(pause, LinearLayout.LayoutParams(dp(72), dp(34)))
        controls?.addView(calibrate, LinearLayout.LayoutParams(dp(78), dp(34)))
        controls?.addView(test, LinearLayout.LayoutParams(dp(92), dp(34)))
        controls?.addView(stop, LinearLayout.LayoutParams(dp(58), dp(34)))
        container.addView(bubbleText, LinearLayout.LayoutParams(dp(118), dp(34)))
        container.addView(controls)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(60)
        }

        try {
            windowManager.addView(container, params)
            root = container
        } catch (t: Throwable) {
            t.printStackTrace()
            root = null
        }
    }

    fun setMapRegion(cx: Float, cy: Float, halfW: Float, halfH: Float) {
        currentRegion = MapRegion(cx, cy, halfW, halfH)
        markerView?.setMapRegion(currentRegion)
    }

    private fun beginCalibration() {
        if (calibrationView != null) return
        controls?.visibility = View.GONE
        bubbleText?.text = "⚡ BF13.1  CAL"
        clearGuidance()

        val view = CalibrationView(context) { cx, cy, halfW, halfH ->
            setMapRegion(cx, cy, halfW, halfH)
            listener.onMapCalibrationChanged(cx, cy, halfW, halfH)
            calibrationView?.let { runCatching { windowManager.removeView(it) } }
            calibrationView = null
            bubbleText?.text = "⚡ BF13.1  MAP✓"
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        try {
            windowManager.addView(view, params)
            calibrationView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            bubbleText?.text = "⚡ BF13.1  CAL ERR"
        }
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun showMarkerLayer() {
        if (markerView != null) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val view = MarkerView(context).also { it.setMapRegion(currentRegion) }
        try {
            windowManager.addView(view, params)
            markerView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            markerView = null
        }
    }

    fun updateMarkers(markers: List<Marker>) = markerView?.setMarkers(markers) ?: Unit

    fun showMapThreats(threats: List<MapThreatIndicator>) {
        markerView?.setMapThreats(threats)
        bubbleText?.text = when {
            !analysisEnabled -> "⚡ BF13.1  PAUSE"
            threats.isEmpty() -> "⚡ BF13.1  0E"
            else -> "⚡ BF13.1  ${threats.size}E"
        }
    }

    fun showScanning() {
        if (analysisEnabled && calibrationView == null) bubbleText?.text = "⚡ BF13.1  SCAN"
    }

    fun clearGuidance() {
        markerView?.setMarkers(emptyList())
        markerView?.setActionHint(null)
        markerView?.setMovementHint(null)
        markerView?.setMapHint(null)
        markerView?.setTargetGuide(null)
        markerView?.setRotationHint(null)
        markerView?.setMapThreats(emptyList())
    }

    fun clearMarkers() = clearGuidance()
    fun showActionHint(text: String?, x: Float = 0.86f, y: Float = 0.74f) {
        markerView?.setActionHint(text?.let { ActionHint(it, x, y) })
    }
    fun showMovementHint(dx: Float, dy: Float, text: String) {
        markerView?.setMovementHint(MovementHint(dx, dy, text))
    }
    fun showMapHint(direction: String, distance: String) {
        markerView?.setMapHint(MapHint(direction, distance))
    }
    fun showTargetGuide(x: Float, y: Float, text: String) {
        markerView?.setTargetGuide(TargetGuide(x, y, text))
    }
    fun clearTargetGuide() = markerView?.setTargetGuide(null) ?: Unit
    fun showRotationHint(dx: Float, dy: Float, text: String) {
        markerView?.setRotationHint(RotationHint(dx, dy, text))
    }
    fun clearRotationHint() = markerView?.setRotationHint(null) ?: Unit

    fun update(status: String, advice: String) {
        if (root == null) show()
    }

    fun showError(message: String) {
        if (root == null) show()
        bubbleText?.text = "⚡ BF13.1  ERREUR"
        clearGuidance()
    }

    fun hidePanel() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        controls = null
        bubbleText = null
    }

    fun hide() {
        calibrationView?.let { runCatching { windowManager.removeView(it) } }
        calibrationView = null
        hidePanel()
        markerView?.let { runCatching { windowManager.removeView(it) } }
        markerView = null
    }

    fun isVisible(): Boolean = root != null
    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    private class CalibrationView(
        context: Context,
        private val done: (Float, Float, Float, Float) -> Unit
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var centerX: Float? = null
        private var centerY: Float? = null

        init {
            textPaint.color = Color.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) return true
            if (centerX == null) {
                centerX = event.x
                centerY = event.y
                invalidate()
                return true
            }
            val cx = centerX ?: return true
            val cy = centerY ?: return true
            val radiusPx = hypot(event.x - cx, event.y - cy)
                .coerceIn(48f * resources.displayMetrics.density, min(width, height) * 0.30f)
            done(
                (cx / width).coerceIn(0.03f, 0.45f),
                (cy / height).coerceIn(0.03f, 0.45f),
                (radiusPx / width).coerceIn(0.035f, 0.30f),
                (radiusPx / height).coerceIn(0.05f, 0.35f)
            )
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val d = resources.displayMetrics.density
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(105, 0, 0, 0)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

            textPaint.textSize = 16f * resources.displayMetrics.scaledDensity
            if (centerX == null) {
                canvas.drawText("1/2  TOUCHE LE CENTRE DE LA MINI-CARTE", width * 0.5f, height * 0.50f, textPaint)
            } else {
                val cx = centerX!!
                val cy = centerY!!
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f * d
                paint.color = Color.YELLOW
                canvas.drawCircle(cx, cy, 16f * d, paint)
                canvas.drawLine(cx - 25f * d, cy, cx + 25f * d, cy, paint)
                canvas.drawLine(cx, cy - 25f * d, cx, cy + 25f * d, paint)
                canvas.drawText("2/2  TOUCHE LE BORD DE LA MINI-CARTE", width * 0.5f, height * 0.50f, textPaint)
            }
        }
    }

    private class MarkerView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private var markers: List<Marker> = emptyList()
        private var actionHint: ActionHint? = null
        private var movementHint: MovementHint? = null
        private var mapHint: MapHint? = null
        private var targetGuide: TargetGuide? = null
        private var rotationHint: RotationHint? = null
        private var mapThreats: List<MapThreatIndicator> = emptyList()
        private var mapRegion = MapRegion(0.13f, 0.145f, 0.115f, 0.125f)

        init {
            paint.style = Paint.Style.STROKE
            textPaint.style = Paint.Style.FILL
            textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        fun setMarkers(value: List<Marker>) { markers = value; postInvalidateOnAnimation() }
        fun setActionHint(value: ActionHint?) { actionHint = value; postInvalidateOnAnimation() }
        fun setMovementHint(value: MovementHint?) { movementHint = value; postInvalidateOnAnimation() }
        fun setMapHint(value: MapHint?) { mapHint = value; postInvalidateOnAnimation() }
        fun setTargetGuide(value: TargetGuide?) { targetGuide = value; postInvalidateOnAnimation() }
        fun setRotationHint(value: RotationHint?) { rotationHint = value; postInvalidateOnAnimation() }
        fun setMapThreats(value: List<MapThreatIndicator>) { mapThreats = value; postInvalidateOnAnimation() }
        fun setMapRegion(value: MapRegion) { mapRegion = value; postInvalidateOnAnimation() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val d = resources.displayMetrics.density
            drawMinimapThreats(canvas, w, h, d)
            drawThreatCompass(canvas, w, h, d)
            rotationHint?.let { drawRotationGuide(canvas, w, h, d, it) }
            targetGuide?.let { drawTargetGuide(canvas, w, h, d, it) }
            for (marker in markers.take(2)) {
                val x = marker.x.coerceIn(0f, 1f) * w
                val y = marker.y.coerceIn(0f, 1f) * h
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f * d
                paint.color = Color.argb(175, 255, 75, 65)
                canvas.drawCircle(x, y, 11f * d, paint)
            }
        }

        private fun drawMinimapThreats(canvas: Canvas, w: Float, h: Float, d: Float) {
            if (mapThreats.isEmpty()) return
            val cx = mapRegion.cx * w
            val cy = mapRegion.cy * h
            val halfW = mapRegion.halfW * w
            val halfH = mapRegion.halfH * h
            mapThreats.take(3).forEachIndexed { i, threat ->
                val x = cx + threat.mapDx.coerceIn(-1f, 1f) * halfW
                val y = cy + threat.mapDy.coerceIn(-1f, 1f) * halfH
                val primary = i == 0
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = if (primary) 3.2f * d else 2f * d
                paint.color = if (primary) Color.YELLOW else Color.CYAN
                canvas.drawCircle(x, y, if (primary) 12f * d else 8f * d, paint)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = 10f * resources.displayMetrics.scaledDensity
                textPaint.color = if (primary) Color.YELLOW else Color.CYAN
                canvas.drawText("E${threat.index}", x, y - 12f * d, textPaint)
            }
        }

        private fun drawThreatCompass(canvas: Canvas, w: Float, h: Float, d: Float) {
            if (mapThreats.isEmpty()) return
            val cx = w * 0.5f
            val cy = h * 0.50f
            val radius = min(w, h) * 0.32f
            mapThreats.take(3).forEachIndexed { i, threat ->
                val mag = sqrt(threat.dx * threat.dx + threat.dy * threat.dy).coerceAtLeast(0.001f)
                val nx = threat.dx / mag
                val ny = threat.dy / mag
                val x = (cx + nx * radius).coerceIn(36f * d, w - 36f * d)
                val y = (cy + ny * radius).coerceIn(36f * d, h - 36f * d)
                val primary = i == 0
                drawChevron(canvas, x, y, nx, ny, d, primary)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = if (primary) 12f * resources.displayMetrics.scaledDensity else 9f * resources.displayMetrics.scaledDensity
                textPaint.color = if (primary) Color.YELLOW else Color.CYAN
                canvas.drawText(if (primary) "E${threat.index} ${threat.direction}" else "E${threat.index}", x, y + 27f * d, textPaint)
            }
        }

        private fun drawChevron(canvas: Canvas, x: Float, y: Float, nx: Float, ny: Float, d: Float, primary: Boolean) {
            val angle = atan2(ny.toDouble(), nx.toDouble())
            val size = if (primary) 21f * d else 14f * d
            val baseX = x - cos(angle).toFloat() * size * 0.55f
            val baseY = y - sin(angle).toFloat() * size * 0.55f
            val perpX = -sin(angle).toFloat()
            val perpY = cos(angle).toFloat()
            path.reset()
            path.moveTo(x + cos(angle).toFloat() * size, y + sin(angle).toFloat() * size)
            path.lineTo(baseX + perpX * size * 0.60f, baseY + perpY * size * 0.60f)
            path.lineTo(baseX - perpX * size * 0.60f, baseY - perpY * size * 0.60f)
            path.close()
            paint.style = Paint.Style.FILL
            paint.color = if (primary) Color.argb(235, 255, 215, 0) else Color.argb(220, 35, 210, 255)
            canvas.drawPath(path, paint)
        }

        private fun drawRotationGuide(canvas: Canvas, w: Float, h: Float, d: Float, r: RotationHint) {
            val dx = r.dx.coerceIn(-1f, 1f)
            val dy = r.dy.coerceIn(-1f, 1f)
            val magnitude = sqrt(dx * dx + dy * dy)
            if (magnitude < 0.04f) return
            val cx = w * 0.5f
            val cy = h * 0.54f
            val nx = dx / magnitude
            val ny = dy / magnitude
            val len = min(w, h) * 0.17f
            val ex = cx + nx * len
            val ey = cy + ny * len
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = 5f * d
            paint.color = Color.argb(238, 255, 210, 0)
            canvas.drawLine(cx, cy, ex, ey, paint)
            val angle = atan2((ey - cy).toDouble(), (ex - cx).toDouble())
            val wing = 16f * d
            canvas.drawLine(ex, ey, ex - wing * cos(angle - 0.55).toFloat(), ey - wing * sin(angle - 0.55).toFloat(), paint)
            canvas.drawLine(ex, ey, ex - wing * cos(angle + 0.55).toFloat(), ey - wing * sin(angle + 0.55).toFloat(), paint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 14f * resources.displayMetrics.scaledDensity
            textPaint.color = Color.YELLOW
            val boxW = min(w * 0.34f, 250f * d)
            val box = RectF(cx - boxW / 2f, cy + 33f * d, cx + boxW / 2f, cy + 65f * d)
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(170, 0, 0, 0)
            canvas.drawRoundRect(box, 10f * d, 10f * d, paint)
            canvas.drawText(r.text, cx, cy + 55f * d, textPaint)
        }

        private fun drawTargetGuide(canvas: Canvas, w: Float, h: Float, d: Float, target: TargetGuide) {
            val tx = target.x.coerceIn(0f, 1f) * w
            val ty = target.y.coerceIn(0f, 1f) * h
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f * d
            paint.color = Color.argb(220, 255, 215, 0)
            canvas.drawCircle(tx, ty, 16f * d, paint)
            canvas.drawLine(tx - 25f * d, ty, tx - 10f * d, ty, paint)
            canvas.drawLine(tx + 10f * d, ty, tx + 25f * d, ty, paint)
            canvas.drawLine(tx, ty - 25f * d, tx, ty - 10f * d, paint)
            canvas.drawLine(tx, ty + 10f * d, tx, ty + 25f * d, paint)
        }
    }
}
