# BoltFire AI V11 – Experimental Decision Bot

Projet Android destiné à l'étude du comportement d'un bot face à une partie de jeu observée à l'écran.

## Ce que fait V11

- capture l'écran Android via MediaProjection ;
- échantillonne l'image afin de limiter la charge CPU ;
- détecte des signaux visuels rouges/orangés avec une heuristique légère ;
- analyse heuristiquement la zone de mini-carte ;
- construit un `GameState` normalisé ;
- exécute un `DecisionEngine` séparé de la vision ;
- produit les décisions `OBSERVE`, `TRACK`, `AIM_RECOMMENDATION`, `ROTATE` et `REPOSITION` ;
- affiche la décision et son niveau de confiance dans l'overlay ;
- enregistre chaque décision dans un CSV pour l'analyse statistique.

## Journal expérimental

Les fichiers CSV sont écrits dans le dossier externe propre à l'application :

`Android/data/com.boltfire.ai/files/experiments/`

Colonnes : timestamp, changement de frame, nombre de signaux, coordonnées de cible, indication mini-carte, décision, confiance et justification.

## Architecture

- `ScreenAnalysisService.kt` : capture et pipeline temps réel
- `BotModels.kt` : état du jeu et modèles de décision
- `DecisionEngine.kt` : politique de décision expérimentale
- `ExperimentLogger.kt` : journalisation CSV
- `OverlayController.kt` : affichage des observations et décisions
- `MainActivity.kt` : permissions overlay/capture et démarrage

## Limite de cette version

V11 observe une partie en direct et prend des décisions de bot, mais ne génère aucun toucher, swipe, tir ou contrôle automatique du client du jeu. Le moteur de décision est volontairement séparé de l'exécution afin de permettre l'étude, la mesure et le remplacement ultérieur des composants dans un environnement autorisé.

La détection visuelle et la mini-carte restent heuristiques : elles ne sont pas encore basées sur un modèle de vision entraîné.

## Compilation

Le projet utilise Android Gradle Plugin 8.6.1, Kotlin 2.0.21, Java 17, compileSdk 35 et minSdk 26.

Le workflow `.github/workflows/build.yml` peut construire automatiquement `app-debug.apk` avec GitHub Actions.
