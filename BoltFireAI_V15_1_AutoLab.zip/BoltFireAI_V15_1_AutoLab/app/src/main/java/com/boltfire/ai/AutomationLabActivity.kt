package com.boltfire.ai

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Local automation lab for validating Android accessibility gestures end-to-end.
 * It is intentionally restricted to BoltFire's own package.
 */
class AutomationLabActivity : Activity() {

    private lateinit var arena: ArenaView
    private lateinit var status: TextView
    private lateinit var autoButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private var autoEnabled = false
    private var actionCount = 0

    private val loop = object : Runnable {
        override fun run() {
            if (autoEnabled) autoStep()
            handler.postDelayed(this, 240L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        val root = FrameLayout(this)
        arena = ArenaView(this)
        root.addView(arena, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.argb(210, 8, 12, 18))
        }
        status = TextView(this).apply {
            text = "A? • AUTO OFF • ACT 0 • HIT 0"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        autoButton = Button(this).apply {
            text = "AUTO ON"
            setOnClickListener {
                if (!BotAccessibilityService.isConnected()) {
                    Toast.makeText(this@AutomationLabActivity, "Active BoltFire dans Accessibilité.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    return@setOnClickListener
                }
                autoEnabled = !autoEnabled
                text = if (autoEnabled) "AUTO OFF" else "AUTO ON"
                updateStatus()
            }
        }
        val reset = Button(this).apply {
            text = "Reset"
            setOnClickListener {
                arena.reset()
                actionCount = 0
                updateStatus()
            }
        }
        val exit = Button(this).apply {
            text = "Quitter"
            setOnClickListener { finish() }
        }
        top.addView(status, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(autoButton)
        top.addView(reset)
        top.addView(exit)

        root.addView(top, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ))
        setContentView(root)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(loop)
        handler.post(loop)
        updateStatus()
    }

    override fun onPause() {
        autoEnabled = false
        handler.removeCallbacks(loop)
        super.onPause()
    }

    private fun autoStep() {
        // Safety gate: gestures are dispatched only while BoltFire itself is foreground.
        val fg = BotAccessibilityService.currentForegroundPackage()
        if (!BotAccessibilityService.isConnected() || fg != packageName) {
            autoEnabled = false
            autoButton.text = "AUTO ON"
            updateStatus()
            return
        }

        val tx = arena.targetX
        val ty = arena.targetY
        val dx = tx - 0.5f
        val dy = ty - 0.48f
        val aligned = abs(dx) < 0.055f && abs(dy) < 0.10f

        val did = if (aligned) {
            // Calibrated lab fire button.
            BotAccessibilityService.tapNormalized(0.90f, 0.62f, 55L)
        } else {
            // Camera swipe. ArenaView interprets the swipe and moves the target toward centre.
            val sx = 0.70f
            val sy = 0.50f
            val ex = (sx + dx.coerceIn(-0.22f, 0.22f)).coerceIn(0.48f, 0.93f)
            val ey = (sy + dy.coerceIn(-0.15f, 0.15f)).coerceIn(0.25f, 0.78f)
            BotAccessibilityService.swipeNormalized(sx, sy, ex, ey, 120L)
        }
        if (did) actionCount++
        updateStatus()
    }

    private fun updateStatus() {
        val a = if (BotAccessibilityService.isConnected()) "A✓" else "A✗"
        val fg = if (BotAccessibilityService.currentForegroundPackage() == packageName) "F✓" else "F✗"
        val auto = if (autoEnabled) "AUTO✓" else "AUTO OFF"
        status.text = "$a • $fg • $auto • ACT $actionCount • HIT ${arena.hits} • SHOT ${arena.shots}"
    }

    private class ArenaView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        var targetX: Float = 0.78f
            private set
        var targetY: Float = 0.43f
            private set
        var shots: Int = 0
            private set
        var hits: Int = 0
            private set

        private var downX = 0f
        private var downY = 0f

        fun reset() {
            targetX = 0.78f
            targetY = 0.43f
            shots = 0
            hits = 0
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(25, 38, 32))
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)

            // Crosshair.
            paint.color = Color.WHITE
            paint.strokeWidth = 3f
            canvas.drawLine(w * 0.48f, h * 0.48f, w * 0.52f, h * 0.48f, paint)
            canvas.drawLine(w * 0.50f, h * 0.44f, w * 0.50f, h * 0.52f, paint)

            // Moving target.
            val cx = w * targetX
            val cy = h * targetY
            paint.color = Color.RED
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 7f
            canvas.drawCircle(cx, cy, h * 0.055f, paint)
            paint.style = Paint.Style.FILL
            canvas.drawCircle(cx, cy, h * 0.016f, paint)

            // Joystick zone.
            paint.color = Color.argb(160, 240, 240, 240)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            canvas.drawCircle(w * 0.15f, h * 0.74f, h * 0.10f, paint)

            // Fire button.
            paint.color = Color.argb(210, 255, 190, 0)
            canvas.drawCircle(w * 0.90f, h * 0.62f, h * 0.075f, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            paint.textSize = h * 0.04f
            canvas.drawText("TIR", w * 0.872f, h * 0.632f, paint)

            // Camera zone cue.
            paint.color = Color.argb(80, 255, 255, 255)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            canvas.drawRect(RectF(w * 0.45f, h * 0.18f, w * 0.95f, h * 0.80f), paint)
            paint.style = Paint.Style.FILL
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val w = width.toFloat().coerceAtLeast(1f)
                    val h = height.toFloat().coerceAtLeast(1f)
                    val ux = event.x / w
                    val uy = event.y / h
                    val dx = (event.x - downX) / w
                    val dy = (event.y - downY) / h
                    val travel = hypot(dx, dy)

                    val fireDist = hypot(ux - 0.90f, uy - 0.62f)
                    if (travel < 0.025f && fireDist < 0.09f) {
                        shots++
                        if (abs(targetX - 0.5f) < 0.065f && abs(targetY - 0.48f) < 0.11f) {
                            hits++
                            // Spawn another target for a repeatable autonomous cycle.
                            targetX = if (hits % 2 == 0) 0.24f else 0.78f
                            targetY = if (hits % 3 == 0) 0.58f else 0.38f
                        }
                        invalidate()
                        return true
                    }

                    // Camera zone swipe. Move target opposite the camera gesture so that
                    // repeated swipes converge the target toward the centre.
                    if (downX / w > 0.45f && travel >= 0.025f) {
                        targetX = (targetX - dx * 1.05f).coerceIn(0.08f, 0.92f)
                        targetY = (targetY - dy * 0.85f).coerceIn(0.16f, 0.82f)
                        invalidate()
                    }
                    return true
                }
            }
            return true
        }
    }
}
