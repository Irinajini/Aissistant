package com.boltfire.ai

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Experimental policy engine.
 * It decides what a hypothetical bot would do from screen-derived observations,
 * but it deliberately does not execute touches, swipes, aiming or firing.
 */
class DecisionEngine {

    fun decide(state: GameState): BotDecision {
        val hasCue = state.visualCueCount > 0 && state.targetX != null && state.targetY != null
        val cueStrength = (state.strongestCueScore / 8f).coerceIn(0f, 1f)

        if (hasCue) {
            val x = state.targetX!!
            val y = state.targetY!!
            val centerDistance = sqrt((x - 0.5f) * (x - 0.5f) + (y - 0.5f) * (y - 0.5f))
            val centered = centerDistance < 0.22f
            val confidence = (0.52f + cueStrength * 0.34f + if (centered) 0.10f else 0f)
                .coerceIn(0f, 0.96f)

            return if (centered) {
                BotDecision(
                    timestampMs = state.timestampMs,
                    action = BotAction.AIM_RECOMMENDATION,
                    confidence = confidence,
                    reason = "Signal visuel prioritaire proche du centre de l'écran",
                    targetX = x,
                    targetY = y
                )
            } else {
                BotDecision(
                    timestampMs = state.timestampMs,
                    action = BotAction.TRACK,
                    confidence = confidence,
                    reason = "Signal visuel prioritaire hors centre, suivi recommandé",
                    targetX = x,
                    targetY = y
                )
            }
        }

        if (state.minimapDirection != null && state.minimapDx != null && state.minimapDy != null) {
            val magnitude = sqrt(
                state.minimapDx * state.minimapDx + state.minimapDy * state.minimapDy
            )
            val action = if (magnitude > 0.30f) BotAction.ROTATE else BotAction.REPOSITION
            return BotDecision(
                timestampMs = state.timestampMs,
                action = action,
                confidence = (0.50f + magnitude.coerceIn(0f, 0.45f)).coerceAtMost(0.88f),
                reason = "Orientation suggérée par l'analyse heuristique de la mini-carte",
                moveDx = state.minimapDx,
                moveDy = state.minimapDy
            )
        }

        val stableConfidence = if (state.frameChanged) 0.48f else 0.62f
        return BotDecision(
            timestampMs = state.timestampMs,
            action = BotAction.OBSERVE,
            confidence = stableConfidence,
            reason = if (state.frameChanged) {
                "Changement visuel sans cible suffisamment fiable"
            } else {
                "Aucun signal exploitable détecté"
            }
        )
    }

    fun humanReadable(decision: BotDecision): String {
        val pct = (decision.confidence * 100f).toInt()
        return when (decision.action) {
            BotAction.OBSERVE -> "BOT: OBSERVER • confiance $pct%"
            BotAction.TRACK -> "BOT: SUIVRE LA CIBLE • confiance $pct%"
            BotAction.AIM_RECOMMENDATION -> "BOT: VISÉE RECOMMANDÉE • confiance $pct%"
            BotAction.ROTATE -> "BOT: ROTATION • confiance $pct%"
            BotAction.REPOSITION -> "BOT: REPOSITIONNEMENT • confiance $pct%"
        }
    }
}
