package com.boltfire.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * V15: compact autonomous-bot overlay for an explicitly bound offline test app.
 * 
 * VERSION MODIFIÉE POUR FREE FIRE :
 * - Renommage du bouton "LAB" en "LIER" pour refléter sa fonction
 */
class OverlayController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onAnalysisEnabledChanged(enabled: Boolean)
        fun onStopRequested()
        fun onMapCalibrationChanged(cx: Float, cy: Float, halfW: Float, halfH: Float)
        fun onAutoModeChanged(enabled: Boolean)
        fun onBindTargetRequested()
    }

    data class Marker(val x: Float, val y: Float, val label: String = "SIGNAL")
    data class ActionHint(val text: String, val x: Float, val y: Float)
    data class MovementHint(val dx: Float, val dy: Float, val text: String)
    data class MapHint(val direction: String, val distance: String)
    data class TargetGuide(val x: Float, val y: Float, val text: String)
    data class RotationHint(val dx: Float, val dy: Float, val text: String)
    data class MapRegion(val cx: Float, val cy: Float, val halfW: Float, val halfH: Float)

    enum class ControlAction { FIRE, SWIPE, JOYSTICK, CROUCH, JUMP, GLOO }

    data class ControlGuide(
        val action: ControlAction,
        val dx: Float = 0f,
        val dy: Float = 0f
    )

    data class ControlPoint(val x: Float, val y: Float)
    data class ControlLayout(
        val joystick: ControlPoint,
        val fire: ControlPoint,
        val crouch: ControlPoint,
        val jump: ControlPoint,
        val gloo: ControlPoint
    )

    data class MapThreatIndicator(
        val dx: Float,
        val dy: Float,
        val mapDx: Float,
        val mapDy: Float,
        val direction: String,
        val distance: String,
        val confidence: Int,
        val index: Int
    )

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var controls: LinearLayout? = null
    private var bubbleText: TextView? = null
    private var markerView: MarkerView? = null
    private var calibrationView: View? = null
    private var analysisEnabled = true
    private var autoEnabled = false
    private var currentRegion = MapRegion(0.13f, 0.145f, 0.115f, 0.125f)
    private val controlPrefs = context.getSharedPreferences("boltfire_control_layout", Context.MODE_PRIVATE)
    private var controlLayout = loadControlLayout()

    fun show() {
        if (root != null) return
        showMarkerLayer()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }

        bubbleText = TextView(context).apply {
            text = "⚡ BF15.1"
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(6), dp(9), dp(6))
            setBackgroundColor(Color.argb(220, 10, 13, 18))
            setOnClickListener {
                controls?.visibility = if (controls?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }

        controls = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            setPadding(0, dp(3), 0, 0)
        }

        val pause = Button(context).apply {
            text = "Pause"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                analysisEnabled = !analysisEnabled
                text = if (analysisEnabled) "Pause" else "Reprendre"
                if (!analysisEnabled) clearGuidance()
                bubbleText?.text = if (analysisEnabled) "⚡ BF15.1" else "⚡ BF15.1 ∥"
                listener.onAnalysisEnabledChanged(analysisEnabled)
            }
        }

        val calibrate = Button(context).apply {
            text = "Map"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { beginCalibration() }
        }

        val test = Button(context).apply {
            text = "HUD"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { beginControlCalibration() }
        }

        val auto = Button(context).apply {
            text = "GUIDE OFF"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                autoEnabled = !autoEnabled
                text = if (autoEnabled) "GUIDE ON" else "GUIDE OFF"
                listener.onAutoModeChanged(autoEnabled)
            }
        }

        // ========== MODIFICATION : RENOMMER "LAB" EN "LIER" ==========
        val bind = Button(context).apply {
            text = "LIER"   // Au lieu de "LAB"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { listener.onBindTargetRequested() }
        }
        // =============================================================

        val stop = Button(context).apply {
            text = "Stop"
            textSize = 9f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { listener.onStopRequested() }
        }

        controls?.addView(pause, LinearLayout.LayoutParams(dp(58), dp(34)))
        controls?.addView(calibrate, LinearLayout.LayoutParams(dp(48), dp(34)))
        controls?.addView(test, LinearLayout.LayoutParams(dp(48), dp(34)))
        controls?.addView(bind, LinearLayout.LayoutParams(dp(50), dp(34)))
        controls?.addView(auto, LinearLayout.LayoutParams(dp(68), dp(34)))
        controls?.addView(stop, LinearLayout.LayoutParams(dp(52), dp(34)))
        container.addView(bubbleText, LinearLayout.LayoutParams(dp(78), dp(32)))
        container.addView(controls)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(60)
        }

        try {
            windowManager.addView(container, params)
            root = container
        } catch (t: Throwable) {
            t.printStackTrace()
            root = null
        }
    }

    fun setMapRegion(cx: Float, cy: Float, halfW: Float, halfH: Float) {
        currentRegion = MapRegion(cx, cy, halfW, halfH)
        markerView?.setMapRegion(currentRegion)
    }

    private fun beginCalibration() {
        if (calibrationView != null) return
        controls?.visibility = View.GONE
        bubbleText?.text = "⚡ BF15 CAL"
        clearGuidance()

        val view = CalibrationView(context) { cx, cy, halfW, halfH ->
            setMapRegion(cx, cy, halfW, halfH)
            listener.onMapCalibrationChanged(cx, cy, halfW, halfH)
            calibrationView?.let { runCatching { windowManager.removeView(it) } }
            calibrationView = null
            bubbleText?.text = "⚡ BF15.1"
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        try {
            windowManager.addView(view, params)
            calibrationView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            bubbleText?.text = "⚡ BF15 !"
        }
    }

    private fun loadControlLayout(): ControlLayout {
        fun point(prefix: String, dx: Float, dy: Float) = ControlPoint(
            controlPrefs.getFloat("${prefix}_x", dx),
            controlPrefs.getFloat("${prefix}_y", dy)
        )
        return ControlLayout(
            joystick = point("joy", 0.15f, 0.74f),
            fire = point("fire", 0.90f, 0.58f),
            crouch = point("crouch", 0.82f, 0.79f),
            jump = point("jump", 0.91f, 0.72f),
            gloo = point("gloo", 0.75f, 0.87f)
        )
    }

    private fun saveControlLayout(layout: ControlLayout) {
        controlPrefs.edit()
            .putFloat("joy_x", layout.joystick.x).putFloat("joy_y", layout.joystick.y)
            .putFloat("fire_x", layout.fire.x).putFloat("fire_y", layout.fire.y)
            .putFloat("crouch_x", layout.crouch.x).putFloat("crouch_y", layout.crouch.y)
            .putFloat("jump_x", layout.jump.x).putFloat("jump_y", layout.jump.y)
            .putFloat("gloo_x", layout.gloo.x).putFloat("gloo_y", layout.gloo.y)
            .apply()
    }

    private fun beginControlCalibration() {
        if (calibrationView != null) return
        controls?.visibility = View.GONE
        bubbleText?.text = "⚡ BF15 HUD"
        clearGuidance()
        val view = ControlCalibrationView(context) { layout ->
            controlLayout = layout
            saveControlLayout(layout)
            markerView?.setControlLayout(layout)
            calibrationView?.let { runCatching { windowManager.removeView(it) } }
            calibrationView = null
            bubbleText?.text = "⚡ BF15.1"
            // Short visual self-test: fire halo, then a right swipe.
            markerView?.setControlGuide(ControlGuide(ControlAction.FIRE))
            bubbleText?.postDelayed({ markerView?.setControlGuide(ControlGuide(ControlAction.SWIPE, 0.8f, 0f)) }, 700L)
            bubbleText?.postDelayed({ markerView?.setControlGuide(null) }, 1500L)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try {
            windowManager.addView(view, params)
            calibrationView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            bubbleText?.text = "⚡ BF15 !"
        }
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun showMarkerLayer() {
        if (markerView != null) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val view = MarkerView(context).also {
            it.setMapRegion(currentRegion)
            it.setControlLayout(controlLayout)
        }
        try {
            windowManager.addView(view, params)
            markerView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            markerView = null
        }
    }

    fun updateMarkers(markers: List<Marker>) = markerView?.setMarkers(markers) ?: Unit

    fun showMapThreats(threats: List<MapThreatIndicator>) {
        // Keep only the primary map signal on-screen to avoid conflicting directions.
        markerView?.setMapThreats(threats.take(1))
    }

    fun showScanning() {
        if (analysisEnabled && calibrationView == null) bubbleText?.text = "⚡ BF15.1"
    }

    fun showControlGuide(action: ControlAction, dx: Float = 0f, dy: Float = 0f) {
        markerView?.setControlGuide(ControlGuide(action, dx, dy))
    }

    fun clearControlGuide() {
        markerView?.setControlGuide(null)
    }

    fun clearGuidance() {
        markerView?.setMarkers(emptyList())
        markerView?.setActionHint(null)
        markerView?.setMovementHint(null)
        markerView?.setMapHint(null)
        markerView?.setTargetGuide(null)
        markerView?.setRotationHint(null)
        markerView?.setMapThreats(emptyList())
        markerView?.setControlGuide(null)
    }

    fun clearMarkers() = clearGuidance()
    fun showActionHint(text: String?, x: Float = 0.86f, y: Float = 0.74f) {
        markerView?.setActionHint(text?.let { ActionHint(it, x, y) })
    }
    fun showMovementHint(dx: Float, dy: Float, text: String) {
        markerView?.setMovementHint(MovementHint(dx, dy, text))
    }
    fun showMapHint(direction: String, distance: String) {
        markerView?.setMapHint(MapHint(direction, distance))
    }
    fun showTargetGuide(x: Float, y: Float, text: String) {
        markerView?.setTargetGuide(TargetGuide(x, y, text))
    }
    fun clearTargetGuide() = markerView?.setTargetGuide(null) ?: Unit
    fun showRotationHint(dx: Float, dy: Float, text: String) {
        markerView?.setRotationHint(RotationHint(dx, dy, text))
    }
    fun clearRotationHint() = markerView?.setRotationHint(null) ?: Unit

    fun update(status: String, advice: String) {
        if (root == null) show()
    }

    fun showError(message: String) {
        if (root == null) show()
        bubbleText?.text = "⚡ BF15 !"
        clearGuidance()
    }

    fun hidePanel() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        controls = null
        bubbleText = null
    }

    fun hide() {
        calibrationView?.let { runCatching { windowManager.removeView(it) } }
        calibrationView = null
        hidePanel()
        markerView?.let { runCatching { windowManager.removeView(it) } }
        markerView = null
    }

    fun isVisible(): Boolean = root != null
    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    // ============================================================
    // TOUTES LES CLASSES INTERNES RESTENT INCHANGÉES
    // (CalibrationView, ControlCalibrationView, MarkerView)
    // ============================================================

    private class CalibrationView(
        context: Context,
        private val done: (Float, Float, Float, Float) -> Unit
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var centerX: Float? = null
        private var centerY: Float? = null

        init {
            textPaint.color = Color.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) return true
            if (centerX == null) {
                centerX = event.x
                centerY = event.y
                invalidate()
                return true
            }
            val cx = centerX ?: return true
            val cy = centerY ?: return true
            val radiusPx = hypot(event.x - cx, event.y - cy)
                .coerceIn(48f * resources.displayMetrics.density, min(width, height) * 0.30f)
            done(
                (cx / width).coerceIn(0.03f, 0.45f),
                (cy / height).coerceIn(0.03f, 0.45f),
                (radiusPx / width).coerceIn(0.035f, 0.30f),
                (radiusPx / height).coerceIn(0.05f, 0.35f)
            )
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val d = resources.displayMetrics.density
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(105, 0, 0, 0)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

            textPaint.textSize = 16f * resources.displayMetrics.scaledDensity
            if (centerX == null) {
                canvas.drawText("1/2  TOUCHE LE CENTRE DE LA MINI-CARTE", width * 0.5f, height * 0.50f, textPaint)
            } else {
                val cx = centerX!!
                val cy = centerY!!
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f * d
                paint.color = Color.YELLOW
                canvas.drawCircle(cx, cy, 16f * d, paint)
                canvas.drawLine(cx - 25f * d, cy, cx + 25f * d, cy, paint)
                canvas.drawLine(cx, cy - 25f * d, cx, cy + 25f * d, paint)
                canvas.drawText("2/2  TOUCHE LE BORD DE LA MINI-CARTE", width * 0.5f, height * 0.50f, textPaint)
            }
        }
    }

    private class ControlCalibrationView(
        context: Context,
        private val done: (ControlLayout) -> Unit
    ) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        private val points = mutableListOf<ControlPoint>()
        private val labels = listOf("JOYSTICK", "TIR", "ACCROUPI", "SAUT", "GLOO")

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) return true
            points.add(ControlPoint((event.x / width).coerceIn(0f, 1f), (event.y / height).coerceIn(0f, 1f)))
            if (points.size >= labels.size) {
                done(ControlLayout(points[0], points[1], points[2], points[3], points[4]))
            } else {
                invalidate()
            }
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val d = resources.displayMetrics.density
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(125, 0, 0, 0)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            points.forEachIndexed { index, p ->
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f * d
                paint.color = Color.YELLOW
                canvas.drawCircle(p.x * width, p.y * height, 18f * d, paint)
                textPaint.textSize = 10f * resources.displayMetrics.scaledDensity
                canvas.drawText(labels[index], p.x * width, p.y * height - 25f * d, textPaint)
            }
            val next = labels[points.size.coerceAtMost(labels.lastIndex)]
            textPaint.textSize = 18f * resources.displayMetrics.scaledDensity
            canvas.drawText("TOUCHE : $next", width * 0.5f, height * 0.48f, textPaint)
            textPaint.textSize = 12f * resources.displayMetrics.scaledDensity
            canvas.drawText("${points.size + 1}/${labels.size}", width * 0.5f, height * 0.54f, textPaint)
        }
    }

    private class MarkerView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private var markers: List<Marker> = emptyList()
        private var actionHint: ActionHint? = null
        private var movementHint: MovementHint? = null
        private var mapHint: MapHint? = null
        private var targetGuide: TargetGuide? = null
        private var rotationHint: RotationHint? = null
        private var mapThreats: List<MapThreatIndicator> = emptyList()
        private var mapRegion = MapRegion(0.13f, 0.145f, 0.115f, 0.125f)
        private var controlGuide: ControlGuide? = null
        private var controlLayout = ControlLayout(
            ControlPoint(0.15f, 0.74f),
            ControlPoint(0.90f, 0.58f),
            ControlPoint(0.82f, 0.79f),
            ControlPoint(0.91f, 0.72f),
            ControlPoint(0.75f, 0.87f)
        )

        init {
            paint.style = Paint.Style.STROKE
            textPaint.style = Paint.Style.FILL
            textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        fun setMarkers(value: List<Marker>) { markers = value; postInvalidateOnAnimation() }
        fun setActionHint(value: ActionHint?) { actionHint = value; postInvalidateOnAnimation() }
        fun setMovementHint(value: MovementHint?) { movementHint = value; postInvalidateOnAnimation() }
        fun setMapHint(value: MapHint?) { mapHint = value; postInvalidateOnAnimation() }
        fun setTargetGuide(value: TargetGuide?) { targetGuide = value; postInvalidateOnAnimation() }
        fun setRotationHint(value: RotationHint?) { rotationHint = value; postInvalidateOnAnimation() }
        fun setMapThreats(value: List<MapThreatIndicator>) { mapThreats = value; postInvalidateOnAnimation() }
        fun setMapRegion(value: MapRegion) { mapRegion = value; postInvalidateOnAnimation() }
        fun setControlGuide(value: ControlGuide?) { controlGuide = value; postInvalidateOnAnimation() }
        fun setControlLayout(value: ControlLayout) { controlLayout = value; postInvalidateOnAnimation() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val d = resources.displayMetrics.density
            drawMinimapThreats(canvas, w, h, d)
            controlGuide?.let {
                drawControlGuide(canvas, w, h, d, it)
                postInvalidateDelayed(55L)
            }
        }

        private fun drawMinimapThreats(canvas: Canvas, w: Float, h: Float, d: Float) {
            val threat = mapThreats.firstOrNull() ?: return
            val cx = mapRegion.cx * w
            val cy = mapRegion.cy * h
            val halfW = mapRegion.halfW * w
            val halfH = mapRegion.halfH * h
            val x = cx + threat.mapDx.coerceIn(-1f, 1f) * halfW
            val y = cy + threat.mapDy.coerceIn(-1f, 1f) * halfH
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f * d
            paint.color = Color.argb(230, 255, 205, 0)
            canvas.drawCircle(x, y, 10f * d, paint)
        }

        private fun drawThreatCompass(canvas: Canvas, w: Float, h: Float, d: Float) {
            if (mapThreats.isEmpty()) return
            val cx = w * 0.5f
            val cy = h * 0.50f
            val radius = min(w, h) * 0.32f
            mapThreats.take(3).forEachIndexed { i, threat ->
                val mag = sqrt(threat.dx * threat.dx + threat.dy * threat.dy).coerceAtLeast(0.001f)
                val nx = threat.dx / mag
                val ny = threat.dy / mag
                val x = (cx + nx * radius).coerceIn(36f * d, w - 36f * d)
                val y = (cy + ny * radius).coerceIn(36f * d, h - 36f * d)
                val primary = i == 0
                drawChevron(canvas, x, y, nx, ny, d, primary)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = if (primary) 12f * resources.displayMetrics.scaledDensity else 9f * resources.displayMetrics.scaledDensity
                textPaint.color = if (primary) Color.YELLOW else Color.CYAN
                canvas.drawText(if (primary) "E${threat.index} ${threat.direction}" else "E${threat.index}", x, y + 27f * d, textPaint)
            }
        }

        private fun drawChevron(canvas: Canvas, x: Float, y: Float, nx: Float, ny: Float, d: Float, primary: Boolean) {
            val angle = atan2(ny.toDouble(), nx.toDouble())
            val size = if (primary) 21f * d else 14f * d
            val baseX = x - cos(angle).toFloat() * size * 0.55f
            val baseY = y - sin(angle).toFloat() * size * 0.55f
            val perpX = -sin(angle).toFloat()
            val perpY = cos(angle).toFloat()
            path.reset()
            path.moveTo(x + cos(angle).toFloat() * size, y + sin(angle).toFloat() * size)
            path.lineTo(baseX + perpX * size * 0.60f, baseY + perpY * size * 0.60f)
            path.lineTo(baseX - perpX * size * 0.60f, baseY - perpY * size * 0.60f)
            path.close()
            paint.style = Paint.Style.FILL
            paint.color = if (primary) Color.argb(235, 255, 215, 0) else Color.argb(220, 35, 210, 255)
            canvas.drawPath(path, paint)
        }

        private fun drawControlGuide(canvas: Canvas, w: Float, h: Float, d: Float, guide: ControlGuide) {
            val phase = (SystemClock.uptimeMillis() % 900L) / 900f
            fun pulseAt(point: ControlPoint, baseRadiusDp: Float) {
                val x = point.x * w
                val y = point.y * h
                val radius = (baseRadiusDp + phase * 12f) * d
                val alpha = (235 - phase * 150f).toInt().coerceIn(70, 235)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 4f * d
                paint.color = Color.argb(alpha, 255, 210, 0)
                canvas.drawCircle(x, y, radius, paint)
                paint.strokeWidth = 2f * d
                paint.color = Color.argb(210, 255, 255, 255)
                canvas.drawCircle(x, y, baseRadiusDp * 0.70f * d, paint)
            }

            when (guide.action) {
                ControlAction.FIRE -> pulseAt(controlLayout.fire, 27f)
                ControlAction.CROUCH -> pulseAt(controlLayout.crouch, 25f)
                ControlAction.JUMP -> pulseAt(controlLayout.jump, 25f)
                ControlAction.GLOO -> pulseAt(controlLayout.gloo, 25f)
                ControlAction.JOYSTICK -> {
                    val p = controlLayout.joystick
                    val cx = p.x * w
                    val cy = p.y * h
                    val mag = sqrt(guide.dx * guide.dx + guide.dy * guide.dy).coerceAtLeast(0.001f)
                    val nx = guide.dx / mag
                    val ny = guide.dy / mag
                    val ex = cx + nx * 44f * d
                    val ey = cy + ny * 44f * d
                    paint.style = Paint.Style.STROKE
                    paint.strokeCap = Paint.Cap.ROUND
                    paint.strokeWidth = 6f * d
                    paint.color = Color.argb(235, 255, 210, 0)
                    canvas.drawCircle(cx, cy, 31f * d, paint)
                    canvas.drawLine(cx, cy, ex, ey, paint)
                    drawArrowHead(canvas, cx, cy, ex, ey, d)
                }
                ControlAction.SWIPE -> {
                    var dx = guide.dx.coerceIn(-1f, 1f)
                    var dy = guide.dy.coerceIn(-0.75f, 0.75f)
                    val mag = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
                    dx /= mag
                    dy /= mag
                    // Keep the gesture on the camera side so it never hides the target or joystick.
                    val sx = w * 0.70f
                    val sy = h * 0.49f
                    val len = min(w, h) * 0.16f
                    val ex = (sx + dx * len).coerceIn(w * 0.48f, w * 0.94f)
                    val ey = (sy + dy * len).coerceIn(h * 0.25f, h * 0.76f)
                    paint.style = Paint.Style.STROKE
                    paint.strokeCap = Paint.Cap.ROUND
                    paint.strokeWidth = 7f * d
                    paint.color = Color.argb(225, 255, 210, 0)
                    canvas.drawLine(sx, sy, ex, ey, paint)
                    drawArrowHead(canvas, sx, sy, ex, ey, d)
                    // Finger cue: three small dots along the gesture, no gameplay text.
                    paint.style = Paint.Style.FILL
                    for (i in 0..2) {
                        val t = 0.15f + i * 0.22f
                        canvas.drawCircle(sx + (ex - sx) * t, sy + (ey - sy) * t, (5f + i) * d, paint)
                    }
                }
            }
        }

        private fun drawArrowHead(canvas: Canvas, sx: Float, sy: Float, ex: Float, ey: Float, d: Float) {
            val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
            val wing = 17f * d
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 6f * d
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.argb(235, 255, 210, 0)
            canvas.drawLine(ex, ey, ex - wing * cos(angle - 0.55).toFloat(), ey - wing * sin(angle - 0.55).toFloat(), paint)
            canvas.drawLine(ex, ey, ex - wing * cos(angle + 0.55).toFloat(), ey - wing * sin(angle + 0.55).toFloat(), paint)
        }

        private fun drawRotationGuide(canvas: Canvas, w: Float, h: Float, d: Float, r: RotationHint) {
            val dx = r.dx.coerceIn(-1f, 1f)
            val dy = r.dy.coerceIn(-1f, 1f)
            val magnitude = sqrt(dx * dx + dy * dy)
            if (magnitude < 0.04f) return
            val cx = w * 0.5f
            val cy = h * 0.54f
            val nx = dx / magnitude
            val ny = dy / magnitude
            val len = min(w, h) * 0.17f
            val ex = cx + nx * len
            val ey = cy + ny * len
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = 5f * d
            paint.color = Color.argb(238, 255, 210, 0)
            canvas.drawLine(cx, cy, ex, ey, paint)
            val angle = atan2((ey - cy).toDouble(), (ex - cx).toDouble())
            val wing = 16f * d
            canvas.drawLine(ex, ey, ex - wing * cos(angle - 0.55).toFloat(), ey - wing * sin(angle - 0.55).toFloat(), paint)
            canvas.drawLine(ex, ey, ex - wing * cos(angle + 0.55).toFloat(), ey - wing * sin(angle + 0.55).toFloat(), paint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 14f * resources.displayMetrics.scaledDensity
            textPaint.color = Color.YELLOW
            val boxW = min(w * 0.34f, 250f * d)
            val box = RectF(cx - boxW / 2f, cy + 33f * d, cx + boxW / 2f, cy + 65f * d)
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(170, 0, 0, 0)
            canvas.drawRoundRect(box, 10f * d, 10f * d, paint)
            canvas.drawText(r.text, cx, cy + 55f * d, textPaint)
        }

        private fun drawTargetGuide(canvas: Canvas, w: Float, h: Float, d: Float, target: TargetGuide) {
            val tx = target.x.coerceIn(0f, 1f) * w
            val ty = target.y.coerceIn(0f, 1f) * h
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f * d
            paint.color = Color.argb(220, 255, 215, 0)
            canvas.drawCircle(tx, ty, 16f * d, paint)
            canvas.drawLine(tx - 25f * d, ty, tx - 10f * d, ty, paint)
            canvas.drawLine(tx + 10f * d, ty, tx + 25f * d, ty, paint)
            canvas.drawLine(tx, ty - 25f * d, tx, ty - 10f * d, paint)
            canvas.drawLine(tx, ty + 10f * d, tx, ty + 25f * d, paint)
        }
    }
}