package com.boltfire.ai

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.sqrt

class ScreenAnalysisService : Service(), OverlayController.Listener {

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_PROJECTION_DATA = "projectionData"
        private const val CHANNEL_ID = "boltfire_analysis"
        private const val NOTIFICATION_ID = 7
        private const val ACTION_STOP = "com.boltfire.ai.STOP"
        private const val ACTION_SHOW = "com.boltfire.ai.SHOW"
        private const val PREFS = "boltfire_map_calibration"
        private const val KEY_CX = "map_cx"
        private const val KEY_CY = "map_cy"
        private const val KEY_HW = "map_half_w"
        private const val KEY_HH = "map_half_h"
        private const val SAMPLE_INTERVAL_MS = 220L
        private const val UI_INTERVAL_MS = 700L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: OverlayController? = null
    private var lastSignature = Long.MIN_VALUE
    private var receivedFrames = 0L
    private var sampledFrames = 0L
    private var lastSampleAt = 0L
    private var lastUiUpdate = 0L
    private var lastChangeAt = 0L
    private var analysisEnabled = true
    private var autoMode = false
    private lateinit var actionExecutor: AutomatedActionExecutor
    private var stopping = false
    private val decisionEngine = DecisionEngine()
    private lateinit var experimentLogger: ExperimentLogger
    private var lastDecision: BotDecision? = null
    private var stableMapThreats: List<MapThreat> = emptyList()
    private var lastMapThreatSeenAt = 0L
    private var mapCx = 0.13f
    private var mapCy = 0.145f
    private var mapHalfW = 0.115f
    private var mapHalfH = 0.125f

    // ===== VARIABLES PANEL =====
    private var panelAimbotActive = false
    private var panelAutoFireActive = false
    private var panelAntiBanActive = false
    private var panelEspActive = false
    private var panelActive = false
    private var aimSensitivity = 1.0f
    private var fovRadius = 0.25f
    private var smoothness = 0.7f

    // ===== STATS =====
    private var kills = 0
    private var shots = 0
    private var hits = 0
    private var lastShotTime = 0L

    override fun onCreate() {
        super.onCreate()
        actionExecutor = AutomatedActionExecutor(this)
        experimentLogger = ExperimentLogger(this)
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        mapCx = prefs.getFloat(KEY_CX, mapCx)
        mapCy = prefs.getFloat(KEY_CY, mapCy)
        mapHalfW = prefs.getFloat(KEY_HW, mapHalfW)
        mapHalfH = prefs.getFloat(KEY_HH, mapHalfH)
        createNotificationChannel()
        connectPanel()
    }

    // ============================================================
    // CONNEXION AU PANEL
    // ============================================================

    private fun connectPanel() {
        PanelManager.addListener(object : PanelManager.PanelStateListener {
            override fun onStateChanged(state: PanelManager.PanelState) {
                panelActive = state.panelActive
                panelAimbotActive = state.aimbotEnabled
                panelAutoFireActive = state.autoFireEnabled
                panelAntiBanActive = state.antiBanEnabled
                panelEspActive = state.espEnabled
                aimSensitivity = state.aimSensitivity
                fovRadius = state.fovRadius
                smoothness = state.smoothness
                
                // Mise à jour de l'overlay si ESP activé
                if (panelEspActive) {
                    overlay?.update("👁️ ESP ACTIF", "Affichage des menaces")
                }
            }

            override fun onAimbotToggled(enabled: Boolean) {
                panelAimbotActive = enabled
                if (enabled) {
                    overlay?.update("🎯 AIMBOT ACTIF", "Visée automatique")
                }
            }

            override fun onAutoFireToggled(enabled: Boolean) {
                panelAutoFireActive = enabled
                if (enabled) {
                    overlay?.update("🔥 AUTO FIRE ACTIF", "Tir automatique")
                }
            }

            override fun onAntiBanToggled(enabled: Boolean) {
                panelAntiBanActive = enabled
                if (enabled) {
                    overlay?.update("🛡️ ANTIBAN ACTIF", "Mode furtif")
                }
            }

            override fun onEspToggled(enabled: Boolean) {
                panelEspActive = enabled
            }
        })
    }

    // ============================================================
    // START COMMAND
    // ============================================================

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SHOW) {
            overlay?.show()
            return START_NOT_STICKY
        }

        stopProjection()
        stopping = false
        experimentLogger.startSession()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = readProjectionIntent(intent)

        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        return try {
            startForegroundCompat()
            overlay = OverlayController(this, this).also {
                it.show()
                it.setMapRegion(mapCx, mapCy, mapHalfW, mapHalfH)
                it.update("● DÉMARRAGE", "Capture en préparation…")
            }
            startProjection(resultCode, data)
            START_NOT_STICKY
        } catch (t: Throwable) {
            t.printStackTrace()
            overlay?.showError("Démarrage impossible : ${t.javaClass.simpleName}")
            mainHandler.postDelayed({ stopSelf(startId) }, 2500L)
            START_NOT_STICKY
        }
    }

    // ============================================================
    // OVERLAY LISTENER
    // ============================================================

    override fun onAnalysisEnabledChanged(enabled: Boolean) {
        analysisEnabled = enabled
        if (enabled) {
            lastSignature = Long.MIN_VALUE
            lastSampleAt = 0L
            overlay?.update("● ANALYSE ACTIVE", "Analyse adaptative activée.")
        } else {
            overlay?.update("● ANALYSE EN PAUSE", "Capture conservée, analyse arrêtée.")
        }
        updateNotification()
    }

    override fun onAutoModeChanged(enabled: Boolean) {
        autoMode = enabled
        updateNotification()
    }

    override fun onBindTargetRequested() {
        val target = actionExecutor.bindForegroundTarget()
        if (target != null) {
            overlay?.showScanning()
            overlay?.update("● CIBLE LIÉE", "Package: $target")
        } else {
            overlay?.showError("Aucune app en premier plan")
        }
    }

    override fun onStopRequested() {
        stopSelf()
    }

    override fun onMapCalibrationChanged(cx: Float, cy: Float, halfW: Float, halfH: Float) {
        mapCx = cx.coerceIn(0.03f, 0.45f)
        mapCy = cy.coerceIn(0.03f, 0.45f)
        mapHalfW = halfW.coerceIn(0.035f, 0.30f)
        mapHalfH = halfH.coerceIn(0.05f, 0.35f)
        stableMapThreats = emptyList()
        lastMapThreatSeenAt = 0L
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(KEY_CX, mapCx)
            .putFloat(KEY_CY, mapCy)
            .putFloat(KEY_HW, mapHalfW)
            .putFloat(KEY_HH, mapHalfH)
            .apply()
        overlay?.setMapRegion(mapCx, mapCy, mapHalfW, mapHalfH)
        overlay?.showScanning()
    }

    // ============================================================
    // FOREGROUND
    // ============================================================

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun readProjectionIntent(intent: Intent?): Intent? {
        if (intent == null) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
        }
    }

    // ============================================================
    // PROJECTION
    // ============================================================

    private fun startProjection(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = manager.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("MediaProjection unavailable")

        mediaProjection = projection
        projection.registerCallback(projectionCallback, mainHandler)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(320)
        val height = metrics.heightPixels.coerceAtLeast(320)
        val density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        reader.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                receivedFrames++
                if (!analysisEnabled) return@setOnImageAvailableListener

                val now = System.currentTimeMillis()
                if (now - lastSampleAt < SAMPLE_INTERVAL_MS) return@setOnImageAvailableListener
                lastSampleAt = now
                sampledFrames++

                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                val signature = quickSignature(
                    plane.buffer,
                    image.width,
                    image.height,
                    plane.pixelStride,
                    plane.rowStride
                )
                val changed = signature != lastSignature
                if (changed) {
                    lastSignature = signature
                    lastChangeAt = now
                }

                val detections = detectVisualCues(
                    plane.buffer,
                    image.width,
                    image.height,
                    plane.pixelStride,
                    plane.rowStride
                )
                val rawMapThreats = analyzeMinimapThreats(
                    plane.buffer, image.width, image.height, plane.pixelStride, plane.rowStride
                )
                val mapThreats = stabilizeMapThreats(rawMapThreats, now)
                val mapGuide = mapThreats.firstOrNull()

                val primaryCue = detections.maxByOrNull { it.score }
                val gameState = GameState(
                    timestampMs = now,
                    frameChanged = changed,
                    visualCueCount = detections.size,
                    strongestCueScore = primaryCue?.score ?: 0,
                    targetX = primaryCue?.x,
                    targetY = primaryCue?.y,
                    minimapDirection = mapGuide?.direction,
                    minimapDistance = mapGuide?.distance,
                    minimapDx = mapGuide?.dx,
                    minimapDy = mapGuide?.dy
                )
                val decision = decisionEngine.decide(gameState)
                lastDecision = decision
                runCatching { experimentLogger.log(gameState, decision) }

                overlay?.showMapThreats(mapThreats.mapIndexed { index, threat ->
                    OverlayController.MapThreatIndicator(
                        dx = threat.dx,
                        dy = threat.dy,
                        mapDx = threat.mapDx,
                        mapDy = threat.mapDy,
                        direction = threat.direction,
                        distance = threat.distance,
                        confidence = threat.confidence,
                        index = index + 1
                    )
                })

                // ============================================================
                // ===== BOUCLE PRINCIPALE AVEC PANEL =====
                // ============================================================

                // 1. Si ESP est activé, afficher les menaces sur l'overlay
                if (panelEspActive && mapThreats.isNotEmpty()) {
                    overlay?.showMapThreats(mapThreats.mapIndexed { index, threat ->
                        OverlayController.MapThreatIndicator(
                            dx = threat.dx,
                            dy = threat.dy,
                            mapDx = threat.mapDx,
                            mapDy = threat.mapDy,
                            direction = threat.direction,
                            distance = threat.distance,
                            confidence = threat.confidence,
                            index = index + 1
                        )
                    })
                }

                // 2. Si le panel est activé ET autoMode est ON
                if (panelActive && autoMode) {
                    
                    // 2a. Vérifier si une cible est visible
                    if (primaryCue != null) {
                        val x = primaryCue.x
                        val y = primaryCue.y
                        
                        // Vérifier si la cible est dans le FOV
                        val dx = x - 0.5f
                        val dy = y - 0.52f
                        val distance = sqrt(dx * dx + dy * dy)
                        val inFov = distance <= fovRadius
                        
                        // Appliquer la correction de visée selon la sensibilité
                        val aimDx = dx * aimSensitivity * smoothness
                        val aimDy = dy * aimSensitivity * smoothness
                        
                        // Vérifier si la cible est alignée (seuil adapté)
                        val aligned = abs(x - 0.5f) <= 0.085f && abs(y - 0.52f) <= 0.17f
                        
                        // ===== AIMBOT =====
                        if (panelAimbotActive && inFov) {
                            // Si aligné → tirer
                            if (aligned) {
                                // ===== AUTO FIRE =====
                                if (panelAutoFireActive) {
                                    val now2 = SystemClock.uptimeMillis()
                                    // Anti-spam de tir
                                    if (now2 - lastShotTime > Humanizer.jitter(220L, 0.4f)) {
                                        val fired = actionExecutor.fire()
                                        if (fired) {
                                            shots++
                                            // Simuler un hit (70% de chance de toucher si aligné)
                                            if (Humanizer.shouldFire(0.85f)) {
                                                hits++
                                                if (Random.nextFloat() < 0.6f) kills++
                                            }
                                            lastShotTime = now2
                                        }
                                    }
                                }
                            } else {
                                // Tourner la caméra vers la cible (avec correction)
                                actionExecutor.rotate(aimDx, aimDy)
                            }
                        } else {
                            // Si aimbot désactivé mais auto fire activé, on suit juste la cible
                            if (panelAutoFireActive && aligned) {
                                val now2 = SystemClock.uptimeMillis()
                                if (now2 - lastShotTime > Humanizer.jitter(250L, 0.4f)) {
                                    val fired = actionExecutor.fire()
                                    if (fired) {
                                        shots++
                                        if (Humanizer.shouldFire(0.80f)) {
                                            hits++
                                            if (Random.nextFloat() < 0.5f) kills++
                                        }
                                        lastShotTime = now2
                                    }
                                }
                            }
                        }
                    }
                    
                    // 2b. Si une menace est sur la mini-map et pas de cible visible
                    if (primaryCue == null && mapGuide != null && panelAimbotActive) {
                        // Tourner vers la direction de la mini-map
                        val mapDx = mapGuide.mapDx * 0.5f
                        val mapDy = mapGuide.mapDy * 0.5f
                        actionExecutor.rotate(mapDx, mapDy)
                    }
                }

                // ============================================================
                // ===== GUIDAGE VISUAL (mode observateur) =====
                // ============================================================

                // Affichage du guide visuel dans l'overlay (mode observateur)
                if (primaryCue != null) {
                    val dx = ((primaryCue.x - 0.5f) * 2f).coerceIn(-1f, 1f)
                    val dy = ((primaryCue.y - 0.5f) * 2f).coerceIn(-1f, 1f)
                    val aligned = abs(primaryCue.x - 0.5f) <= 0.095f &&
                        abs(primaryCue.y - 0.52f) <= 0.19f
                    
                    if (aligned) {
                        overlay?.showControlGuide(OverlayController.ControlAction.FIRE)
                    } else if (panelAimbotActive) {
                        // Montrer la direction de visée si aimbot actif
                        overlay?.showControlGuide(OverlayController.ControlAction.SWIPE, dx, dy)
                    } else {
                        overlay?.showControlGuide(OverlayController.ControlAction.SWIPE, dx, dy)
                    }
                } else if (mapGuide != null) {
                    overlay?.showControlGuide(
                        OverlayController.ControlAction.SWIPE,
                        mapGuide.dx,
                        mapGuide.dy
                    )
                } else {
                    overlay?.clearControlGuide()
                }

                overlay?.clearTargetGuide()
                overlay?.clearRotationHint()
                overlay?.updateMarkers(emptyList())

                // ============================================================
                // ===== MISE À JOUR UI =====
                // ============================================================

                if (now - lastUiUpdate >= UI_INTERVAL_MS) {
                    lastUiUpdate = now
                    val state = decisionEngine.humanReadable(decision)
                    val panelStatus = if (panelActive) "🔓 PANEL ON" else "🔒 PANEL OFF"
                    val advice = buildString {
                        append("$panelStatus | ")
                        if (panelAimbotActive) append("🎯 ")
                        if (panelAutoFireActive) append("🔥 ")
                        if (panelAntiBanActive) append("🛡️ ")
                        if (panelEspActive) append("👁️ ")
                        append("\n")
                        append(decision.reason)
                        append("\nÉchantillon #")
                        append(sampledFrames)
                        append(" • STATS: K$kills S$shots H$hits")
                        if (primaryCue != null) {
                            val dist = sqrt(
                                (primaryCue.x - 0.5f) * (primaryCue.x - 0.5f) +
                                (primaryCue.y - 0.52f) * (primaryCue.y - 0.52f)
                            )
                            append("\nDistance: ${String.format("%.2f", dist)}")
                        }
                    }
                    overlay?.update(state, advice)
                }
            } catch (t: Throwable) {
                t.printStackTrace()
            } finally {
                image.close()
            }
        }, mainHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "BoltFireScreenCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            mainHandler
        ) ?: throw IllegalStateException("VirtualDisplay unavailable")

        overlay?.update(
            "● BOT EXPÉRIMENTAL PRÊT",
            "Capture connectée.\nPanel ${if (panelActive) "ACTIF" else "INACTIF"}"
        )
        updateNotification()
    }

    // ============================================================
    // DONNÉES INTERNES
    // ============================================================

    private data class VisualCue(val x: Float, val y: Float, val score: Int)

    private data class MapThreat(
        val direction: String,
        val distance: String,
        val dx: Float,
        val dy: Float,
        val mapDx: Float,
        val mapDy: Float,
        val confidence: Int,
        val score: Int
    )

    private data class HeadingEstimate(
        val dx: Float,
        val dy: Float,
        val confidence: Int
    )

    private data class ActionHint(val text: String, val x: Float, val y: Float)

    private fun actionHintFor(x: Float, y: Float): ActionHint {
        val horizontal = when {
            x < 0.35f -> "GAUCHE"
            x > 0.65f -> "DROITE"
            else -> "CENTRE"
        }
        return when {
            horizontal == "DROITE" -> ActionHint("TOURNE À DROITE → TIRER", 0.78f, 0.64f)
            horizontal == "GAUCHE" -> ActionHint("TOURNE À GAUCHE → DÉPLACER", 0.34f, 0.68f)
            y < 0.38f -> ActionHint("VISE EN HAUT → TIRER", 0.66f, 0.52f)
            else -> ActionHint("VISE → TIRER", 0.76f, 0.64f)
        }
    }

    // ============================================================
    // MINIMAP ANALYSIS
    // ============================================================

    private fun analyzeMinimapThreats(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int
    ): List<MapThreat> {
        val cxPx = (mapCx * width).toInt().coerceIn(0, width - 1)
        val cyPx = (mapCy * height).toInt().coerceIn(0, height - 1)
        val halfWPx = (mapHalfW * width).toInt().coerceAtLeast(40)
        val halfHPx = (mapHalfH * height).toInt().coerceAtLeast(40)
        val ox = (cxPx - halfWPx).coerceIn(0, width - 1)
        val oy = (cyPx - halfHPx).coerceIn(0, height - 1)
        val right = (cxPx + halfWPx).coerceIn(1, width)
        val bottom = (cyPx + halfHPx).coerceIn(1, height)
        val mw = (right - ox).coerceAtLeast(60)
        val mh = (bottom - oy).coerceAtLeast(60)

        val gridW = 64
        val gridH = 64
        val active = Array(gridH) { BooleanArray(gridW) }
        val heading = estimatePlayerHeading(buffer, width, height, pixelStride, rowStride, ox, oy, mw, mh)

        fun threatColourAt(x: Int, y: Int): Boolean {
            val off = y * rowStride + x * pixelStride
            if (off < 0 || off + 3 >= buffer.limit()) return false
            val r = buffer.get(off).toInt() and 255
            val g = buffer.get(off + 1).toInt() and 255
            val b = buffer.get(off + 2).toInt() and 255
            val red = r >= 145 && r >= g + 42 && r >= b + 48 && (r - minOf(g, b)) >= 58
            val orange = r >= 170 && g in 45..175 && b <= 125 && r >= g + 32
            return red || orange
        }

        val probeX = maxOf(1, mw / 260)
        val probeY = maxOf(1, mh / 260)
        for (gy in 0 until gridH) {
            for (gx in 0 until gridW) {
                val u = (gx + 0.5f) / gridW
                val v = (gy + 0.5f) / gridH
                val mdx = u - 0.5f
                val mdy = v - 0.5f
                val radialSq = mdx * mdx + mdy * mdy
                if (radialSq < 0.0045f) continue
                if (u < 0.025f || u > 0.975f || v < 0.025f || v > 0.975f) continue

                val px = ox + (u * mw).toInt()
                val py = oy + (v * mh).toInt()
                var hits = 0
                for (sy in -1..1) {
                    for (sx in -1..1) {
                        val x = (px + sx * probeX).coerceIn(0, width - 1)
                        val y = (py + sy * probeY).coerceIn(0, height - 1)
                        if (threatColourAt(x, y)) hits++
                    }
                }
                active[gy][gx] = hits >= 1
            }
        }

        val visited = Array(gridH) { BooleanArray(gridW) }
        val dirs = arrayOf(
            intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1),
            intArrayOf(1, 1), intArrayOf(-1, -1), intArrayOf(1, -1), intArrayOf(-1, 1)
        )
        val threats = mutableListOf<MapThreat>()

        for (sy in 0 until gridH) {
            for (sx in 0 until gridW) {
                if (!active[sy][sx] || visited[sy][sx]) continue
                val queue = ArrayDeque<Pair<Int, Int>>()
                queue.add(sx to sy)
                visited[sy][sx] = true
                var cells = 0
                var sumU = 0f
                var sumV = 0f

                while (queue.isNotEmpty()) {
                    val (x, y) = queue.removeFirst()
                    cells++
                    sumU += (x + 0.5f) / gridW
                    sumV += (y + 0.5f) / gridH
                    for (dir in dirs) {
                        val nx = x + dir[0]
                        val ny = y + dir[1]
                        if (nx in 0 until gridW && ny in 0 until gridH && active[ny][nx] && !visited[ny][nx]) {
                            visited[ny][nx] = true
                            queue.add(nx to ny)
                        }
                    }
                }

                if (cells !in 1..72) continue
                val u = sumU / cells
                val v = sumV / cells
                val mapDx = ((u - 0.5f) * 2f).coerceIn(-1f, 1f)
                val mapDy = ((v - 0.5f) * 2f).coerceIn(-1f, 1f)
                val radial = sqrt(mapDx * mapDx + mapDy * mapDy)
                if (radial < 0.10f || radial > 1.36f) continue

                val rightX = -heading.dy
                val rightY = heading.dx
                val relDx = (mapDx * rightX + mapDy * rightY).coerceIn(-1f, 1f)
                val forward = mapDx * heading.dx + mapDy * heading.dy
                val relDy = (-forward).coerceIn(-1f, 1f)

                val direction = relativeDirection(relDx, relDy)
                val distance = when {
                    radial < 0.34f -> "PROCHE"
                    radial < 0.66f -> "MOYEN"
                    else -> "LOIN"
                }
                val confidence = (52 + cells * 5 + heading.confidence / 10).coerceIn(55, 97)
                val compactBonus = when (cells) {
                    in 2..18 -> 18
                    1 -> 8
                    else -> 0
                }
                val score = compactBonus + cells.coerceAtMost(18) * 7 + ((1.30f - radial.coerceAtMost(1.30f)) * 14f).toInt()
                threats.add(MapThreat(direction, distance, relDx, relDy, mapDx, mapDy, confidence, score))
            }
        }

        val sorted = threats.sortedByDescending { it.score }
        val kept = mutableListOf<MapThreat>()
        for (candidate in sorted) {
            val duplicate = kept.any { old ->
                val dx = old.mapDx - candidate.mapDx
                val dy = old.mapDy - candidate.mapDy
                dx * dx + dy * dy < 0.018f
            }
            if (!duplicate) kept.add(candidate)
            if (kept.size == 3) break
        }
        return kept
    }

    private fun stabilizeMapThreats(raw: List<MapThreat>, now: Long): List<MapThreat> {
        if (raw.isEmpty()) {
            if (now - lastMapThreatSeenAt <= 750L) return stableMapThreats
            stableMapThreats = emptyList()
            return emptyList()
        }

        lastMapThreatSeenAt = now
        val previous = stableMapThreats.toMutableList()
        val smoothed = raw.map { threat ->
            val match = previous.minByOrNull { old ->
                val ddx = old.dx - threat.dx
                val ddy = old.dy - threat.dy
                ddx * ddx + ddy * ddy
            }
            if (match != null) {
                val ddx = match.dx - threat.dx
                val ddy = match.dy - threat.dy
                if (ddx * ddx + ddy * ddy < 0.10f) {
                    val dx = match.dx * 0.42f + threat.dx * 0.58f
                    val dy = match.dy * 0.42f + threat.dy * 0.58f
                    val mapDx = match.mapDx * 0.42f + threat.mapDx * 0.58f
                    val mapDy = match.mapDy * 0.42f + threat.mapDy * 0.58f
                    threat.copy(
                        dx = dx,
                        dy = dy,
                        mapDx = mapDx,
                        mapDy = mapDy,
                        direction = relativeDirection(dx, dy)
                    )
                } else threat
            } else threat
        }
        stableMapThreats = smoothed.sortedByDescending { it.score }.take(3)
        return stableMapThreats
    }

    private fun estimatePlayerHeading(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int,
        ox: Int,
        oy: Int,
        mw: Int,
        mh: Int
    ): HeadingEstimate {
        var sumDx = 0f
        var sumDy = 0f
        var weight = 0f

        for (gy in -9..9) {
            for (gx in -9..9) {
                val u = 0.5f + gx / 70f
                val v = 0.5f + gy / 70f
                val x = (ox + u * mw).toInt().coerceIn(0, width - 1)
                val y = (oy + v * mh).toInt().coerceIn(0, height - 1)
                val off = y * rowStride + x * pixelStride
                if (off < 0 || off + 3 >= buffer.limit()) continue
                val r = buffer.get(off).toInt() and 255
                val g = buffer.get(off + 1).toInt() and 255
                val b = buffer.get(off + 2).toInt() and 255
                val cyanBlue = b >= 135 && g >= 95 && b >= r + 18 && (b + g) >= 270
                if (!cyanBlue) continue
                val localDx = u - 0.5f
                val localDy = v - 0.5f
                val pixelWeight = ((b + g - r) / 255f).coerceAtLeast(0.4f)
                sumDx += localDx * pixelWeight
                sumDy += localDy * pixelWeight
                weight += pixelWeight
            }
        }

        if (weight < 1.2f) return HeadingEstimate(0f, -1f, 0)
        val dx = sumDx / weight
        val dy = sumDy / weight
        val mag = sqrt(dx * dx + dy * dy)
        if (mag < 0.015f) return HeadingEstimate(0f, -1f, 0)
        return HeadingEstimate(
            dx = dx / mag,
            dy = dy / mag,
            confidence = (weight * 10f).toInt().coerceIn(10, 80)
        )
    }

    private fun relativeDirection(dx: Float, dy: Float): String {
        val angle = Math.toDegrees(atan2(dx.toDouble(), (-dy).toDouble()))
        val normalized = (angle + 360.0) % 360.0
        return when {
            normalized < 22.5 || normalized >= 337.5 -> "DEVANT"
            normalized < 67.5 -> "AVANT-DROITE"
            normalized < 112.5 -> "DROITE"
            normalized < 157.5 -> "ARRIÈRE-DROITE"
            normalized < 202.5 -> "ARRIÈRE"
            normalized < 247.5 -> "ARRIÈRE-GAUCHE"
            normalized < 292.5 -> "GAUCHE"
            else -> "AVANT-GAUCHE"
        }
    }

    // ============================================================
    // VISUAL CUES DETECTION
    // ============================================================

    private fun detectVisualCues(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int
    ): List<VisualCue> {
        val gridW = 32
        val gridH = 18
        val active = Array(gridH) { BooleanArray(gridW) }

        fun isRedAt(x: Int, y: Int): Boolean {
            val offset = y * rowStride + x * pixelStride
            if (offset < 0 || offset + 3 >= buffer.limit()) return false
            val r = buffer.get(offset).toInt() and 0xff
            val g = buffer.get(offset + 1).toInt() and 0xff
            val b = buffer.get(offset + 2).toInt() and 0xff
            val max = maxOf(r, g, b)
            val min = minOf(r, g, b)
            return r >= 155 && r >= g + 55 && r >= b + 55 && max - min >= 80
        }

        for (gy in 0 until gridH) {
            for (gx in 0 until gridW) {
                val cx = ((gx + 0.5f) * width / gridW).toInt().coerceIn(0, width - 1)
                val cy = ((gy + 0.5f) * height / gridH).toInt().coerceIn(0, height - 1)

                val nx = cx.toFloat() / width
                val ny = cy.toFloat() / height
                if ((nx < 0.22f && ny < 0.25f) || ny > 0.82f || (nx > 0.82f && ny < 0.20f)) continue

                var hits = 0
                for (oy in -1..1) {
                    for (ox in -1..1) {
                        val x = (cx + ox * maxOf(1, width / 220)).coerceIn(0, width - 1)
                        val y = (cy + oy * maxOf(1, height / 120)).coerceIn(0, height - 1)
                        if (isRedAt(x, y)) hits++
                    }
                }
                active[gy][gx] = hits >= 3
            }
        }

        val visited = Array(gridH) { BooleanArray(gridW) }
        val result = mutableListOf<VisualCue>()
        val dirs = arrayOf(
            intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1),
            intArrayOf(1, 1), intArrayOf(-1, -1), intArrayOf(1, -1), intArrayOf(-1, 1)
        )

        for (sy in 0 until gridH) {
            for (sx in 0 until gridW) {
                if (!active[sy][sx] || visited[sy][sx]) continue
                val queue = ArrayDeque<Pair<Int, Int>>()
                queue.add(sx to sy)
                visited[sy][sx] = true
                var count = 0
                var sumX = 0f
                var sumY = 0f

                while (queue.isNotEmpty()) {
                    val (x, y) = queue.removeFirst()
                    count++
                    sumX += (x + 0.5f) / gridW
                    sumY += (y + 0.5f) / gridH
                    for (d in dirs) {
                        val nx = x + d[0]
                        val ny = y + d[1]
                        if (nx in 0 until gridW && ny in 0 until gridH && active[ny][nx] && !visited[ny][nx]) {
                            visited[ny][nx] = true
                            queue.add(nx to ny)
                        }
                    }
                }

                if (count >= 2) {
                    result.add(VisualCue(sumX / count, sumY / count, count))
                }
            }
        }

        return result.sortedByDescending { it.score }.take(3)
    }

    // ============================================================
    // SIGNATURE
    // ============================================================

    private fun quickSignature(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int
    ): Long {
        val sampleW = 12
        val sampleH = 12
        var hash = 1469598103934665603L
        for (sy in 0 until sampleH) {
            val y = (sy * height) / sampleH
            for (sx in 0 until sampleW) {
                val x = (sx * width) / sampleW
                val offset = y * rowStride + x * pixelStride
                if (offset < 0 || offset + 3 >= buffer.limit()) continue
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                hash = (hash xor (r * 31L + g * 17L + b * 13L)) * 1099511628211L
            }
        }
        return hash
    }

    // ============================================================
    // NOTIFICATIONS
    // ============================================================

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BoltFire Lab",
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Capture écran et décisions expérimentales BoltFire"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun actionPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, ScreenAnalysisService::class.java).setAction(action)
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("BoltFire Bot V15")
            .setContentText(if (analysisEnabled) if (autoMode) "Bot autonome actif" else "Guidage visuel actif" else "Analyse en pause")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    null,
                    "Afficher",
                    actionPendingIntent(ACTION_SHOW, 10)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    null,
                    "Arrêter BoltFire",
                    actionPendingIntent(ACTION_STOP, 11)
                ).build()
            )
            .build()

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    // ============================================================
    // STOP
    // ============================================================

    private fun stopProjection() {
        if (stopping) return
        stopping = true
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null
        mediaProjection?.unregisterCallback(projectionCallback)
        mediaProjection?.stop()
        mediaProjection = null
        overlay?.clearMarkers()
        overlay?.hide()
        overlay = null
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopProjection()
            stopSelf()
        }
    }

    override fun onDestroy() {
        stopProjection()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}