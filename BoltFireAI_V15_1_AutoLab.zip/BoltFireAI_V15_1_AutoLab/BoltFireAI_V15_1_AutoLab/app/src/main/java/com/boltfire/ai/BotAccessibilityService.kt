package com.boltfire.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.max

/**
 * Gesture bridge for the user's explicitly bound offline test game.
 * The service never chooses the target package by itself: the user binds the
 * currently foreground application from the BoltFire overlay.
 */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile private var instance: BotAccessibilityService? = null
        @Volatile private var foregroundPackage: String? = null

        fun isConnected(): Boolean = instance != null
        fun currentForegroundPackage(): String? = foregroundPackage

        fun tapNormalized(x: Float, y: Float, durationMs: Long = 55L): Boolean {
            return instance?.tap(x, y, durationMs) ?: false
        }

        fun swipeNormalized(
            startX: Float,
            startY: Float,
            endX: Float,
            endY: Float,
            durationMs: Long = 130L
        ): Boolean {
            return instance?.swipe(startX, startY, endX, endY, durationMs) ?: false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return
        foregroundPackage = pkg
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun tap(nx: Float, ny: Float, durationMs: Long): Boolean {
        val metrics = resources.displayMetrics
        val x = nx.coerceIn(0f, 1f) * metrics.widthPixels
        val y = ny.coerceIn(0f, 1f) * metrics.heightPixels
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, max(20L, durationMs))
        return dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            Handler(Looper.getMainLooper())
        )
    }

    private fun swipe(
        nsx: Float,
        nsy: Float,
        nex: Float,
        ney: Float,
        durationMs: Long
    ): Boolean {
        val metrics = resources.displayMetrics
        val sx = nsx.coerceIn(0f, 1f) * metrics.widthPixels
        val sy = nsy.coerceIn(0f, 1f) * metrics.heightPixels
        val ex = nex.coerceIn(0f, 1f) * metrics.widthPixels
        val ey = ney.coerceIn(0f, 1f) * metrics.heightPixels
        val path = Path().apply {
            moveTo(sx, sy)
            lineTo(ex, ey)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, max(45L, durationMs))
        return dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            Handler(Looper.getMainLooper())
        )
    }
}
