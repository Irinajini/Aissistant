package com.boltfire.ai

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.atan2

class PanelActivity : AppCompatActivity(), PanelManager.PanelStateListener {

    private lateinit var mainContainer: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var handler: Handler

    // Références des toggles
    private var aimbotToggleContainer: LinearLayout? = null
    private var autoFireToggleContainer: LinearLayout? = null
    private var antiBanToggleContainer: LinearLayout? = null
    private var espToggleContainer: LinearLayout? = null

    // Vues des stats
    private var killsView: TextView? = null
    private var shotsView: TextView? = null
    private var accuracyView: TextView? = null
    private var timeView: TextView? = null

    // Compteurs stats
    private var kills = 0
    private var shots = 0
    private var hits = 0
    private var startTime = System.currentTimeMillis()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        PanelManager.init(this)
        PanelManager.addListener(this)

        handler = Handler(Looper.getMainLooper())
        setupUI()
        updateUIFromState()
    }

    override fun onDestroy() {
        super.onDestroy()
        PanelManager.removeListener(this)
        handler.removeCallbacksAndMessages(null)
    }

    // ============================================================
    // UI SETUP
    // ============================================================

    private fun setupUI() {
        val scrollView = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0A0A0F"))
            isVerticalScrollBarEnabled = false
        }

        mainContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        mainContainer.addView(createHeader())
        mainContainer.addView(createStatusBar())
        mainContainer.addView(createFeaturesGrid())
        mainContainer.addView(createSectionHeader("🎯 AIMBOT"))
        mainContainer.addView(createAimbotToggle())
        mainContainer.addView(createSectionHeader("👁️ ESP / WALLHACK"))
        mainContainer.addView(createEspToggle())
        mainContainer.addView(createSectionHeader("🔥 AUTO FIRE"))
        mainContainer.addView(createAutoFireToggle())
        mainContainer.addView(createSectionHeader("🛡️ ANTIBAN"))
        mainContainer.addView(createAntiBanToggle())
        mainContainer.addView(createSectionHeader("⚙️ PARAMÈTRES"))
        mainContainer.addView(createSettingsSection())
        mainContainer.addView(createStatsCard())
        mainContainer.addView(createActionButtons())
        mainContainer.addView(createServiceControl())

        scrollView.addView(mainContainer)
        setContentView(scrollView)
    }

    // ============================================================
    // HEADER
    // ============================================================

    private fun createHeader(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(16))

            val icon = TextView(this@PanelActivity).apply {
                text = "⚡"
                textSize = 32f
                setPadding(dp(8), 0, dp(8), 0)
            }
            addView(icon)

            val title = TextView(this@PanelActivity).apply {
                text = "BoltFire FF Panel"
                textSize = 22f
                setTextColor(Color.WHITE)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            addView(title)

            val version = TextView(this@PanelActivity).apply {
                text = "v2.0"
                textSize = 12f
                setTextColor(Color.parseColor("#8888AA"))
                setPadding(dp(16), 0, 0, 0)
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            addView(version)

            val backBtn = TextView(this@PanelActivity).apply {
                text = "✕"
                textSize = 18f
                setTextColor(Color.parseColor("#FF4444"))
                setPadding(dp(16), dp(4), dp(4), dp(4))
                setOnClickListener { finish() }
            }
            addView(backBtn)
        }
    }

    // ============================================================
    // STATUS BAR
    // ============================================================

    private fun createStatusBar(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = createRoundedDrawable(Color.parseColor("#1A1A2E"), dp(12))

            statusDot = View(this@PanelActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(10), dp(10))
                background = createRoundedDrawable(Color.parseColor("#FF4444"), dp(10))
            }
            addView(statusDot)

            statusText = TextView(this@PanelActivity).apply {
                text = "Panel INACTIF"
                textSize = 14f
                setTextColor(Color.parseColor("#8888AA"))
                setPadding(dp(12), 0, 0, 0)
            }
            addView(statusText)

            startStatusAnimation()
        }
    }

    private fun startStatusAnimation() {
        val animator = ValueAnimator.ofFloat(0.3f, 1.0f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                statusDot.alpha = it.animatedValue as Float
            }
        }
        animator.start()
    }

    private fun updateStatus(message: String, isActive: Boolean) {
        statusText.text = message
        if (isActive) {
            statusDot.setBackgroundColor(Color.parseColor("#00FF88"))
            statusText.setTextColor(Color.parseColor("#00FF88"))
        } else {
            statusDot.setBackgroundColor(Color.parseColor("#FF4444"))
            statusText.setTextColor(Color.parseColor("#FF4444"))
        }
    }

    // ============================================================
    // FEATURES GRID
    // ============================================================

    private fun createFeaturesGrid(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(16))
            tag = "features_grid"

            val features = listOf(
                Triple("🎯", "Aimbot", PanelManager.state.aimbotEnabled),
                Triple("👁️", "ESP", PanelManager.state.espEnabled),
                Triple("🔥", "Auto Fire", PanelManager.state.autoFireEnabled),
                Triple("🛡️", "AntiBan", PanelManager.state.antiBanEnabled)
            )

            features.forEachIndexed { index, (icon, label, active) ->
                val card = createFeatureCard(icon, label, active)
                addView(card)
                if (index < features.size - 1) {
                    val spacer = View(this@PanelActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(8), 1)
                    }
                    addView(spacer)
                }
            }
        }
    }

    private fun createFeatureCard(icon: String, label: String, active: Boolean): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            background = createRoundedDrawable(
                if (active) Color.parseColor("#1A2E1A") else Color.parseColor("#1A1A2E"),
                dp(10)
            )

            val iconView = TextView(this@PanelActivity).apply {
                text = icon
                textSize = 20f
            }
            addView(iconView)

            val labelView = TextView(this@PanelActivity).apply {
                text = label
                textSize = 10f
                setTextColor(if (active) Color.parseColor("#00FF88") else Color.parseColor("#666688"))
                setPadding(0, dp(4), 0, 0)
            }
            addView(labelView)
        }
    }

    // ============================================================
    // SECTION HEADER
    // ============================================================

    private fun createSectionHeader(title: String): View {
        return TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.parseColor("#AAAAEE"))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(16), 0, dp(8))
        }
    }

    // ============================================================
    // TOGGLES
    // ============================================================

    private fun createAimbotToggle(): View {
        val container = createToggleButton(
            "Aimbot automatique",
            "Vise automatiquement les ennemis détectés",
            PanelManager.state.aimbotEnabled
        ) { isChecked ->
            PanelManager.toggleAimbot(isChecked)
        }
        aimbotToggleContainer = container
        return container
    }

    private fun createEspToggle(): View {
        val container = createToggleButton(
            "ESP / Wallhack",
            "Affiche les ennemis à travers les murs",
            PanelManager.state.espEnabled
        ) { isChecked ->
            PanelManager.toggleEsp(isChecked)
        }
        espToggleContainer = container
        return container
    }

    private fun createAutoFireToggle(): View {
        val container = createToggleButton(
            "Auto Fire",
            "Tire automatiquement quand la cible est alignée",
            PanelManager.state.autoFireEnabled
        ) { isChecked ->
            PanelManager.toggleAutoFire(isChecked)
        }
        autoFireToggleContainer = container
        return container
    }

    private fun createAntiBanToggle(): View {
        val container = createToggleButton(
            "AntiBan System",
            "Protection contre la détection (mode furtif)",
            PanelManager.state.antiBanEnabled
        ) { isChecked ->
            PanelManager.toggleAntiBan(isChecked)
        }
        antiBanToggleContainer = container
        return container
    }

    // ============================================================
    // TOGGLE BUTTON GENERIQUE
    // ============================================================

    private fun createToggleButton(
        title: String,
        subtitle: String,
        initialValue: Boolean,
        onToggle: (Boolean) -> Unit
    ): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = createRoundedDrawable(Color.parseColor("#111122"), dp(10))

            val textContainer = LinearLayout(this@PanelActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val titleView = TextView(this@PanelActivity).apply {
                text = title
                textSize = 15f
                setTextColor(Color.WHITE)
            }
            textContainer.addView(titleView)

            val subtitleView = TextView(this@PanelActivity).apply {
                text = subtitle
                textSize = 11f
                setTextColor(Color.parseColor("#666688"))
            }
            textContainer.addView(subtitleView)

            addView(textContainer)

            val toggle = createSwitch(initialValue, onToggle)
            addView(toggle)
        }
    }

    private fun createSwitch(initialValue: Boolean, onToggle: (Boolean) -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = createRoundedDrawable(
                if (initialValue) Color.parseColor("#00FF88") else Color.parseColor("#333355"),
                dp(16)
            )
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(28))
            isClickable = true
            isFocusable = true
            var isChecked = initialValue

            val indicator = View(this@PanelActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
                background = createRoundedDrawable(Color.WHITE, dp(20))
                translationX = if (isChecked) dp(14) else dp(-14)
            }
            addView(indicator)

            setOnClickListener {
                isChecked = !isChecked
                indicator.animate()
                    .translationX(if (isChecked) dp(14) else dp(-14))
                    .setDuration(250)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()

                background = createRoundedDrawable(
                    if (isChecked) Color.parseColor("#00FF88") else Color.parseColor("#333355"),
                    dp(16)
                )

                onToggle(isChecked)
            }
        }
    }

    // ============================================================
    // PARAMÈTRES
    // ============================================================

    private fun createSettingsSection(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = createRoundedDrawable(Color.parseColor("#111122"), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, dp(8), 0, dp(8))
            }

            val sensRow = LinearLayout(this@PanelActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val sensLabel = TextView(this@PanelActivity).apply {
                text = "Sensibilité visée"
                textSize = 13f
                setTextColor(Color.parseColor("#AAAAAA"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            sensRow.addView(sensLabel)

            val sensValue = TextView(this@PanelActivity).apply {
                text = "${String.format("%.1f", PanelManager.state.aimSensitivity)}x"
                textSize = 13f
                setTextColor(Color.parseColor("#00FF88"))
            }
            sensRow.addView(sensValue)
            addView(sensRow)

            val fovRow = LinearLayout(this@PanelActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val fovLabel = TextView(this@PanelActivity).apply {
                text = "FOV (champ de visée)"
                textSize = 13f
                setTextColor(Color.parseColor("#AAAAAA"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            fovRow.addView(fovLabel)

            val fovValue = TextView(this@PanelActivity).apply {
                text = "${(PanelManager.state.fovRadius * 100).toInt()}%"
                textSize = 13f
                setTextColor(Color.parseColor("#FFAA44"))
            }
            fovRow.addView(fovValue)
            addView(fovRow)
        }
    }

    // ============================================================
    // STATS CARD
    // ============================================================

    private fun createStatsCard(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = createRoundedDrawable(Color.parseColor("#111122"), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, dp(16), 0, dp(16))
            }

            val title = TextView(this@PanelActivity).apply {
                text = "📊 STATISTIQUES"
                textSize = 14f
                setTextColor(Color.parseColor("#8888AA"))
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            addView(title)

            val statsGrid = LinearLayout(this@PanelActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(12), 0, 0)
            }

            // Création des cartes de stats avec références
            val killsCard = createStatCard("Kills", "0", "#FF4444")
            statsGrid.addView(killsCard)
            killsView = killsCard.findViewWithTag<TextView>("stat_value")

            val shotsCard = createStatCard("Tirs", "0", "#FFAA44")
            statsGrid.addView(shotsCard)
            shotsView = shotsCard.findViewWithTag<TextView>("stat_value")

            val accCard = createStatCard("Précision", "0%", "#44FF88")
            statsGrid.addView(accCard)
            accuracyView = accCard.findViewWithTag<TextView>("stat_value")

            val timeCard = createStatCard("Temps", "00:00", "#4488FF")
            statsGrid.addView(timeCard)
            timeView = timeCard.findViewWithTag<TextView>("stat_value")

            addView(statsGrid)
            startStatsUpdater()
        }
    }

    private fun createStatCard(label: String, value: String, color: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = createRoundedDrawable(Color.parseColor("#1A1A2E"), dp(8))

            val valueView = TextView(this@PanelActivity).apply {
                text = value
                textSize = 18f
                setTextColor(Color.parseColor(color))
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                tag = "stat_value"
            }
            addView(valueView)

            val labelView = TextView(this@PanelActivity).apply {
                text = label
                textSize = 10f
                setTextColor(Color.parseColor("#666688"))
            }
            addView(labelView)
        }
    }

    private fun startStatsUpdater() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                updateStats()
                handler.postDelayed(this, 2000)
            }
        }, 1000)
    }

    private fun updateStats() {
        val elapsed = (System.currentTimeMillis() - startTime) / 1000
        val minutes = elapsed / 60
        val seconds = elapsed % 60

        killsView?.text = "$kills"
        shotsView?.text = "$shots"
        
        val acc = if (shots > 0) (hits * 100 / shots) else 0
        accuracyView?.text = "${acc}%"
        
        timeView?.text = String.format("%02d:%02d", minutes, seconds)
    }

    // ============================================================
    // ACTION BUTTONS
    // ============================================================

    private fun createActionButtons(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))

            val activateButton = createActionButton("▶ ACTIVER", Color.parseColor("#00CC66")) {
                PanelManager.togglePanel(true)
                updateStatus("Panel ACTIF ✅", true)
                Toast.makeText(this@PanelActivity, "🔓 Panel activé", Toast.LENGTH_SHORT).show()
            }
            addView(activateButton)

            val spacer = View(this@PanelActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(16), 1)
            }
            addView(spacer)

            val stopButton = createActionButton("⏹ ARRÊTER", Color.parseColor("#CC4444")) {
                PanelManager.togglePanel(false)
                updateStatus("Panel INACTIF ❌", false)
                Toast.makeText(this@PanelActivity, "🔒 Panel désactivé", Toast.LENGTH_SHORT).show()
            }
            addView(stopButton)
        }
    }

    private fun createActionButton(
        text: String,
        color: Int,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(32), dp(14), dp(32), dp(14))
            setBackgroundColor(color)
            background = createRoundedDrawable(color, dp(10))
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
            setOnClickListener { onClick() }
        }
    }

    // ============================================================
    // SERVICE CONTROL
    // ============================================================

    private fun createServiceControl(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(16))

            val launchBtn = createActionButton("🚀 LANCER BOT", Color.parseColor("#4488FF")) {
                if (!Settings.canDrawOverlays(this@PanelActivity)) {
                    Toast.makeText(this@PanelActivity, "Autorisez l'overlay d'abord", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                    return@createActionButton
                }
                startActivity(Intent(this@PanelActivity, MainActivity::class.java))
                finish()
            }
            addView(launchBtn)
        }
    }

    // ============================================================
    // UTILS
    // ============================================================

    private fun createRoundedDrawable(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // ============================================================
    // PANEL STATE LISTENER
    // ============================================================

    override fun onStateChanged(state: PanelManager.PanelState) {
        updateUIFromState()
    }

    override fun onAimbotToggled(enabled: Boolean) {
        updateToggleUI(aimbotToggleContainer, enabled)
        Toast.makeText(this, if (enabled) "🎯 Aimbot activé" else "🎯 Aimbot désactivé", Toast.LENGTH_SHORT).show()
    }

    override fun onAutoFireToggled(enabled: Boolean) {
        updateToggleUI(autoFireToggleContainer, enabled)
        Toast.makeText(this, if (enabled) "🔥 Auto Fire activé" else "🔥 Auto Fire désactivé", Toast.LENGTH_SHORT).show()
    }

    override fun onAntiBanToggled(enabled: Boolean) {
        updateToggleUI(antiBanToggleContainer, enabled)
        Toast.makeText(this, if (enabled) "🛡️ AntiBan activé" else "🛡️ AntiBan désactivé", Toast.LENGTH_SHORT).show()
    }

    override fun onEspToggled(enabled: Boolean) {
        updateToggleUI(espToggleContainer, enabled)
        Toast.makeText(this, if (enabled) "👁️ ESP activé" else "👁️ ESP désactivé", Toast.LENGTH_SHORT).show()
    }

    private fun updateUIFromState() {
        val state = PanelManager.state
        updateStatus(
            if (state.panelActive) "Panel ACTIF ✅" else "Panel INACTIF ❌",
            state.panelActive
        )
        updateToggleUI(aimbotToggleContainer, state.aimbotEnabled)
        updateToggleUI(autoFireToggleContainer, state.autoFireEnabled)
        updateToggleUI(antiBanToggleContainer, state.antiBanEnabled)
        updateToggleUI(espToggleContainer, state.espEnabled)
        updateFeaturesGrid()
    }

    private fun updateToggleUI(container: LinearLayout?, enabled: Boolean) {
        container?.let {
            val bg = createRoundedDrawable(
                if (enabled) Color.parseColor("#00FF88") else Color.parseColor("#333355"),
                dp(16)
            )
            it.background = bg
        }
    }

    private fun updateFeaturesGrid() {
        val grid = mainContainer.findViewWithTag<LinearLayout>("features_grid")
        grid?.let {
            // Mise à jour simplifiée : on recrée la grid
            val index = mainContainer.indexOfChild(it)
            mainContainer.removeViewAt(index)
            val newGrid = createFeaturesGrid()
            mainContainer.addView(newGrid, index)
        }
    }
}