package com.boltfire.ai

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PanelActivity : AppCompatActivity(), PanelManager.PanelStateListener {

    private lateinit var mainContainer: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var handler: Handler

    private var aimbotToggleContainer: LinearLayout? = null
    private var autoFireToggleContainer: LinearLayout? = null
    private var antiBanToggleContainer: LinearLayout? = null
    private var espToggleContainer: LinearLayout? = null

    private var killsView: TextView? = null
    private var shotsView: TextView? = null
    private var accuracyView: TextView? = null
    private var timeView: TextView? = null

    private var kills = 0
    private var shots = 0
    private var hits = 0
    private var startTime = System.currentTimeMillis()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        PanelManager.init(this)
        PanelManager.addListener(this)

        handler = Handler(Looper.getMainLooper())
        setupUI()
        updateUIFromState()
    }

    override fun onDestroy() {
        super.onDestroy()
        PanelManager.removeListener(this)
        handler.removeCallbacksAndMessages(null)
    }

    private fun setupUI() {
        val scrollView = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0A0A0F"))
        }

        mainContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        mainContainer.addView(createHeader())
        mainContainer.addView(createStatusBar())
        mainContainer.addView(createFeaturesGrid())

        mainContainer.addView(createSectionHeader("🎯 AIMBOT"))
        mainContainer.addView(createToggle("Aimbot", "Vise automatiquement", PanelManager.state.aimbotEnabled) { PanelManager.toggleAimbot(it) })

        mainContainer.addView(createSectionHeader("🔥 AUTO FIRE"))
        mainContainer.addView(createToggle("Auto Fire", "Tire automatiquement", PanelManager.state.autoFireEnabled) { PanelManager.toggleAutoFire(it) })

        mainContainer.addView(createSectionHeader("🛡️ ANTIBAN"))
        mainContainer.addView(createToggle("AntiBan", "Mode furtif", PanelManager.state.antiBanEnabled) { PanelManager.toggleAntiBan(it) })

        mainContainer.addView(createSectionHeader("👁️ ESP"))
        mainContainer.addView(createToggle("ESP", "Affichage des menaces", PanelManager.state.espEnabled) { PanelManager.toggleEsp(it) })

        mainContainer.addView(createActionButtons())

        scrollView.addView(mainContainer)
        setContentView(scrollView)
    }

    private fun createHeader(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(16))
        }
        val title = TextView(this).apply {
            text = "⚡ BoltFire FF Panel"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        layout.addView(title)
        val backBtn = TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(Color.RED)
            setPadding(dp(16), dp(4), dp(4), dp(4))
            setOnClickListener { finish() }
        }
        layout.addView(backBtn)
        return layout
    }

    private fun createStatusBar(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = createRoundedDrawable(Color.parseColor("#1A1A2E"), dp(12))
        }
        statusDot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10))
            background = createRoundedDrawable(Color.parseColor("#FF4444"), dp(10))
        }
        layout.addView(statusDot)
        statusText = TextView(this).apply {
            text = "Panel INACTIF"
            textSize = 14f
            setTextColor(Color.parseColor("#8888AA"))
            setPadding(dp(12), 0, 0, 0)
        }
        layout.addView(statusText)
        return layout
    }

    private fun createFeaturesGrid(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(16))
        }
        val features = listOf(
            Triple("🎯", "Aimbot", PanelManager.state.aimbotEnabled),
            Triple("🔥", "Auto Fire", PanelManager.state.autoFireEnabled),
            Triple("🛡️", "AntiBan", PanelManager.state.antiBanEnabled),
            Triple("👁️", "ESP", PanelManager.state.espEnabled)
        )
        features.forEach { (icon, label, active) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(12), dp(12), dp(12))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                background = createRoundedDrawable(
                    if (active) Color.parseColor("#1A2E1A") else Color.parseColor("#1A1A2E"),
                    dp(10)
                )
                val iconView = TextView(this@PanelActivity).apply {
                    text = icon
                    textSize = 20f
                }
                addView(iconView)
                val labelView = TextView(this@PanelActivity).apply {
                    text = label
                    textSize = 10f
                    setTextColor(if (active) Color.parseColor("#00FF88") else Color.parseColor("#666688"))
                }
                addView(labelView)
            }
            layout.addView(card)
        }
        return layout
    }

    private fun createSectionHeader(title: String): View {
        return TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.parseColor("#AAAAEE"))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(16), 0, dp(8))
        }
    }

    private fun createToggle(
        title: String,
        subtitle: String,
        initialValue: Boolean,
        onToggle: (Boolean) -> Unit
    ): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = createRoundedDrawable(Color.parseColor("#111122"), dp(10))

            val textContainer = LinearLayout(this@PanelActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val titleView = TextView(this@PanelActivity).apply {
                text = title
                textSize = 15f
                setTextColor(Color.WHITE)
            }
            textContainer.addView(titleView)
            val subtitleView = TextView(this@PanelActivity).apply {
                text = subtitle
                textSize = 11f
                setTextColor(Color.parseColor("#666688"))
            }
            textContainer.addView(subtitleView)
            addView(textContainer)

            val toggle = createSwitch(initialValue, onToggle)
            addView(toggle)
        }
    }

    private fun createSwitch(initialValue: Boolean, onToggle: (Boolean) -> Unit): View {
        return LinearLayout(this).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = createRoundedDrawable(
                if (initialValue) Color.parseColor("#00FF88") else Color.parseColor("#333355"),
                dp(16)
            )
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(28))
            isClickable = true
            var isChecked = initialValue

            val indicator = View(this@PanelActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
                background = createRoundedDrawable(Color.WHITE, dp(20))
                translationX = if (isChecked) dp(14) else dp(-14)
            }
            addView(indicator)

            setOnClickListener {
                isChecked = !isChecked
                indicator.animate().translationX(if (isChecked) dp(14) else dp(-14))
                    .setDuration(250).start()
                background = createRoundedDrawable(
                    if (isChecked) Color.parseColor("#00FF88") else Color.parseColor("#333355"),
                    dp(16)
                )
                onToggle(isChecked)
            }
        }
    }

    private fun createActionButtons(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
        }

        val activateBtn = Button(this).apply {
            text = "▶ ACTIVER"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#00CC66"))
            background = createRoundedDrawable(Color.parseColor("#00CC66"), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                PanelManager.togglePanel(true)
                updateStatus("Panel ACTIF ✅", true)
                Toast.makeText(this@PanelActivity, "Panel activé", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(activateBtn)

        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(16), 1) }
        layout.addView(spacer)

        val stopBtn = Button(this).apply {
            text = "⏹ ARRÊTER"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#CC4444"))
            background = createRoundedDrawable(Color.parseColor("#CC4444"), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                PanelManager.togglePanel(false)
                updateStatus("Panel INACTIF ❌", false)
                Toast.makeText(this@PanelActivity, "Panel désactivé", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(stopBtn)

        return layout
    }

    private fun createRoundedDrawable(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun updateStatus(message: String, isActive: Boolean) {
        statusText.text = message
        if (isActive) {
            statusDot.setBackgroundColor(Color.parseColor("#00FF88"))
            statusText.setTextColor(Color.parseColor("#00FF88"))
        } else {
            statusDot.setBackgroundColor(Color.parseColor("#FF4444"))
            statusText.setTextColor(Color.parseColor("#FF4444"))
        }
    }

    override fun onStateChanged(state: PanelManager.PanelState) {
        updateStatus(if (state.panelActive) "Panel ACTIF ✅" else "Panel INACTIF ❌", state.panelActive)
    }

    override fun onAimbotToggled(enabled: Boolean) {
        Toast.makeText(this, if (enabled) "🎯 Aimbot activé" else "🎯 Aimbot désactivé", Toast.LENGTH_SHORT).show()
    }

    override fun onAutoFireToggled(enabled: Boolean) {
        Toast.makeText(this, if (enabled) "🔥 Auto Fire activé" else "🔥 Auto Fire désactivé", Toast.LENGTH_SHORT).show()
    }

    override fun onAntiBanToggled(enabled: Boolean) {
        Toast.makeText(this, if (enabled) "🛡️ AntiBan activé" else "🛡️ AntiBan désactivé", Toast.LENGTH_SHORT).show()
    }

    override fun onEspToggled(enabled: Boolean) {
        Toast.makeText(this, if (enabled) "👁️ ESP activé" else "👁️ ESP désactivé", Toast.LENGTH_SHORT).show()
    }

    private fun updateUIFromState() {
        val state = PanelManager.state
        updateStatus(
            if (state.panelActive) "Panel ACTIF ✅" else "Panel INACTIF ❌",
            state.panelActive
        )
    }
}