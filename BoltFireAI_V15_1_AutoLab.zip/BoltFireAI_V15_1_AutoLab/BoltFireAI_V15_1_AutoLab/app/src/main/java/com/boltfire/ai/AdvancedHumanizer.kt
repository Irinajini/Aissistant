package com.boltfire.ai

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

class AutomatedActionExecutor(private val context: Context) {

    // ... (déclarations existantes) ...

    // ===== NOUVEAU : AdvancedHumanizer =====
    private val humanizer = AdvancedHumanizer()
    private var lastShotResult: Boolean? = null

    // ============================================================
    // FIRE AVEC HUMANIZER AVANCÉ
    // ============================================================
    fun fire(): Boolean {
        if (!isReady()) return false
        
        // ===== HUMANISATION AVANCÉE : décision de tirer selon la stratégie =====
        if (!humanizer.shouldFire()) {
            val delay = humanizer.getActionDelay()
            SystemClock.sleep(delay.coerceAtMost(500L))
            return false
        }
        
        // ===== HUMANISATION AVANCÉE : délai selon la stratégie =====
        val strategyDelay = humanizer.getActionDelay()
        SystemClock.sleep(strategyDelay.coerceAtMost(400L))
        
        val now = SystemClock.uptimeMillis()
        val cooldown = Humanizer.jitter(180L, 0.40f)
        if (now - lastFireAt < cooldown) return false
        lastFireAt = now

        val x = controlPrefs.getFloat("fire_x", 0.90f)
        val y = controlPrefs.getFloat("fire_y", 0.58f)
        
        // ===== HUMANISATION AVANCÉE : offsets calculés =====
        // On simule que la cible est au centre (pour l'exemple)
        val offsets = humanizer.calculateOffsets(0.5f, 0.5f, lastShotResult)
        val finalX = (x + offsets.first).coerceIn(0.70f, 0.98f)
        val finalY = (y + offsets.second).coerceIn(0.40f, 0.80f)

        val duration = Humanizer.tapDuration(48L)
        val result = BotAccessibilityService.tapNormalized(finalX, finalY, duration)
        
        // On simule un résultat pour la prochaine itération
        lastShotResult = result && Random.nextFloat() < 0.7f // 70% de chance de toucher
        
        return result
    }

    // ============================================================
    // STEP AVEC HUMANIZER AVANCÉ
    // ============================================================
    fun step(primaryX: Float?, primaryY: Float?, mapDx: Float?, mapDy: Float?): String {
        if (!isReady()) return "WAIT"

        if (primaryX != null && primaryY != null) {
            // ===== HUMANISATION AVANCÉE : offsets selon la stratégie/fatigue =====
            val offsets = humanizer.calculateOffsets(primaryX, primaryY, lastShotResult)
            val noisyX = (primaryX + offsets.first).coerceIn(0f, 1f)
            val noisyY = (primaryY + offsets.second).coerceIn(0f, 1f)
            
            val dx = ((noisyX - 0.5f) * 2f).coerceIn(-1f, 1f)
            val dy = ((noisyY - 0.52f) * 2f).coerceIn(-1f, 1f)
            
            // ===== HUMANISATION AVANCÉE : seuil d'alignement variable =====
            // La fatigue rend l'alignement plus imprécis
            val fatigueLevel = humanizer.getCurrentObjective() // On utilise l'objectif comme proxy
            val alignThresholdX = 0.085f + (Random.nextFloat() - 0.5f) * 0.03f + 
                                  (1f - humanizer.getRiskTolerance()) * 0.02f
            val alignThresholdY = 0.17f + (Random.nextFloat() - 0.5f) * 0.03f +
                                  (1f - humanizer.getRiskTolerance()) * 0.02f
            val aligned = abs(noisyX - 0.5f) <= alignThresholdX.coerceAtLeast(0.06f) &&
                          abs(noisyY - 0.52f) <= alignThresholdY.coerceAtLeast(0.13f)
            
            // ===== HUMANISATION AVANCÉE : perte de focus =====
            if (humanizer.shouldRefocus()) {
                // Simule une micro-perte de focus : on relâche la visée momentanément
                return "FOCUS_LOST"
            }
            
            if (aligned) {
                // ===== HUMANISATION AVANCÉE : stratégie influence le tir =====
                val strategy = humanizer.getStrategy()
                when (strategy) {
                    AdvancedHumanizer.Strategy.DEFENSIVE -> {
                        // Se met à couvert au lieu de tirer
                        crouch()
                        return "COVER"
                    }
                    AdvancedHumanizer.Strategy.PATIENT -> {
                        // Attend une meilleure occasion
                        return "WAIT"
                    }
                    else -> {
                        // Tire normalement
                        return if (fire()) "FIRE" else "TRACK"
                    }
                }
            } else {
                return if (rotate(dx, dy)) "ROTATE" else "TRACK"
            }
        }

        if (mapDx != null && mapDy != null) {
            return if (rotate(mapDx, mapDy)) "ROTATE_MAP" else "TRACK_MAP"
        }

        return "OBSERVE"
    }

    // ============================================================
    // FONCTIONS SUPPLÉMENTAIRES POUR LES STRATÉGIES
    // ============================================================
    fun crouch(): Boolean {
        if (!isReady()) return false
        val x = controlPrefs.getFloat("crouch_x", 0.82f)
        val y = controlPrefs.getFloat("crouch_y", 0.79f)
        return BotAccessibilityService.tapNormalized(x, y, 55L)
    }

    fun jump(): Boolean {
        if (!isReady()) return false
        val x = controlPrefs.getFloat("jump_x", 0.91f)
        val y = controlPrefs.getFloat("jump_y", 0.72f)
        return BotAccessibilityService.tapNormalized(x, y, 55L)
    }
}