package com.boltfire.ai

/**
 * Normalized state consumed by the experimental decision engine.
 * Values come only from screen observation. No input is injected into the game.
 */
data class GameState(
    val timestampMs: Long,
    val frameChanged: Boolean,
    val visualCueCount: Int,
    val strongestCueScore: Int,
    val targetX: Float?,
    val targetY: Float?,
    val minimapDirection: String?,
    val minimapDistance: String?,
    val minimapDx: Float?,
    val minimapDy: Float?
)

enum class BotAction {
    OBSERVE,
    TRACK,
    AIM_RECOMMENDATION,
    ROTATE,
    REPOSITION
}

data class BotDecision(
    val timestampMs: Long,
    val action: BotAction,
    val confidence: Float,
    val reason: String,
    val targetX: Float? = null,
    val targetY: Float? = null,
    val moveDx: Float? = null,
    val moveDy: Float? = null
)
