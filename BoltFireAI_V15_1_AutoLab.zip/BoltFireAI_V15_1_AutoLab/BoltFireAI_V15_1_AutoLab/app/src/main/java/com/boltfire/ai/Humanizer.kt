package com.boltfire.ai

import kotlin.random.Random

/**
 * Humanizer : ajoute du bruit biologique aux actions du bot.
 * Version simple et stable.
 */
object Humanizer {

    private val rng = Random(System.currentTimeMillis())

    // Jitter sur les intervalles
    fun jitter(baseMs: Long, intensity: Float = 0.30f): Long {
        val delta = (baseMs * intensity * rng.nextFloat()).toLong()
        val sign = if (rng.nextBoolean()) 1 else -1
        return (baseMs + sign * delta).coerceAtLeast(60L)
    }

    // Micro-tremblement de visée
    fun aimOffset(strength: Float = 0.015f): Pair<Float, Float> {
        val dx = (rng.nextGaussian() * strength).toFloat()
        val dy = (rng.nextGaussian() * strength).toFloat()
        return dx.coerceIn(-0.08f, 0.08f) to dy.coerceIn(-0.08f, 0.08f)
    }

    // Hésitation avant de tirer
    fun shouldFire(confidence: Float = 0.85f): Boolean {
        val hesitationChance = 0.05f + (1f - confidence) * 0.25f
        return rng.nextFloat() > hesitationChance
    }

    // Durée d'appui variable
    fun tapDuration(baseMs: Long = 55L): Long {
        return (baseMs + rng.nextLong(-25L, 65L)).coerceIn(30L, 140L)
    }
}