package com.boltfire.ai

import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Humanizer : ajoute du bruit biologique aux actions du bot.
 * Version simple et stable, compatible avec Kotlin multiplateforme.
 */
object Humanizer {

    private val rng = Random(System.currentTimeMillis())

    /**
     * Génère un nombre aléatoire avec une distribution gaussienne approximée
     * via la méthode de Box-Muller (pour remplacer nextGaussian() qui n'existe pas)
     */
    private fun nextGaussian(): Double {
        var u: Double
        var v: Double
        var s: Double
        do {
            u = rng.nextDouble() * 2.0 - 1.0
            v = rng.nextDouble() * 2.0 - 1.0
            s = u * u + v * v
        } while (s >= 1.0 || s == 0.0)
        return u * sqrt(-2.0 * ln(s) / s)
    }

    // Jitter sur les intervalles
    fun jitter(baseMs: Long, intensity: Float = 0.30f): Long {
        val delta = (baseMs * intensity * rng.nextFloat()).toLong()
        val sign = if (rng.nextBoolean()) 1 else -1
        return (baseMs + sign * delta).coerceAtLeast(60L)
    }

    // Micro-tremblement de visée (avec distribution gaussienne)
    fun aimOffset(strength: Float = 0.015f): Pair<Float, Float> {
        val dx = (nextGaussian() * strength).toFloat()
        val dy = (nextGaussian() * strength).toFloat()
        return dx.coerceIn(-0.08f, 0.08f) to dy.coerceIn(-0.08f, 0.08f)
    }

    // Hésitation avant de tirer
    fun shouldFire(confidence: Float = 0.85f): Boolean {
        val hesitationChance = 0.05f + (1f - confidence) * 0.25f
        return rng.nextFloat() > hesitationChance
    }

    // Durée d'appui variable
    fun tapDuration(baseMs: Long = 55L): Long {
        return (baseMs + rng.nextLong(-25L, 65L)).coerceIn(30L, 140L)
    }

    // Temps de réaction variable (distribution log-normale approximée)
    fun humanReactionDelay(): Long {
        val base = (nextGaussian() * 60 + 260).toLong()
        return base.coerceIn(140L, 480L)
    }
}