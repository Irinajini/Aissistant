package com.boltfire.ai

import kotlin.math.sqrt
import kotlin.random.Random

class DecisionEngine {

    private var lastAction: BotAction = BotAction.OBSERVE
    private var inertiaCounter = 0
    private var decisionHistory = mutableListOf<BotAction>()

    fun decide(state: GameState): BotDecision {
        val hasCue = state.visualCueCount > 0 && state.targetX != null && state.targetY != null
        val cueStrength = (state.strongestCueScore / 8f).coerceIn(0f, 1f)

        // ===== HUMANISATION : inertie =====
        // Un humain ne change pas de décision 60 fois par seconde.
        // Si on était en TRACK, on reste en TRACK un peu plus longtemps.
        if (lastAction == BotAction.TRACK && inertiaCounter < 3 && hasCue) {
            inertiaCounter++
            return BotDecision(
                timestampMs = state.timestampMs,
                action = BotAction.TRACK,
                confidence = 0.65f,
                reason = "Inertie : maintien du suivi",
                targetX = state.targetX,
                targetY = state.targetY
            )
        }
        inertiaCounter = 0

        if (hasCue) {
            val x = state.targetX!!
            val y = state.targetY!!
            
            // ===== HUMANISATION : bruit sur la position perçue =====
            val noise = Humanizer.aimOffset(0.015f)
            val noisyX = (x + noise.first).coerceIn(0f, 1f)
            val noisyY = (y + noise.second).coerceIn(0f, 1f)
            
            val centerDistance = sqrt(
                (noisyX - 0.5f) * (noisyX - 0.5f) +
                (noisyY - 0.5f) * (noisyY - 0.5f)
            )
            
            // ===== HUMANISATION : seuil de centrage variable =====
            val centeringThreshold = 0.22f + (Random.nextFloat() - 0.5f) * 0.04f
            val centered = centerDistance < centeringThreshold.coerceAtLeast(0.18f)
            
            // ===== HUMANISATION : décision erronée (1 fois sur 20) =====
            val makeMistake = Random.nextFloat() < 0.05f
            
            // ===== HUMANISATION : confiance bruitée =====
            val confidenceNoise = (Random.nextFloat() - 0.5f) * 0.08f
            val confidence = (0.52f + cueStrength * 0.34f + if (centered) 0.10f else 0f + confidenceNoise)
                .coerceIn(0f, 0.96f)

            return when {
                centered && !makeMistake -> {
                    lastAction = BotAction.AIM_RECOMMENDATION
                    BotDecision(
                        timestampMs = state.timestampMs,
                        action = BotAction.AIM_RECOMMENDATION,
                        confidence = confidence,
                        reason = "Signal visuel proche du centre (bruité)",
                        targetX = noisyX,
                        targetY = noisyY
                    )
                }
                !makeMistake -> {
                    lastAction = BotAction.TRACK
                    BotDecision(
                        timestampMs = state.timestampMs,
                        action = BotAction.TRACK,
                        confidence = confidence,
                        reason = "Signal visuel hors centre (bruité)",
                        targetX = noisyX,
                        targetY = noisyY
                    )
                }
                else -> {
                    // Erreur volontaire : on fait une rotation inutile
                    lastAction = BotAction.ROTATE
                    BotDecision(
                        timestampMs = state.timestampMs,
                        action = BotAction.ROTATE,
                        confidence = 0.35f,
                        reason = "Erreur humaine simulée",
                        moveDx = (Random.nextFloat() - 0.5f) * 0.5f,
                        moveDy = (Random.nextFloat() - 0.5f) * 0.5f
                    )
                }
            }
        }

        // ... le reste du code inchangé ...
        
        return BotDecision(
            timestampMs = state.timestampMs,
            action = BotAction.OBSERVE,
            confidence = if (state.frameChanged) 0.48f else 0.62f,
            reason = if (state.frameChanged) "Changement visuel sans cible" else "Aucun signal exploitable"
        )
    }
}