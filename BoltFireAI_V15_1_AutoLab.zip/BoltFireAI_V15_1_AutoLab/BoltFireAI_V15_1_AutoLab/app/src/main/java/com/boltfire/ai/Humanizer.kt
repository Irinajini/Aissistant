package com.boltfire.ai

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.ln
import kotlin.random.Random

/**
 * Humanizer : ajoute du bruit biologique aux actions du bot.
 * Version stable avec implémentation manuelle de la distribution gaussienne.
 */
object Humanizer {

    private val rng = Random(System.currentTimeMillis())

    /**
     * Génère un nombre aléatoire avec une distribution gaussienne (Box-Muller)
     */
    private fun nextGaussian(): Double {
        var u: Double
        var v: Double
        var s: Double
        do {
            u = rng.nextDouble() * 2.0 - 1.0
            v = rng.nextDouble() * 2.0 - 1.0
            s = u * u + v * v
        } while (s >= 1.0 || s == 0.0)
        return u * sqrt(-2.0 * ln(s) / s)
    }

    // ============================================================
    // 1. JITTER SUR LES INTERVALLES
    // ============================================================
    fun jitter(baseMs: Long, intensity: Float = 0.30f): Long {
        val delta = (baseMs * intensity * rng.nextFloat()).toLong()
        val sign = if (rng.nextBoolean()) 1 else -1
        return (baseMs + sign * delta).coerceAtLeast(60L)
    }

    // ============================================================
    // 2. OFFSET DE VISÉE (micro-tremblements)
    // ============================================================
    fun aimOffset(strength: Float = 0.015f): Pair<Float, Float> {
        val dx = (nextGaussian() * strength).toFloat()
        val dy = (nextGaussian() * strength).toFloat()
        return dx.coerceIn(-0.08f, 0.08f) to dy.coerceIn(-0.08f, 0.08f)
    }

    // ============================================================
    // 3. HÉSITATION AVANT DE TIRER
    // ============================================================
    fun shouldFire(confidence: Float = 0.85f): Boolean {
        val hesitationChance = 0.05f + (1f - confidence) * 0.25f
        return rng.nextFloat() > hesitationChance
    }

    // ============================================================
    // 4. DURÉE D'APPUI VARIABLE
    // ============================================================
    fun tapDuration(baseMs: Long = 55L): Long {
        return (baseMs + rng.nextLong(-25L, 65L)).coerceIn(30L, 140L)
    }

    // ============================================================
    // 5. TEMPS DE RÉACTION HUMAIN
    // ============================================================
    fun humanReactionDelay(): Long {
        val base = (nextGaussian() * 60 + 260).toLong()
        return base.coerceIn(140L, 480L)
    }

    // ============================================================
    // 6. GÉNÉRATEUR DE TRAJECTOIRES COURBES (swipes humains)
    // ============================================================
    fun bezierSwipePoints(
        startX: Float, startY: Float,
        endX: Float, endY: Float,
        steps: Int = 14,
        curvature: Float = 0.15f
    ): List<Pair<Float, Float>> {
        val points = mutableListOf<Pair<Float, Float>>()
        
        val midX = (startX + endX) / 2f
        val midY = (startY + endY) / 2f
        
        val dist = kotlin.math.hypot(
            (endX - startX).toDouble(),
            (endY - startY).toDouble()
        ).toFloat()
        
        val deviation = dist * (0.05f + curvature * rng.nextFloat())
        
        val angle = kotlin.math.atan2(
            (endY - startY).toDouble(),
            (endX - startX).toDouble()
        ) + (if (rng.nextBoolean()) 1.57 else -1.57)
        
        val controlX = midX + (deviation * kotlin.math.cos(angle)).toFloat()
        val controlY = midY + (deviation * kotlin.math.sin(angle)).toFloat()

        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val x = (1-t)*(1-t) * startX + 2*(1-t)*t * controlX + t*t * endX
            val y = (1-t)*(1-t) * startY + 2*(1-t)*t * controlY + t*t * endY
            points.add(x to y)
        }
        return points
    }

    // ============================================================
    // 7. MICRO-MOUVEMENTS DE CAMÉRA (bruit de fond)
    // ============================================================
    fun cameraNoise(strength: Float = 0.002f): Pair<Float, Float> {
        val dx = (nextGaussian() * strength).toFloat()
        val dy = (nextGaussian() * strength).toFloat()
        return dx.coerceIn(-0.01f, 0.01f) to dy.coerceIn(-0.01f, 0.01f)
    }

    // ============================================================
    // 8. TEMPS DE RÉACTION SELON LA DISTANCE
    // ============================================================
    fun reactionTimeByDistance(distance: Float, baseMs: Long = 260L): Long {
        val factor = 1f + distance * 0.5f
        val delay = (baseMs * factor).toLong()
        return delay.coerceIn(160L, 500L)
    }

    // ============================================================
    // 9. GÉNÉRATEUR DE TRAJECTOIRE POUR LE JOYSTICK
    // ============================================================
    fun joystickPath(
        startX: Float, startY: Float,
        endX: Float, endY: Float,
        steps: Int = 6
    ): List<Pair<Float, Float>> {
        val points = mutableListOf<Pair<Float, Float>>()
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val noiseX = (nextGaussian() * 0.015f).toFloat()
            val noiseY = (nextGaussian() * 0.015f).toFloat()
            val x = startX + (endX - startX) * t + noiseX
            val y = startY + (endY - startY) * t + noiseY
            points.add(x.coerceIn(0f, 1f) to y.coerceIn(0f, 1f))
        }
        return points
    }

    // ============================================================
    // 10. SIMULATION D'ERREUR DE VISÉE (tirer à côté)
    // ============================================================
    fun missedShot(targetX: Float, targetY: Float, missRadius: Float = 0.06f): Pair<Float, Float> {
        val angle = rng.nextFloat() * 2f * Math.PI.toFloat()
        val radius = missRadius * rng.nextFloat()
        return Pair(
            (targetX + radius * kotlin.math.cos(angle)).coerceIn(0f, 1f),
            (targetY + radius * kotlin.math.sin(angle)).coerceIn(0f, 1f)
        )
    }

    // ============================================================
    // 11. EASING FUNCTION (accélération/décélération)
    // ============================================================
    fun easeInOut(t: Float): Float {
        return t * t * (3f - 2f * t)
    }
}