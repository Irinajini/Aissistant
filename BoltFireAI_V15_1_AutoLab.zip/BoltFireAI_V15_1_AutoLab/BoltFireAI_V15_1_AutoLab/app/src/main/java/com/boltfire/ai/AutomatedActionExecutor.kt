package com.boltfire.ai

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Executes calibrated gestures only while the explicitly bound target app is
 * the foreground application. This keeps BoltFire from touching Settings,
 * the launcher, or unrelated apps.
 * 
 * VERSION MODIFIÉE POUR FREE FIRE :
 * - Suppression du return true dans isReady() (force la vérification du package)
 * - Ajout de jitter sur les cooldowns (humanisation)
 * - Suppression de move() dans step() (le bot ne touche pas au joystick)
 */
class AutomatedActionExecutor(private val context: Context) {

    companion object {
        private const val PREFS = "boltfire_autobot"
        private const val TARGET_PACKAGE = "target_package"
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val controlPrefs = context.getSharedPreferences("boltfire_control_layout", Context.MODE_PRIVATE)

    private var lastRotateAt = 0L
    private var lastFireAt = 0L
    private var lastMoveAt = 0L

    fun bindForegroundTarget(): String? {
        val pkg = BotAccessibilityService.currentForegroundPackage()
            ?.takeIf { it != context.packageName && it.isNotBlank() }
            ?: return null
        prefs.edit().putString(TARGET_PACKAGE, pkg).apply()
        return pkg
    }

    fun targetPackage(): String? = prefs.getString(TARGET_PACKAGE, null)

    // ========== MODIFICATION 1 : SUPPRESSION DU return true ==========
    // Avant : targetPackage() ?: return true
    // Après : on force la vérification du package
    fun isReady(): Boolean {
        val target = targetPackage() ?: return false
        return BotAccessibilityService.isConnected() &&
            BotAccessibilityService.currentForegroundPackage() == target
    }
    // ================================================================

    // ========== MODIFICATION 2 : AJOUT DE JITTER (humanisation) ==========
    private fun jitter(base: Long): Long = (base + Random.nextLong(-30L, 40L)).coerceAtLeast(80L)

    fun rotate(dx: Float, dy: Float): Boolean {
        if (!isReady()) return false
        val now = SystemClock.uptimeMillis()
        if (now - lastRotateAt < jitter(120L)) return false
        lastRotateAt = now

        val mag = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val nx = (dx / mag).coerceIn(-1f, 1f)
        val ny = (dy / mag).coerceIn(-0.70f, 0.70f)

        // Camera gesture zone: intentionally away from the calibrated fire button.
        val sx = 0.68f
        val sy = 0.50f
        val amplitude = (0.075f + 0.11f * mag.coerceIn(0f, 1f))
        val ex = (sx + nx * amplitude).coerceIn(0.48f, 0.93f)
        val ey = (sy + ny * amplitude * 0.80f).coerceIn(0.24f, 0.78f)
        
        // Ajout d'un micro-bruit sur le point d'arrivée pour humaniser
        val noiseX = (Random.nextGaussian() * 0.005f).toFloat().coerceIn(-0.02f, 0.02f)
        val noiseY = (Random.nextGaussian() * 0.005f).toFloat().coerceIn(-0.02f, 0.02f)
        val finalX = (ex + noiseX).coerceIn(0.48f, 0.93f)
        val finalY = (ey + noiseY).coerceIn(0.24f, 0.78f)
        
        val duration = jitter(90L)
        return BotAccessibilityService.swipeNormalized(sx, sy, finalX, finalY, duration)
    }

    fun fire(): Boolean {
        if (!isReady()) return false
        
        // 1 chance sur 15 de ne pas tirer même si aligné (hésitation humaine)
        if (Random.nextFloat() < 0.07f) return false
        
        val now = SystemClock.uptimeMillis()
        if (now - lastFireAt < jitter(180L)) return false
        lastFireAt = now
        
        val x = controlPrefs.getFloat("fire_x", 0.90f)
        val y = controlPrefs.getFloat("fire_y", 0.58f)
        val duration = (48L + Random.nextLong(-15L, 40L)).coerceIn(30L, 130L)
        return BotAccessibilityService.tapNormalized(x, y, duration)
    }

    fun move(dx: Float, dy: Float, durationMs: Long = 520L): Boolean {
        if (!isReady()) return false
        val now = SystemClock.uptimeMillis()
        if (now - lastMoveAt < jitter(600L)) return false
        lastMoveAt = now

        val jx = controlPrefs.getFloat("joy_x", 0.15f)
        val jy = controlPrefs.getFloat("joy_y", 0.74f)
        val mag = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val nx = (dx / mag).coerceIn(-1f, 1f)
        val ny = (dy / mag).coerceIn(-1f, 1f)
        val radius = 0.065f
        val duration = jitter(durationMs)
        return BotAccessibilityService.swipeNormalized(
            jx,
            jy,
            (jx + nx * radius).coerceIn(0.03f, 0.34f),
            (jy + ny * radius).coerceIn(0.48f, 0.95f),
            duration
        )
    }
    // ================================================================

    // ========== MODIFICATION 3 : SUPPRESSION DE move() DANS step() ==========
    // Avant : le bot cherchait automatiquement (move(0f, -1f, 420L))
    // Après : si rien n'est détecté, le bot ne fait rien (vous gardez le contrôle)
    fun step(primaryX: Float?, primaryY: Float?, mapDx: Float?, mapDy: Float?): String {
        if (!isReady()) return "WAIT"

        // PRIORITÉ 1 : Un ennemi est visible à l'écran
        if (primaryX != null && primaryY != null) {
            val dx = ((primaryX - 0.5f) * 2f).coerceIn(-1f, 1f)
            val dy = ((primaryY - 0.52f) * 2f).coerceIn(-1f, 1f)
            val aligned = abs(primaryX - 0.5f) <= 0.085f && abs(primaryY - 0.52f) <= 0.17f
            
            return if (aligned) {
                if (fire()) "FIRE" else "TRACK"
            } else {
                if (rotate(dx, dy)) "ROTATE" else "TRACK"
            }
        }

        // PRIORITÉ 2 : Aucun ennemi visible, mais une menace sur la mini-map
        if (mapDx != null && mapDy != null) {
            return if (rotate(mapDx, mapDy)) "ROTATE_MAP" else "TRACK_MAP"
        }

        // PRIORITÉ 3 : Rien du tout → le bot ne fait rien
        // ❌ SUPPRESSION DE LA RECHERCHE AUTO (move())
        // Vous gardez le contrôle total du joystick
        return "OBSERVE"
    }
    // ================================================================
}