package com.boltfire.ai

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

class AutomatedActionExecutor(private val context: Context) {

    companion object {
        private const val PREFS = "boltfire_autobot"
        private const val TARGET_PACKAGE = "target_package"
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val controlPrefs = context.getSharedPreferences("boltfire_control_layout", Context.MODE_PRIVATE)

    private var lastRotateAt = 0L
    private var lastFireAt = 0L
    private var lastMoveAt = 0L

    // ============================================================
    // GESTION DU PACKAGE CIBLE
    // ============================================================

    fun bindForegroundTarget(): String? {
        val pkg = BotAccessibilityService.currentForegroundPackage()
            ?.takeIf { it != context.packageName && it.isNotBlank() }
            ?: return null
        prefs.edit().putString(TARGET_PACKAGE, pkg).apply()
        return pkg
    }

    fun targetPackage(): String? = prefs.getString(TARGET_PACKAGE, null)

    fun isReady(): Boolean {
        val target = targetPackage() ?: return false
        return BotAccessibilityService.isConnected() &&
            BotAccessibilityService.currentForegroundPackage() == target
    }

    // ============================================================
    // ROTATION CAMÉRA (avec Humanizer)
    // ============================================================

    fun rotate(dx: Float, dy: Float): Boolean {
        if (!isReady()) return false

        val now = SystemClock.uptimeMillis()
        if (now - lastRotateAt < Humanizer.jitter(120L, 0.35f)) return false
        lastRotateAt = now

        val mag = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val nx = (dx / mag).coerceIn(-1f, 1f)
        val ny = (dy / mag).coerceIn(-0.70f, 0.70f)

        val sx = 0.68f
        val sy = 0.50f
        val amplitude = (0.075f + 0.11f * mag.coerceIn(0f, 1f))
        val ex = (sx + nx * amplitude).coerceIn(0.48f, 0.93f)
        val ey = (sy + ny * amplitude * 0.80f).coerceIn(0.24f, 0.78f)

        // Micro-bruit sur le point d'arrivée
        val noise = Humanizer.aimOffset(0.005f)
        val finalX = (ex + noise.first).coerceIn(0.48f, 0.93f)
        val finalY = (ey + noise.second).coerceIn(0.24f, 0.78f)

        val duration = Humanizer.jitter(90L, 0.30f)
        return BotAccessibilityService.swipeNormalized(sx, sy, finalX, finalY, duration)
    }

    // ============================================================
    // TIR (avec Humanizer)
    // ============================================================

    fun fire(): Boolean {
        if (!isReady()) return false

        // Hésitation humaine
        if (!Humanizer.shouldFire(0.88f)) {
            SystemClock.sleep(Humanizer.jitter(150L, 0.4f))
            return false
        }

        val now = SystemClock.uptimeMillis()
        if (now - lastFireAt < Humanizer.jitter(180L, 0.40f)) return false
        lastFireAt = now

        val x = controlPrefs.getFloat("fire_x", 0.90f)
        val y = controlPrefs.getFloat("fire_y", 0.58f)

        // Micro-décalage du point de tir
        val offset = Humanizer.aimOffset(0.005f)
        val finalX = (x + offset.first).coerceIn(0.70f, 0.98f)
        val finalY = (y + offset.second).coerceIn(0.40f, 0.80f)

        val duration = Humanizer.tapDuration(48L)
        return BotAccessibilityService.tapNormalized(finalX, finalY, duration)
    }

    // ============================================================
    // DÉPLACEMENT (joystick) - Conservé mais non utilisé dans step()
    // ============================================================

    fun move(dx: Float, dy: Float, durationMs: Long = 520L): Boolean {
        if (!isReady()) return false

        val now = SystemClock.uptimeMillis()
        if (now - lastMoveAt < Humanizer.jitter(600L, 0.35f)) return false
        lastMoveAt = now

        val jx = controlPrefs.getFloat("joy_x", 0.15f)
        val jy = controlPrefs.getFloat("joy_y", 0.74f)
        val mag = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val nx = (dx / mag).coerceIn(-1f, 1f)
        val ny = (dy / mag).coerceIn(-1f, 1f)
        val radius = 0.065f

        val endX = (jx + nx * radius).coerceIn(0.03f, 0.34f)
        val endY = (jy + ny * radius).coerceIn(0.48f, 0.95f)

        val duration = Humanizer.jitter(durationMs, 0.20f)
        return BotAccessibilityService.swipeNormalized(jx, jy, endX, endY, duration)
    }

    // ============================================================
    // STEP PRINCIPAL
    // ============================================================

    fun step(primaryX: Float?, primaryY: Float?, mapDx: Float?, mapDy: Float?): String {
        if (!isReady()) return "WAIT"

        // PRIORITÉ 1 : Ennemi visible à l'écran
        if (primaryX != null && primaryY != null) {
            // Micro-bruit sur la position perçue
            val noise = Humanizer.aimOffset(0.01f)
            val noisyX = (primaryX + noise.first).coerceIn(0f, 1f)
            val noisyY = (primaryY + noise.second).coerceIn(0f, 1f)

            val dx = ((noisyX - 0.5f) * 2f).coerceIn(-1f, 1f)
            val dy = ((noisyY - 0.52f) * 2f).coerceIn(-1f, 1f)

            // Seuil d'alignement variable
            val alignThresholdX = 0.085f + (Random.nextFloat() - 0.5f) * 0.02f
            val alignThresholdY = 0.17f + (Random.nextFloat() - 0.5f) * 0.02f
            val aligned = abs(noisyX - 0.5f) <= alignThresholdX.coerceAtLeast(0.06f) &&
                          abs(noisyY - 0.52f) <= alignThresholdY.coerceAtLeast(0.13f)

            return if (aligned) {
                if (fire()) "FIRE" else "TRACK"
            } else {
                if (rotate(dx, dy)) "ROTATE" else "TRACK"
            }
        }

        // PRIORITÉ 2 : Menace sur la mini-map
        if (mapDx != null && mapDy != null) {
            // Bruit sur la direction de la mini-map
            val noise = Humanizer.aimOffset(0.02f)
            val noisyDx = (mapDx + noise.first).coerceIn(-1f, 1f)
            val noisyDy = (mapDy + noise.second).coerceIn(-1f, 1f)
            return if (rotate(noisyDx, noisyDy)) "ROTATE_MAP" else "TRACK_MAP"
        }

        // PRIORITÉ 3 : Rien du tout → le bot ne fait rien
        return "OBSERVE"
    }
}