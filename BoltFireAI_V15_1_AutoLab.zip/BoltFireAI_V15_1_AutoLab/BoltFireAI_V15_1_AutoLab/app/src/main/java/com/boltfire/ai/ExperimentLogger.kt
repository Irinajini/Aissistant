package com.boltfire.ai

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Writes one CSV row per sampled decision for later statistical analysis.
 * The file is stored in the app-specific external files directory.
 */
class ExperimentLogger(context: Context) {
    private val root = File(context.getExternalFilesDir(null), "experiments").apply { mkdirs() }
    private var currentFile: File? = null

    fun startSession(): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(root, "boltfire_session_$stamp.csv")
        file.writeText(
            "timestamp_ms,frame_changed,cue_count,strongest_cue,target_x,target_y," +
                "map_direction,map_distance,map_dx,map_dy,decision,confidence,reason\n"
        )
        currentFile = file
        return file
    }

    fun log(state: GameState, decision: BotDecision) {
        val file = currentFile ?: startSession()
        val row = listOf(
            state.timestampMs.toString(),
            state.frameChanged.toString(),
            state.visualCueCount.toString(),
            state.strongestCueScore.toString(),
            state.targetX?.toString().orEmpty(),
            state.targetY?.toString().orEmpty(),
            csv(state.minimapDirection),
            csv(state.minimapDistance),
            state.minimapDx?.toString().orEmpty(),
            state.minimapDy?.toString().orEmpty(),
            decision.action.name,
            "%.3f".format(Locale.US, decision.confidence),
            csv(decision.reason)
        ).joinToString(",")
        file.appendText(row + "\n")
    }

    fun path(): String = currentFile?.absolutePath ?: root.absolutePath

    private fun csv(value: String?): String {
        if (value == null) return ""
        val escaped = value.replace("\"", "\"\"")
        return "\"$escaped\""
    }
}
