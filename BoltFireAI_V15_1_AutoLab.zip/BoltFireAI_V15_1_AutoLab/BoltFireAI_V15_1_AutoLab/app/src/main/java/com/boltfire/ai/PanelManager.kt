package com.boltfire.ai

import android.content.Context
import android.content.SharedPreferences

object PanelManager {

    private const val PREFS_NAME = "boltfire_panel"
    private lateinit var prefs: SharedPreferences

    data class PanelState(
        var aimbotEnabled: Boolean = false,
        var autoFireEnabled: Boolean = false,
        var antiBanEnabled: Boolean = false,
        var espEnabled: Boolean = false,
        var panelActive: Boolean = false,
        var aimSensitivity: Float = 1.0f,
        var fovRadius: Float = 0.25f,
        var smoothness: Float = 0.7f
    )

    private var _state = PanelState()
    val state: PanelState get() = _state

    private var listeners = mutableListOf<PanelStateListener>()

    interface PanelStateListener {
        fun onStateChanged(state: PanelState)
        fun onAimbotToggled(enabled: Boolean)
        fun onAutoFireToggled(enabled: Boolean)
        fun onAntiBanToggled(enabled: Boolean)
        fun onEspToggled(enabled: Boolean)
    }

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadState()
    }

    fun addListener(listener: PanelStateListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeListener(listener: PanelStateListener) {
        listeners.remove(listener)
    }

    fun toggleAimbot(enabled: Boolean) {
        _state.aimbotEnabled = enabled
        saveState()
        listeners.forEach { it.onAimbotToggled(enabled); it.onStateChanged(_state) }
    }

    fun toggleAutoFire(enabled: Boolean) {
        _state.autoFireEnabled = enabled
        saveState()
        listeners.forEach { it.onAutoFireToggled(enabled); it.onStateChanged(_state) }
    }

    fun toggleAntiBan(enabled: Boolean) {
        _state.antiBanEnabled = enabled
        saveState()
        listeners.forEach { it.onAntiBanToggled(enabled); it.onStateChanged(_state) }
    }

    fun toggleEsp(enabled: Boolean) {
        _state.espEnabled = enabled
        saveState()
        listeners.forEach { it.onEspToggled(enabled); it.onStateChanged(_state) }
    }

    fun togglePanel(enabled: Boolean) {
        _state.panelActive = enabled
        saveState()
        listeners.forEach { it.onStateChanged(_state) }
    }

    private fun saveState() {
        if (!::prefs.isInitialized) return
        prefs.edit().apply {
            putBoolean("aimbot", _state.aimbotEnabled)
            putBoolean("autofire", _state.autoFireEnabled)
            putBoolean("antiban", _state.antiBanEnabled)
            putBoolean("esp", _state.espEnabled)
            putBoolean("panel_active", _state.panelActive)
            putFloat("aim_sensitivity", _state.aimSensitivity)
            putFloat("fov_radius", _state.fovRadius)
            putFloat("smoothness", _state.smoothness)
            apply()
        }
    }

    private fun loadState() {
        if (!::prefs.isInitialized) return
        _state.aimbotEnabled = prefs.getBoolean("aimbot", false)
        _state.autoFireEnabled = prefs.getBoolean("autofire", false)
        _state.antiBanEnabled = prefs.getBoolean("antiban", false)
        _state.espEnabled = prefs.getBoolean("esp", false)
        _state.panelActive = prefs.getBoolean("panel_active", false)
        _state.aimSensitivity = prefs.getFloat("aim_sensitivity", 1.0f)
        _state.fovRadius = prefs.getFloat("fov_radius", 0.25f)
        _state.smoothness = prefs.getFloat("smoothness", 0.7f)
    }

    fun isAimbotActive(): Boolean = _state.panelActive && _state.aimbotEnabled
    fun isAutoFireActive(): Boolean = _state.panelActive && _state.autoFireEnabled
    fun isAntiBanActive(): Boolean = _state.antiBanEnabled
    fun isEspActive(): Boolean = _state.espEnabled
}