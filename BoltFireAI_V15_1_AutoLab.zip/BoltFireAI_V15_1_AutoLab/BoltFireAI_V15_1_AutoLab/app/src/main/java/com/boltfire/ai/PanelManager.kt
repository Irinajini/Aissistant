package com.boltfire.ai

import android.content.Context
import android.content.SharedPreferences

/**
 * Gère l'état du panel et synchronise avec le bot
 */
object PanelManager {

    private const val PREFS_NAME = "boltfire_panel"
    private lateinit var prefs: SharedPreferences

    // États des fonctionnalités
    data class PanelState(
        var aimbotEnabled: Boolean = false,
        var espEnabled: Boolean = false,
        var autoFireEnabled: Boolean = false,
        var antiBanEnabled: Boolean = false,
        var panelActive: Boolean = false,
        var aimSensitivity: Float = 1.0f,
        var fovRadius: Float = 0.25f,
        var smoothness: Float = 0.7f
    )

    private var _state = PanelState()
    val state: PanelState get() = _state

    // Callbacks pour notifier les changements
    private var listeners = mutableListOf<PanelStateListener>()

    interface PanelStateListener {
        fun onStateChanged(state: PanelState)
        fun onAimbotToggled(enabled: Boolean)
        fun onAutoFireToggled(enabled: Boolean)
        fun onAntiBanToggled(enabled: Boolean)
        fun onEspToggled(enabled: Boolean)
    }

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadState()
    }

    fun addListener(listener: PanelStateListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeListener(listener: PanelStateListener) {
        listeners.remove(listener)
    }

    // ============================================================
    // TOGGLES
    // ============================================================

    fun toggleAimbot(enabled: Boolean) {
        _state.aimbotEnabled = enabled
        saveState()
        listeners.forEach { it.onAimbotToggled(enabled); it.onStateChanged(_state) }
    }

    fun toggleEsp(enabled: Boolean) {
        _state.espEnabled = enabled
        saveState()
        listeners.forEach { it.onEspToggled(enabled); it.onStateChanged(_state) }
    }

    fun toggleAutoFire(enabled: Boolean) {
        _state.autoFireEnabled = enabled
        saveState()
        listeners.forEach { it.onAutoFireToggled(enabled); it.onStateChanged(_state) }
    }

    fun toggleAntiBan(enabled: Boolean) {
        _state.antiBanEnabled = enabled
        saveState()
        listeners.forEach { it.onAntiBanToggled(enabled); it.onStateChanged(_state) }
    }

    fun togglePanel(enabled: Boolean) {
        _state.panelActive = enabled
        saveState()
        listeners.forEach { it.onStateChanged(_state) }
    }

    fun setAimSensitivity(value: Float) {
        _state.aimSensitivity = value.coerceIn(0.1f, 2.0f)
        saveState()
    }

    fun setFovRadius(value: Float) {
        _state.fovRadius = value.coerceIn(0.05f, 0.50f)
        saveState()
    }

    // ============================================================
    // PERSISTANCE
    // ============================================================

    private fun saveState() {
        if (!::prefs.isInitialized) return
        prefs.edit().apply {
            putBoolean("aimbot", _state.aimbotEnabled)
            putBoolean("esp", _state.espEnabled)
            putBoolean("autofire", _state.autoFireEnabled)
            putBoolean("antiban", _state.antiBanEnabled)
            putBoolean("panel_active", _state.panelActive)
            putFloat("aim_sensitivity", _state.aimSensitivity)
            putFloat("fov_radius", _state.fovRadius)
            putFloat("smoothness", _state.smoothness)
            apply()
        }
    }

    private fun loadState() {
        if (!::prefs.isInitialized) return
        _state.aimbotEnabled = prefs.getBoolean("aimbot", false)
        _state.espEnabled = prefs.getBoolean("esp", false)
        _state.autoFireEnabled = prefs.getBoolean("autofire", false)
        _state.antiBanEnabled = prefs.getBoolean("antiban", false)
        _state.panelActive = prefs.getBoolean("panel_active", false)
        _state.aimSensitivity = prefs.getFloat("aim_sensitivity", 1.0f)
        _state.fovRadius = prefs.getFloat("fov_radius", 0.25f)
        _state.smoothness = prefs.getFloat("smoothness", 0.7f)
    }

    // ============================================================
    // UTILITAIRES POUR LE BOT
    // ============================================================

    /**
     * Vérifie si l'aimbot est activé ET que le panel est actif
     */
    fun isAimbotActive(): Boolean = _state.panelActive && _state.aimbotEnabled

    /**
     * Vérifie si l'auto-fire est activé ET que le panel est actif
     */
    fun isAutoFireActive(): Boolean = _state.panelActive && _state.autoFireEnabled

    /**
     * Vérifie si l'anti-ban est activé
     */
    fun isAntiBanActive(): Boolean = _state.antiBanEnabled

    /**
     * Vérifie si l'ESP est activé
     */
    fun isEspActive(): Boolean = _state.espEnabled

    /**
     * Calcule le facteur de correction pour la visée selon la sensibilité
     */
    fun getAimCorrection(originalDx: Float, originalDy: Float): Pair<Float, Float> {
        val smooth = _state.smoothness
        val sensitivity = _state.aimSensitivity
        return Pair(
            originalDx * sensitivity * smooth,
            originalDy * sensitivity * smooth
        )
    }

    /**
     * Vérifie si une cible est dans le FOV (Field of View)
     */
    fun isInFov(targetX: Float, targetY: Float): Boolean {
        val dx = targetX - 0.5f
        val dy = targetY - 0.5f
        val distance = kotlin.math.sqrt(dx * dx + dy * dy)
        return distance <= _state.fovRadius
    }
}