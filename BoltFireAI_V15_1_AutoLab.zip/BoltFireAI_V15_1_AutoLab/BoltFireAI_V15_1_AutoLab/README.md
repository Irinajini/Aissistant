# BoltFire AI V15.1 AutoLab

Cette version corrige surtout le diagnostic du mode automatique.

## Nouveau

- `A✓ / A✗` : état réel du service Accessibilité.
- **Arène AUTO intégrée** : teste de vrais gestes Android via `dispatchGesture()`.
- Le bot tourne automatiquement la caméra virtuelle vers une cible, puis appuie sur **TIR** quand elle est alignée.
- Compteurs `ACT`, `SHOT` et `HIT` pour confirmer que les gestes sont réellement exécutés.
- Reset et arrêt immédiat.
- Capture écran et guidage visuel V15 conservés.

## Test conseillé

1. Installer l'APK.
2. Activer BoltFire dans **Paramètres > Accessibilité**.
3. Revenir dans BoltFire : la ligne doit afficher `A✓`.
4. Appuyer sur **Tester AUTO dans l'arène BoltFire**.
5. Appuyer sur **AUTO ON**.
6. Vérifier que la cible rouge converge vers le centre puis que le bouton TIR est pressé automatiquement.
7. Les compteurs `ACT`, `SHOT` et `HIT` doivent augmenter.

Le mode AUTO de cette version est volontairement limité à l'arène intégrée à BoltFire. Le mode d'analyse d'écran externe conserve les indications visuelles sans injecter de gestes dans une application tierce.
