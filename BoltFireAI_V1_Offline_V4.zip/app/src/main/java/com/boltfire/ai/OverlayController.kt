package com.boltfire.ai

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayController(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var statusText: TextView? = null
    private var adviceText: TextView? = null

    fun show() {
        if (root != null) return

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.argb(225, 20, 20, 24))
        }

        val title = TextView(context).apply {
            text = "BOLTFIRE  •  ACTIF"
            setTextColor(Color.WHITE)
            textSize = 15f
        }
        statusText = TextView(context).apply {
            text = "Observation en cours…"
            setTextColor(Color.LTGRAY)
            textSize = 12f
        }
        adviceText = TextView(context).apply {
            text = "En attente d'une situation à analyser."
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(6))
        }

        val dismiss = Button(context).apply {
            text = "Masquer"
            setOnClickListener { hide() }
        }

        panel.addView(title)
        panel.addView(statusText)
        panel.addView(adviceText)
        panel.addView(dismiss, LinearLayout.LayoutParams(-1, dp(38)))

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            dp(230),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(80)
        }

        windowManager.addView(panel, params)
        root = panel
    }

    fun update(status: String, advice: String) {
        statusText?.text = status
        adviceText?.text = advice
    }

    fun hide() {
        root?.let {
            runCatching { windowManager.removeView(it) }
        }
        root = null
        statusText = null
        adviceText = null
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}
