package com.boltfire.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onAnalysisEnabledChanged(enabled: Boolean)
        fun onStopRequested()
    }

    data class Marker(
        val x: Float,
        val y: Float,
        val label: String = "ALERTE"
    )

    data class ActionHint(
        val text: String,
        val x: Float,
        val y: Float
    )

    data class MovementHint(
        val dx: Float,
        val dy: Float,
        val text: String
    )

    data class MapHint(
        val direction: String,
        val distance: String
    )

    data class TargetGuide(
        val x: Float,
        val y: Float,
        val text: String
    )

    data class RotationHint(
        val dx: Float,
        val dy: Float,
        val text: String
    )

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: LinearLayout? = null
    private var markerView: MarkerView? = null
    private var statusText: TextView? = null
    private var adviceText: TextView? = null
    private var toggleButton: Button? = null
    private var params: WindowManager.LayoutParams? = null
    private var analysisEnabled = true
    private var actionHint: ActionHint? = null
    private var movementHint: MovementHint? = null
    private var mapHint: MapHint? = null
    private var targetGuide: TargetGuide? = null
    private var rotationHint: RotationHint? = null

    fun show() {
        if (root != null) return

        showMarkerLayer()

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.argb(235, 15, 18, 24))
        }

        val title = TextView(context).apply {
            text = "⚡ BOLTFIRE LAB V12  ⋮⋮"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, 0, dp(2))
        }
        makeDraggable(title)

        statusText = TextView(context).apply {
            text = "● ANALYSE ACTIVE"
            setTextColor(Color.GREEN)
            textSize = 12f
        }

        adviceText = TextView(context).apply {
            text = "Capture connectée."
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(6))
        }

        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }

        toggleButton = Button(context).apply {
            text = "Pause"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                analysisEnabled = !analysisEnabled
                text = if (analysisEnabled) "Pause" else "Reprendre"
                if (!analysisEnabled) clearMarkers()
                listener.onAnalysisEnabledChanged(analysisEnabled)
            }
        }

        val hide = Button(context).apply {
            text = "Masquer"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { hidePanel() }
        }

        val stop = Button(context).apply {
            text = "Arrêter"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { listener.onStopRequested() }
        }

        actions.addView(toggleButton, weightParams())
        actions.addView(hide, weightParams())
        actions.addView(stop, weightParams())
        panel.addView(title)
        panel.addView(statusText)
        panel.addView(adviceText)
        panel.addView(actions)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            dp(300),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(70)
        }

        try {
            windowManager.addView(panel, params)
            root = panel
        } catch (t: Throwable) {
            t.printStackTrace()
            root = null
        }
    }

    private fun showMarkerLayer() {
        if (markerView != null) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val markerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val view = MarkerView(context)
        try {
            windowManager.addView(view, markerParams)
            markerView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            markerView = null
        }
    }

    fun updateMarkers(markers: List<Marker>) {
        markerView?.setMarkers(markers)
    }

    fun clearMarkers() {
        markerView?.setMarkers(emptyList())
        markerView?.setActionHint(null)
        markerView?.setMovementHint(null)
        markerView?.setMapHint(null)
        markerView?.setTargetGuide(null)
        markerView?.setRotationHint(null)
    }

    fun showActionHint(text: String?, x: Float = 0.86f, y: Float = 0.74f) {
        actionHint = text?.let { ActionHint(it, x, y) }
        markerView?.setActionHint(actionHint)
    }

    fun showMovementHint(dx: Float, dy: Float, text: String) {
        movementHint = MovementHint(dx, dy, text)
        markerView?.setMovementHint(movementHint)
    }

    fun showMapHint(direction: String, distance: String) {
        mapHint = MapHint(direction, distance)
        markerView?.setMapHint(mapHint)
    }

    fun showTargetGuide(x: Float, y: Float, text: String) {
        targetGuide = TargetGuide(x, y, text)
        markerView?.setTargetGuide(targetGuide)
    }

    fun clearTargetGuide() {
        targetGuide = null
        markerView?.setTargetGuide(null)
    }

    fun showRotationHint(dx: Float, dy: Float, text: String) {
        rotationHint = RotationHint(dx, dy, text)
        markerView?.setRotationHint(rotationHint)
    }

    fun clearRotationHint() {
        rotationHint = null
        markerView?.setRotationHint(null)
    }

    private fun makeDraggable(handle: View) {
        handle.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = params ?: return false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = p.x
                        startY = p.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (downX - event.rawX).toInt()
                        p.y = startY + (event.rawY - downY).toInt()
                        root?.let { view -> runCatching { windowManager.updateViewLayout(view, p) } }
                        return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(40), 1f).apply {
        marginEnd = dp(3)
    }

    fun update(status: String, advice: String) {
        if (root == null) show()
        statusText?.text = status
        adviceText?.text = advice
    }

    fun showError(message: String) {
        if (root == null) show()
        statusText?.text = "● ERREUR"
        statusText?.setTextColor(Color.RED)
        adviceText?.text = message
        clearMarkers()
    }

    fun hidePanel() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        statusText = null
        adviceText = null
        toggleButton = null
        // Keep the non-touchable guidance layer visible.
    }

    fun hide() {
        hidePanel()
        markerView?.let { runCatching { windowManager.removeView(it) } }
        markerView = null
    }

    fun isVisible(): Boolean = root != null

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    private class MarkerView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var markers: List<Marker> = emptyList()
        private var actionHint: ActionHint? = null
        private var movementHint: MovementHint? = null
        private var mapHint: MapHint? = null
        private var targetGuide: TargetGuide? = null
        private var rotationHint: RotationHint? = null
    private var targetGuide: TargetGuide? = null
    private var rotationHint: RotationHint? = null

        init {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f * resources.displayMetrics.density
            paint.color = Color.RED
            textPaint.color = Color.WHITE
            textPaint.textSize = 14f * resources.displayMetrics.scaledDensity
            textPaint.style = Paint.Style.FILL
        }

        fun setMarkers(value: List<Marker>) {
            markers = value
            postInvalidateOnAnimation()
        }

        fun setActionHint(value: ActionHint?) {
            actionHint = value
            postInvalidateOnAnimation()
        }

        fun setMovementHint(value: MovementHint?) {
            movementHint = value
            postInvalidateOnAnimation()
        }

        fun setMapHint(value: MapHint?) {
            mapHint = value
            postInvalidateOnAnimation()
        }

        fun setTargetGuide(value: TargetGuide?) {
            targetGuide = value
            postInvalidateOnAnimation()
        }

        fun setRotationHint(value: RotationHint?) {
            rotationHint = value
            postInvalidateOnAnimation()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val radius = 24f * resources.displayMetrics.density
            for (marker in markers) {
                val x = marker.x.coerceIn(0f, 1f) * w
                val y = marker.y.coerceIn(0f, 1f) * h
                canvas.drawCircle(x, y, radius, paint)
                canvas.drawLine(x - radius - 10f, y, x + radius + 10f, y, paint)
                canvas.drawLine(x, y - radius - 10f, x, y + radius + 10f, paint)
                val box = RectF(x - radius, y + radius + 6f, x + radius + 130f, y + radius + 34f)
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(210, 180, 0, 0)
                canvas.drawRoundRect(box, 8f, 8f, paint)
                canvas.drawText(marker.label, box.left + 8f, box.bottom - 8f, textPaint)
                paint.style = Paint.Style.STROKE
                paint.color = Color.RED
            }

            // Central guidance: show where to rotate/aim without injecting game input.
            rotationHint?.let { r ->
                val cx = w * 0.5f
                val cy = h * 0.5f
                val dx = r.dx.coerceIn(-1f, 1f)
                val dy = r.dy.coerceIn(-1f, 1f)
                drawLongArrow(canvas, cx, cy, dx, dy)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = 16f * resources.displayMetrics.scaledDensity
                textPaint.color = Color.YELLOW
                canvas.drawText(r.text, cx, (cy - 78f * resources.displayMetrics.density).coerceAtLeast(32f), textPaint)
                textPaint.textAlign = Paint.Align.LEFT
            }

            targetGuide?.let { target ->
                val tx = target.x.coerceIn(0f, 1f) * w
                val ty = target.y.coerceIn(0f, 1f) * h
                val cx = w * 0.5f
                val cy = h * 0.5f
                val d = resources.displayMetrics.density
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f * d
                paint.color = Color.YELLOW
                canvas.drawLine(cx, cy, tx, ty, paint)
                canvas.drawCircle(tx, ty, 18f * d, paint)
                canvas.drawCircle(tx, ty, 5f * d, paint)
                canvas.drawLine(tx - 28f*d, ty, tx - 12f*d, ty, paint)
                canvas.drawLine(tx + 12f*d, ty, tx + 28f*d, ty, paint)
                canvas.drawLine(tx, ty - 28f*d, tx, ty - 12f*d, paint)
                canvas.drawLine(tx, ty + 12f*d, tx, ty + 28f*d, paint)

                paint.style = Paint.Style.FILL
                paint.color = Color.argb(220, 15, 18, 24)
                val box = RectF(
                    (tx - 105f*d).coerceAtLeast(8f),
                    (ty - 62f*d).coerceAtLeast(8f),
                    (tx + 105f*d).coerceAtMost(w - 8f),
                    (ty - 30f*d).coerceAtLeast(36f)
                )
                canvas.drawRoundRect(box, 10f*d, 10f*d, paint)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = 12f * resources.displayMetrics.scaledDensity
                textPaint.color = Color.YELLOW
                canvas.drawText(target.text, box.centerX(), box.centerY() + 5f*d, textPaint)
                textPaint.textAlign = Paint.Align.LEFT
            }

            // A non-touchable HUD guide showing the physical game controls to use.
            drawHudButton(canvas, w * 0.87f, h * 0.73f, "TIRER", actionHint?.text?.contains("TIRER") == true)
            drawHudButton(canvas, w * 0.79f, h * 0.78f, "VISE", actionHint?.text?.contains("VISE") == true)
            drawHudButton(canvas, w * 0.90f, h * 0.84f, "SAUTER", actionHint?.text?.contains("SAUTER") == true)
            drawHudButton(canvas, w * 0.78f, h * 0.88f, "ACCROUPI", actionHint?.text?.contains("ACCROUPI") == true)
            drawHudButton(canvas, w * 0.11f, h * 0.80f, "DÉPLACER", actionHint?.text?.contains("DÉPLACER") == true)

            // Direction pad guide: arrows are drawn on top of the real joystick area.
            movementHint?.let { m ->
                val cx = w * 0.13f
                val cy = h * 0.80f
                drawArrow(canvas, cx, cy, m.dx, m.dy, highlighted = true)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = 14f * resources.displayMetrics.scaledDensity
                textPaint.color = Color.YELLOW
                canvas.drawText(m.text, cx, cy + 58f * resources.displayMetrics.density, textPaint)
                textPaint.textAlign = Paint.Align.LEFT
            }

            mapHint?.let { mh ->
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(225, 10, 12, 18)
                val box = RectF(w * 0.04f, h * 0.20f, w * 0.42f, h * 0.29f)
                canvas.drawRoundRect(box, 14f, 14f, paint)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = 15f * resources.displayMetrics.scaledDensity
                textPaint.color = Color.WHITE
                canvas.drawText("MAPA → ${mh.direction}", box.centerX(), box.top + 27f * resources.displayMetrics.density, textPaint)
                textPaint.textSize = 12f * resources.displayMetrics.scaledDensity
                canvas.drawText(mh.distance, box.centerX(), box.top + 51f * resources.displayMetrics.density, textPaint)
                textPaint.textAlign = Paint.Align.LEFT
            }

            actionHint?.let { hint ->
                val x = hint.x.coerceIn(0.08f, 0.92f) * w
                val y = hint.y.coerceIn(0.12f, 0.88f) * h
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(235, 15, 18, 24)
                val left = (x - 115f).coerceAtLeast(8f)
                val right = (x + 115f).coerceAtMost(w - 8f)
                val box = RectF(left, y - 25f, right, y + 25f)
                canvas.drawRoundRect(box, 14f, 14f, paint)
                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = 16f * resources.displayMetrics.scaledDensity
                textPaint.color = Color.WHITE
                canvas.drawText(hint.text, (left + right) / 2f, y + 6f, textPaint)
                textPaint.textAlign = Paint.Align.LEFT
            }
        }
        private fun drawLongArrow(canvas: Canvas, x: Float, y: Float, dx: Float, dy: Float) {
            val d = resources.displayMetrics.density
            val mag = kotlin.math.sqrt(dx*dx + dy*dy).coerceAtLeast(0.001f)
            val ndx = dx / mag
            val ndy = dy / mag
            val len = 118f * d
            val ex = x + ndx * len
            val ey = y + ndy * len
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 7f * d
            paint.color = Color.YELLOW
            canvas.drawLine(x, y, ex, ey, paint)
            val angle = kotlin.math.atan2((ey-y).toDouble(), (ex-x).toDouble())
            val wing = 24f * d
            canvas.drawLine(ex, ey, ex - wing*kotlin.math.cos(angle-0.55).toFloat(), ey - wing*kotlin.math.sin(angle-0.55).toFloat(), paint)
            canvas.drawLine(ex, ey, ex - wing*kotlin.math.cos(angle+0.55).toFloat(), ey - wing*kotlin.math.sin(angle+0.55).toFloat(), paint)
        }

        private fun drawArrow(canvas: Canvas, x: Float, y: Float, dx: Float, dy: Float, highlighted: Boolean) {
            val d = resources.displayMetrics.density
            val len = 48f * d
            val ex = x + dx.coerceIn(-1f, 1f) * len
            val ey = y + dy.coerceIn(-1f, 1f) * len
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f * d
            paint.color = if (highlighted) Color.YELLOW else Color.WHITE
            canvas.drawLine(x, y, ex, ey, paint)
            val angle = kotlin.math.atan2((ey-y).toDouble(), (ex-x).toDouble())
            val wing = 18f * d
            canvas.drawLine(ex, ey, ex - wing*kotlin.math.cos(angle-0.55).toFloat(), ey - wing*kotlin.math.sin(angle-0.55).toFloat(), paint)
            canvas.drawLine(ex, ey, ex - wing*kotlin.math.cos(angle+0.55).toFloat(), ey - wing*kotlin.math.sin(angle+0.55).toFloat(), paint)
        }

        private fun drawHudButton(canvas: Canvas, x: Float, y: Float, label: String, highlighted: Boolean) {
            val d = resources.displayMetrics.density
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (highlighted) 4f * d else 2f * d
            paint.color = if (highlighted) Color.YELLOW else Color.argb(155, 255, 255, 255)
            canvas.drawCircle(x, y, 27f * d, paint)
            textPaint.textSize = 10f * resources.displayMetrics.scaledDensity
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.color = if (highlighted) Color.YELLOW else Color.WHITE
            canvas.drawText(label, x, y + 48f * d, textPaint)
            textPaint.textAlign = Paint.Align.LEFT
        }

    }
}
