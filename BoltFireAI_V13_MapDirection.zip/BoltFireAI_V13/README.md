# BoltFire AI V13 – Map Direction Edition

Version centrée sur un HUD minimal et sur l'analyse de la mini-carte.

## Changements principaux

- petite bulle `BF V13` au lieu du grand panneau BoltFire ;
- tap sur la bulle pour afficher uniquement Pause / Stop ;
- la mini-carte devient la source prioritaire de direction ;
- estimation heuristique de l’orientation du marqueur joueur au centre de la mini-carte pour convertir les menaces en gauche/droite par rapport au regard ;
- les signaux rouges/orangés de la mini-carte sont regroupés en menaces distinctes au lieu d'être moyennés ensemble ;
- jusqu'à 3 menaces sont suivies simultanément ;
- E1 est la menace prioritaire et apparaît en jaune ; E2/E3 apparaissent en rouge ;
- cercles E1/E2/E3 dessinés directement par-dessus la mini-carte ;
- chevrons directionnels autour du centre de l'écran pour repérer les menaces hors champ ;
- grosse flèche centrale avec instruction compacte, par exemple `→ DROITE 64°` ;
- lissage temporel des directions et maintien court des signaux pour réduire le clignotement ;
- les anciens gros blocs MAPA / boutons TIRER / VISE / DÉPLACER ne sont plus dessinés ;
- les signaux visuels de l'écran ne servent que de repli quand la mini-carte ne fournit rien.

## Important

L’estimation de l’orientation du joueur dépend de la visibilité/couleur du marqueur central ; si elle échoue, le système suppose que le haut de la mini-carte correspond à l’avant.

Cette version ne connaît pas la position cachée de tous les joueurs. Elle peut seulement exploiter ce que Free Fire rend réellement visible sur la mini-carte au moment de la capture. Les valeurs PROCHE / MOYEN / LOIN sont des distances relatives au centre du radar, pas des mètres.

Le système n'injecte aucun toucher, swipe, tir ou mouvement dans le jeu.

## Compilation

Android Gradle Plugin 8.6.1, Kotlin 2.0.21, Java 17, compileSdk 35, minSdk 26.
Le workflow `.github/workflows/build.yml` génère `app-debug.apk` via GitHub Actions.
