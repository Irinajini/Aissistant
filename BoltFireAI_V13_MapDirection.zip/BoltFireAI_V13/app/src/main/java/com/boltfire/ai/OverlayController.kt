package com.boltfire.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * V13 indication-first overlay.
 *
 * The gameplay surface stays almost empty: one compact BoltFire bubble plus
 * directional guidance rendered on a non-touchable layer. No input injection.
 */
class OverlayController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onAnalysisEnabledChanged(enabled: Boolean)
        fun onStopRequested()
    }

    data class Marker(
        val x: Float,
        val y: Float,
        val label: String = "SIGNAL"
    )

    data class ActionHint(val text: String, val x: Float, val y: Float)
    data class MovementHint(val dx: Float, val dy: Float, val text: String)
    data class MapHint(val direction: String, val distance: String)
    data class TargetGuide(val x: Float, val y: Float, val text: String)
    data class RotationHint(val dx: Float, val dy: Float, val text: String)

    data class MapThreatIndicator(
        val dx: Float,
        val dy: Float,
        val mapDx: Float,
        val mapDy: Float,
        val direction: String,
        val distance: String,
        val confidence: Int,
        val index: Int
    )

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: LinearLayout? = null
    private var controls: LinearLayout? = null
    private var bubbleText: TextView? = null
    private var markerView: MarkerView? = null
    private var analysisEnabled = true

    fun show() {
        if (root != null) return
        showMarkerLayer()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        bubbleText = TextView(context).apply {
            text = "⚡ BF V13  ●"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setBackgroundColor(Color.argb(220, 10, 13, 18))
            setOnClickListener {
                controls?.visibility = if (controls?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }

        controls = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            setPadding(0, dp(3), 0, 0)
        }

        val pause = Button(context).apply {
            text = "Pause"
            textSize = 10f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                analysisEnabled = !analysisEnabled
                text = if (analysisEnabled) "Pause" else "Reprendre"
                bubbleText?.text = if (analysisEnabled) "⚡ BF V13  ●" else "⚡ BF V13  PAUSE"
                if (!analysisEnabled) clearMarkers()
                listener.onAnalysisEnabledChanged(analysisEnabled)
            }
        }

        val stop = Button(context).apply {
            text = "Stop"
            textSize = 10f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { listener.onStopRequested() }
        }

        controls?.addView(pause, LinearLayout.LayoutParams(dp(88), dp(36)))
        controls?.addView(stop, LinearLayout.LayoutParams(dp(70), dp(36)))
        container.addView(bubbleText, LinearLayout.LayoutParams(dp(128), dp(38)))
        container.addView(controls)

        val type = overlayType()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(10)
            y = dp(78)
        }

        try {
            windowManager.addView(container, params)
            root = container
        } catch (t: Throwable) {
            t.printStackTrace()
            root = null
        }
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun showMarkerLayer() {
        if (markerView != null) return
        val markerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val view = MarkerView(context)
        try {
            windowManager.addView(view, markerParams)
            markerView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            markerView = null
        }
    }

    fun updateMarkers(markers: List<Marker>) = markerView?.setMarkers(markers) ?: Unit

    fun showMapThreats(threats: List<MapThreatIndicator>) {
        markerView?.setMapThreats(threats)
        bubbleText?.text = when {
            !analysisEnabled -> "⚡ BF V13  PAUSE"
            threats.isEmpty() -> "⚡ BF V13  ●"
            else -> "⚡ BF V13  ${threats.size}E"
        }
    }

    fun clearMarkers() {
        markerView?.setMarkers(emptyList())
        markerView?.setActionHint(null)
        markerView?.setMovementHint(null)
        markerView?.setMapHint(null)
        markerView?.setTargetGuide(null)
        markerView?.setRotationHint(null)
        markerView?.setMapThreats(emptyList())
    }

    fun showActionHint(text: String?, x: Float = 0.86f, y: Float = 0.74f) {
        markerView?.setActionHint(text?.let { ActionHint(it, x, y) })
    }

    fun showMovementHint(dx: Float, dy: Float, text: String) {
        markerView?.setMovementHint(MovementHint(dx, dy, text))
    }

    fun showMapHint(direction: String, distance: String) {
        markerView?.setMapHint(MapHint(direction, distance))
    }

    fun showTargetGuide(x: Float, y: Float, text: String) {
        markerView?.setTargetGuide(TargetGuide(x, y, text))
    }

    fun clearTargetGuide() = markerView?.setTargetGuide(null) ?: Unit

    fun showRotationHint(dx: Float, dy: Float, text: String) {
        markerView?.setRotationHint(RotationHint(dx, dy, text))
    }

    fun clearRotationHint() = markerView?.setRotationHint(null) ?: Unit

    /** The V13 bubble intentionally does not display verbose status text. */
    fun update(status: String, advice: String) {
        if (root == null) show()
    }

    fun showError(message: String) {
        if (root == null) show()
        bubbleText?.text = "⚡ BF  ERREUR"
        clearMarkers()
    }

    fun hidePanel() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        controls = null
        bubbleText = null
    }

    fun hide() {
        hidePanel()
        markerView?.let { runCatching { windowManager.removeView(it) } }
        markerView = null
    }

    fun isVisible(): Boolean = root != null

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    private class MarkerView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private var markers: List<Marker> = emptyList()
        private var actionHint: ActionHint? = null
        private var movementHint: MovementHint? = null
        private var mapHint: MapHint? = null
        private var targetGuide: TargetGuide? = null
        private var rotationHint: RotationHint? = null
        private var mapThreats: List<MapThreatIndicator> = emptyList()

        init {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f * resources.displayMetrics.density
            textPaint.style = Paint.Style.FILL
            textPaint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        fun setMarkers(value: List<Marker>) { markers = value; postInvalidateOnAnimation() }
        fun setActionHint(value: ActionHint?) { actionHint = value; postInvalidateOnAnimation() }
        fun setMovementHint(value: MovementHint?) { movementHint = value; postInvalidateOnAnimation() }
        fun setMapHint(value: MapHint?) { mapHint = value; postInvalidateOnAnimation() }
        fun setTargetGuide(value: TargetGuide?) { targetGuide = value; postInvalidateOnAnimation() }
        fun setRotationHint(value: RotationHint?) { rotationHint = value; postInvalidateOnAnimation() }
        fun setMapThreats(value: List<MapThreatIndicator>) { mapThreats = value; postInvalidateOnAnimation() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val d = resources.displayMetrics.density

            // 1) Draw the detected minimap threats directly over the minimap area.
            drawMinimapThreats(canvas, w, h, d)

            // 2) Edge/field indicators: primary threat is yellow, secondary threats red.
            drawThreatCompass(canvas, w, h, d)

            // 3) Main turn direction from the primary threat.
            rotationHint?.let { drawRotationGuide(canvas, w, h, d, it) }

            // 4) Only show a screen-space target when a visual cue actually exists.
            targetGuide?.let { drawTargetGuide(canvas, w, h, d, it) }

            // Visual cues are deliberately subtle in V13; map guidance has priority.
            for (marker in markers.take(2)) {
                val x = marker.x.coerceIn(0f, 1f) * w
                val y = marker.y.coerceIn(0f, 1f) * h
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f * d
                paint.color = Color.argb(175, 255, 75, 65)
                canvas.drawCircle(x, y, 12f * d, paint)
            }
        }

        private fun drawMinimapThreats(canvas: Canvas, w: Float, h: Float, d: Float) {
            if (mapThreats.isEmpty()) return
            val ox = w * 0.02f
            val oy = h * 0.03f
            val mw = w * 0.22f
            val mh = h * 0.24f
            val cx = ox + mw * 0.5f
            val cy = oy + mh * 0.5f

            mapThreats.take(3).forEachIndexed { i, threat ->
                val x = cx + threat.mapDx.coerceIn(-1f, 1f) * mw * 0.5f
                val y = cy + threat.mapDy.coerceIn(-1f, 1f) * mh * 0.5f
                val primary = i == 0
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = if (primary) 3.5f * d else 2f * d
                paint.color = if (primary) Color.YELLOW else Color.RED
                canvas.drawCircle(x, y, if (primary) 13f * d else 9f * d, paint)

                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = 10f * resources.displayMetrics.scaledDensity
                textPaint.color = if (primary) Color.YELLOW else Color.RED
                canvas.drawText("E${threat.index}", x, y - 14f * d, textPaint)
            }
        }

        private fun drawThreatCompass(canvas: Canvas, w: Float, h: Float, d: Float) {
            if (mapThreats.isEmpty()) return
            val cx = w * 0.5f
            val cy = h * 0.50f
            val radius = min(w, h) * 0.34f

            mapThreats.take(3).forEachIndexed { i, threat ->
                val mag = sqrt(threat.dx * threat.dx + threat.dy * threat.dy).coerceAtLeast(0.001f)
                val nx = threat.dx / mag
                val ny = threat.dy / mag
                val x = cx + nx * radius
                val y = cy + ny * radius
                val primary = i == 0
                drawChevron(canvas, x, y, nx, ny, d, primary)

                textPaint.textAlign = Paint.Align.CENTER
                textPaint.textSize = if (primary) 12f * resources.displayMetrics.scaledDensity else 10f * resources.displayMetrics.scaledDensity
                textPaint.color = if (primary) Color.YELLOW else Color.RED
                val label = if (primary) "E${threat.index}  ${threat.direction}  ${threat.distance}" else "E${threat.index}"
                canvas.drawText(label, x, y + 29f * d, textPaint)
            }
        }

        private fun drawChevron(
            canvas: Canvas,
            x: Float,
            y: Float,
            nx: Float,
            ny: Float,
            d: Float,
            primary: Boolean
        ) {
            val angle = atan2(ny.toDouble(), nx.toDouble())
            val size = if (primary) 22f * d else 15f * d
            val baseX = x - cos(angle).toFloat() * size * 0.55f
            val baseY = y - sin(angle).toFloat() * size * 0.55f
            val perpX = -sin(angle).toFloat()
            val perpY = cos(angle).toFloat()

            path.reset()
            path.moveTo(x + cos(angle).toFloat() * size, y + sin(angle).toFloat() * size)
            path.lineTo(baseX + perpX * size * 0.60f, baseY + perpY * size * 0.60f)
            path.lineTo(baseX - perpX * size * 0.60f, baseY - perpY * size * 0.60f)
            path.close()

            paint.style = Paint.Style.FILL
            paint.color = if (primary) Color.argb(235, 255, 215, 0) else Color.argb(220, 235, 35, 45)
            canvas.drawPath(path, paint)
        }

        private fun drawRotationGuide(canvas: Canvas, w: Float, h: Float, d: Float, r: RotationHint) {
            val dx = r.dx.coerceIn(-1f, 1f)
            val dy = r.dy.coerceIn(-1f, 1f)
            val magnitude = sqrt(dx * dx + dy * dy)
            if (magnitude < 0.05f) return

            val cx = w * 0.5f
            val cy = h * 0.53f
            val nx = dx / magnitude
            val ny = dy / magnitude
            val len = min(w, h) * 0.16f
            val ex = cx + nx * len
            val ey = cy + ny * len

            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = 5f * d
            paint.color = Color.argb(235, 255, 210, 0)
            canvas.drawLine(cx, cy, ex, ey, paint)

            val angle = atan2((ey - cy).toDouble(), (ex - cx).toDouble())
            val wing = 16f * d
            canvas.drawLine(
                ex, ey,
                ex - wing * cos(angle - 0.55).toFloat(),
                ey - wing * sin(angle - 0.55).toFloat(),
                paint
            )
            canvas.drawLine(
                ex, ey,
                ex - wing * cos(angle + 0.55).toFloat(),
                ey - wing * sin(angle + 0.55).toFloat(),
                paint
            )

            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 14f * resources.displayMetrics.scaledDensity
            textPaint.color = Color.YELLOW
            val labelY = (cy + 52f * d).coerceAtMost(h - 24f * d)
            canvas.drawText(r.text, cx, labelY, textPaint)
        }

        private fun drawTargetGuide(canvas: Canvas, w: Float, h: Float, d: Float, target: TargetGuide) {
            val tx = target.x.coerceIn(0f, 1f) * w
            val ty = target.y.coerceIn(0f, 1f) * h
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f * d
            paint.color = Color.argb(220, 255, 215, 0)
            canvas.drawCircle(tx, ty, 17f * d, paint)
            canvas.drawLine(tx - 27f * d, ty, tx - 11f * d, ty, paint)
            canvas.drawLine(tx + 11f * d, ty, tx + 27f * d, ty, paint)
            canvas.drawLine(tx, ty - 27f * d, tx, ty - 11f * d, paint)
            canvas.drawLine(tx, ty + 11f * d, tx, ty + 27f * d, paint)
        }
    }
}
