# BoltFire AI — V1 Offline

BoltFire AI is an Android prototype for local screen observation and context-aware visual recommendations.

## V1 scope

- MediaProjection-based screen capture.
- Local/offline processing scaffold.
- Foreground service configured for Android media projection.
- No automatic taps, gestures, key events, accessibility actions, or game control.
- Java and Kotlin compile against JVM 17.
- GitHub Actions build using Java 17 and Gradle 8.7.

The current V1 establishes the capture/build foundation. The visual recognition and recommendation engine can be implemented on top of the captured frames in a later step.

## Build

The GitHub Actions workflow can build either:

1. the Android project directly from the repository root; or
2. a ZIP archive containing the Android project.

The workflow extracts the ZIP when necessary, validates the project structure, builds `assembleDebug`, verifies the APK exists, and uploads it as an artifact.

## Important Android permissions

The app requests screen-capture consent through MediaProjection and requires overlay permission for a future floating UI. The screen-capture service is declared as a `mediaProjection` foreground service as required by recent Android versions.
