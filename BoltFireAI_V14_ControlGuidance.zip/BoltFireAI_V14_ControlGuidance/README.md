# BoltFire AI V14 — Control Guidance

V14 simplifie radicalement le HUD : pendant le gameplay, une seule indication visuelle est active.

## Ce qui change

- petite bulle `BF14`
- plus de messages de combat au centre de l’écran
- plus de plusieurs flèches concurrentes
- priorité à la mini-carte pour une cible hors écran
- si une cible visuelle est décalée : un seul geste de swipe jaune apparaît dans la zone caméra
- si la cible est suffisamment alignée : seul le bouton TIR calibré pulse
- un seul signal principal est entouré sur la mini-carte
- calibration MAP en 2 touches
- calibration HUD en 5 touches : joystick, tir, accroupi, saut, gloo

## Calibration recommandée

1. Lance BoltFire puis Free Fire en paysage.
2. Touche `BF14` > `Map` : touche le centre de la mini-carte puis son bord.
3. Touche `BF14` > `HUD` : touche successivement joystick, tir, accroupi, saut et gloo.
4. Après la 5e touche, un court auto-test montre le halo TIR puis un swipe.

## Limite importante

Cette version n’injecte aucun toucher et ne déplace pas automatiquement la caméra. Elle affiche uniquement les contrôles/gestes à effectuer. La détection écran existante reste heuristique (couleurs/signaux visuels) et ne constitue pas encore un vrai modèle de reconnaissance de personnes.
