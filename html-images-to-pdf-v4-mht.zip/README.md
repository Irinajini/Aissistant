# HTML Images vers PDF — v3

Application web statique, utilisable sur GitHub Pages.

## Deux options
1. **Un fichier HTML** : génère un PDF avec uniquement les images du HTML.
2. **Dossier complet** : inspecte récursivement chaque `.html` / `.htm`, puis génère un PDF distinct par fichier.

## Classement automatique
Le ZIP de sortie contient un dossier `PDF_CONVERTIS/`.

Les fichiers sont :
- triés par chemin/nom source ;
- renommés automatiquement : `001_nom.pdf`, `002_nom.pdf`, etc. ;
- rangés dans les mêmes sous-dossiers que les HTML si l'option de conservation est cochée ;
- accompagnés de `INDEX_CONVERSIONS.csv` pour retrouver immédiatement source et sortie ;
- accompagnés de `ERREURS_IMAGES.txt` uniquement si certaines images ou conversions ont échoué.

## Internet optionnel
L'application fonctionne sans Internet pour :
- images Base64 / `data:image/...` ;
- images locales incluses dans le dossier importé.

Une case **Vérification Internet optionnelle** permet de :
- tester la présence d'une connexion ;
- tenter de charger les images HTTP/HTTPS avant la génération du PDF ;
- signaler les images distantes inaccessibles ou bloquées par CORS.

Si la case n'est pas cochée, les images distantes sont ignorées plutôt que de ralentir la conversion.

## Dépendances
`JSZip` est inclus localement dans `vendor/`, donc la création du ZIP ne dépend pas d'un CDN.
Le PDF est construit directement dans le navigateur, sans bibliothèque PDF externe.

## GitHub Pages
Dépose le contenu du dossier sur ton dépôt puis active GitHub Pages.

## Compatibilité
La sélection de dossier via `webkitdirectory` fonctionne surtout avec Chrome, Edge et les navigateurs Chromium. Sur Android, le comportement dépend du sélecteur de fichiers du téléphone.

## Version 4
- Support HTML, HTM, MHT et MHTML.
- Extraction des images encapsulées dans les archives MHT/MHTML (MIME Base64 / quoted-printable).
- Traitement d'un fichier ou d'un dossier complet avec sous-dossiers.
- 1 source = 1 PDF, classement et renommage automatiques.
- Vérification Internet optionnelle pour les images HTTP/HTTPS non encapsulées.
- Workflow GitHub Pages inclus dans `.github/workflows/deploy.yml`.
