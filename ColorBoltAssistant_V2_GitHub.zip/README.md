# ColorBolt Assistant

Prototype Android d'un assistant visuel temps réel pour les puzzles de type Color Bolts.

## Ce que contient cette V0.1

- application Android Kotlin ;
- autorisation de superposition (bulle flottante) ;
- capture d'écran système via MediaProjection ;
- service foreground pour maintenir la capture ;
- architecture séparant capture, vision, solveur et overlay ;
- aucun clic automatique dans le jeu.

## Vision du projet

```text
Color Bolts
    ↓
MediaProjection
    ↓
ImageReader
    ↓
BoardDetector
    ↓
PuzzleState
    ↓
PuzzleSolver
    ↓
Guide
    ↓
Overlay flottant
```

## Prochaines étapes

1. Tester la capture sur un vrai téléphone.
2. Capturer une image du plateau depuis le flux ImageReader.
3. Détecter les boulons et leurs couleurs.
4. Déduire les règles d'accessibilité du jeu.
5. Implémenter le solveur.
6. Ajouter le dessin d'une flèche/cercle sur la position du prochain mouvement.
7. Ajouter une détection de changement d'état pour recalculer après chaque mouvement.

## Important

Ce dépôt est un prototype technique. Il ne prétend pas connaître encore toutes les règles internes de Color Bolts. Le solveur doit être alimenté par une représentation fidèle du plateau.

Le projet est conçu comme un assistant qui guide le joueur ; il n'automatise pas les clics et ne cherche pas à contourner les protections du jeu.

## Build

Ouvrir le dossier dans Android Studio et laisser Gradle synchroniser les dépendances.

Configuration prévue :
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- compileSdk 35
- minSdk 26


## V2 — GitHub Actions

Le dépôt contient maintenant `.github/workflows/android.yml`.

Après avoir envoyé le projet sur GitHub :
1. Ouvrir l'onglet **Actions**.
2. Sélectionner **Build ColorBolt Assistant**.
3. Utiliser **Run workflow** si nécessaire.
4. Une fois le build terminé, ouvrir le workflow réussi.
5. Télécharger l'artefact **ColorBoltAssistant-debug** pour récupérer l'APK.

Le workflow utilise JDK 17, Android SDK 35 et Gradle 8.7.
