# Mise en ligne sur GitHub

1. Crée un dépôt GitHub vide, par exemple `ColorBoltAssistant`.
2. Décompresse ce ZIP et envoie tout le contenu au dépôt.
3. Vérifie que `.github/workflows/android.yml` est bien présent.
4. Va dans **Actions** > **Build ColorBolt Assistant**.
5. Lance **Run workflow**.
6. Après réussite, ouvre le workflow puis **Artifacts** > `ColorBoltAssistant-debug`.

Cette V2 automatise le build du prototype. La reconnaissance réelle du plateau et le solveur sont les prochaines étapes.
