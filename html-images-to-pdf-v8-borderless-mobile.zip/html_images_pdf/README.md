# HTML Images vers PDF — V8

Cette version ajoute :

- Conversion parallèle de plusieurs pages Web.
- Détection HTML/HTM/XHTML/XHT/SHTML/MHT/MHTML et détection de certains BIN/TXT/DAT/EML contenant réellement du HTML/MHTML.
- Import d'un dossier, de plusieurs fichiers ou d'un ZIP.
- Téléchargement/enregistrement de chaque PDF dès que sa conversion est terminée.
- Sur les navigateurs compatibles avec File System Access API : choix du dossier parent puis création automatique de `PDF_CONVERTIS/` et de ses sous-dossiers.
- Sur Android/navigateurs non compatibles : téléchargement automatique de chaque PDF dans le dossier de téléchargement géré par le navigateur, avec ZIP final de secours optionnel.
- Renommage et classement automatiques, plus `INDEX_CONVERSIONS.csv`.

## Limite navigateur Android

Une page Web GitHub Pages ne peut pas forcer silencieusement la création d'un sous-dossier dans le stockage Android si le navigateur ne fournit pas l'API d'accès au système de fichiers. Dans ce cas, l'app télécharge chaque PDF individuellement et peut générer le ZIP final.


## V8
- Pages PDF bord à bord : chaque page adopte exactement les dimensions/ratio de l’image, sans marge A4.
- Interface mobile agrandie pour téléphone Android.
