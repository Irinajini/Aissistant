# BoltFire AI V5

Assistant Android hors ligne pour observation d'écran.

## V5
- MediaProjection pour capturer l'écran après autorisation utilisateur.
- Service foreground compatible avec le type mediaProjection.
- Overlay visible au-dessus des autres applications.
- Indicateur d'état et compteur d'images.
- Détection locale de changements visuels.
- Aucun clic automatique n'est envoyé au jeu.

## Limite actuelle
Cette version fournit l'infrastructure fiable de capture et d'overlay. Elle ne prétend pas encore reconnaître les armes, ennemis ou boutons de Free Fire. Un moteur de vision local entraîné/embarqué est nécessaire pour produire des recommandations spécifiques au jeu.

## Lancement
1. Autoriser l'affichage par-dessus les autres applications.
2. Appuyer sur Démarrer.
3. Autoriser la capture d'écran.
4. Ouvrir Free Fire.
5. L'overlay BoltFire doit rester visible.
