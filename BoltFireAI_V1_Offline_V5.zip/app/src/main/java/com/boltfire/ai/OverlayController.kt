package com.boltfire.ai

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayController(private val context: Context) {

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: LinearLayout? = null
    private var statusText: TextView? = null
    private var adviceText: TextView? = null

    fun show() {
        if (root != null) return

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.argb(235, 15, 18, 24))
        }

        val title = TextView(context).apply {
            text = "⚡ BOLTFIRE"
            setTextColor(Color.WHITE)
            textSize = 16f
        }

        statusText = TextView(context).apply {
            text = "● INITIALISATION"
            setTextColor(Color.GREEN)
            textSize = 12f
            setPadding(0, dp(4), 0, 0)
        }

        adviceText = TextView(context).apply {
            text = "Connexion à la capture…"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(8), 0, dp(8))
        }

        val hide = Button(context).apply {
            text = "Masquer"
            setOnClickListener { hide() }
        }

        panel.addView(title)
        panel.addView(statusText)
        panel.addView(adviceText)
        panel.addView(
            hide,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(40)
            )
        )

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            dp(260),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(70)
        }

        try {
            windowManager.addView(panel, params)
            root = panel
        } catch (t: Throwable) {
            t.printStackTrace()
            root = null
        }
    }

    fun update(status: String, advice: String) {
        if (root == null) show()
        statusText?.text = status
        adviceText?.text = advice
    }

    fun showError(message: String) {
        if (root == null) show()
        statusText?.text = "● ERREUR"
        statusText?.setTextColor(Color.RED)
        adviceText?.text = message
    }

    fun hide() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        statusText = null
        adviceText = null
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
