package com.boltfire.ai

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.nio.ByteBuffer

class ScreenAnalysisService : Service(), OverlayController.Listener {

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_PROJECTION_DATA = "projectionData"
        private const val CHANNEL_ID = "boltfire_analysis"
        private const val NOTIFICATION_ID = 7
        private const val ACTION_STOP = "com.boltfire.ai.STOP"
        private const val ACTION_SHOW = "com.boltfire.ai.SHOW"
        private const val SAMPLE_INTERVAL_MS = 300L
        private const val UI_INTERVAL_MS = 900L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: OverlayController? = null
    private var lastSignature = Long.MIN_VALUE
    private var receivedFrames = 0L
    private var sampledFrames = 0L
    private var lastSampleAt = 0L
    private var lastUiUpdate = 0L
    private var lastChangeAt = 0L
    private var analysisEnabled = true
    private var stopping = false
    private val decisionEngine = DecisionEngine()
    private lateinit var experimentLogger: ExperimentLogger
    private var lastDecision: BotDecision? = null

    override fun onCreate() {
        super.onCreate()
        experimentLogger = ExperimentLogger(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SHOW) {
            overlay?.show()
            return START_NOT_STICKY
        }

        stopProjection()
        stopping = false
        experimentLogger.startSession()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = readProjectionIntent(intent)

        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        return try {
            startForegroundCompat()
            overlay = OverlayController(this, this).also {
                it.show()
                it.update("● DÉMARRAGE", "Capture en préparation…")
            }
            startProjection(resultCode, data)
            START_NOT_STICKY
        } catch (t: Throwable) {
            t.printStackTrace()
            overlay?.showError("Démarrage impossible : ${t.javaClass.simpleName}")
            mainHandler.postDelayed({ stopSelf(startId) }, 2500L)
            START_NOT_STICKY
        }
    }

    override fun onAnalysisEnabledChanged(enabled: Boolean) {
        analysisEnabled = enabled
        if (enabled) {
            lastSignature = Long.MIN_VALUE
            lastSampleAt = 0L
            overlay?.update("● ANALYSE ACTIVE", "Analyse adaptative activée.")
        } else {
            overlay?.update("● ANALYSE EN PAUSE", "Capture conservée, analyse arrêtée.")
        }
        updateNotification()
    }

    override fun onStopRequested() {
        stopSelf()
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun readProjectionIntent(intent: Intent?): Intent? {
        if (intent == null) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
        }
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = manager.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("MediaProjection unavailable")

        mediaProjection = projection
        projection.registerCallback(projectionCallback, mainHandler)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(320)
        val height = metrics.heightPixels.coerceAtLeast(320)
        val density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        reader.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                receivedFrames++
                if (!analysisEnabled) return@setOnImageAvailableListener

                val now = System.currentTimeMillis()
                if (now - lastSampleAt < SAMPLE_INTERVAL_MS) return@setOnImageAvailableListener
                lastSampleAt = now
                sampledFrames++

                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                val signature = quickSignature(
                    plane.buffer,
                    image.width,
                    image.height,
                    plane.pixelStride,
                    plane.rowStride
                )
                val changed = signature != lastSignature
                if (changed) {
                    lastSignature = signature
                    lastChangeAt = now
                }

                val detections = detectVisualCues(
                    plane.buffer,
                    image.width,
                    image.height,
                    plane.pixelStride,
                    plane.rowStride
                )
                val mapGuide = analyzeMinimap(
                    plane.buffer, image.width, image.height, plane.pixelStride, plane.rowStride
                )

                val primaryCue = detections.maxByOrNull { it.score }
                val gameState = GameState(
                    timestampMs = now,
                    frameChanged = changed,
                    visualCueCount = detections.size,
                    strongestCueScore = primaryCue?.score ?: 0,
                    targetX = primaryCue?.x,
                    targetY = primaryCue?.y,
                    minimapDirection = mapGuide?.direction,
                    minimapDistance = mapGuide?.distance,
                    minimapDx = mapGuide?.dx,
                    minimapDy = mapGuide?.dy
                )
                val decision = decisionEngine.decide(gameState)
                lastDecision = decision
                runCatching { experimentLogger.log(gameState, decision) }

                mapGuide?.let { guide ->
                    overlay?.showMapHint(guide.direction, guide.distance)
                    overlay?.showMovementHint(guide.dx, guide.dy, guide.direction)
                }
                if (detections.isNotEmpty()) {
                    overlay?.updateMarkers(detections.map {
                        OverlayController.Marker(it.x, it.y, cueLabel(it.x, it.y))
                    })
                    val primary = detections.maxByOrNull { it.score }!!
                    val hint = actionHintFor(primary.x, primary.y)
                    overlay?.showActionHint(hint.text, hint.x, hint.y)
                    overlay?.showTargetGuide(primary.x, primary.y, "CIBLE PROBABLE")
                    val turnDx = ((primary.x - 0.5f) * 2f).coerceIn(-1f, 1f)
                    val turnDy = ((primary.y - 0.5f) * 2f).coerceIn(-1f, 1f)
                    overlay?.showRotationHint(turnDx, turnDy, rotationText(primary.x, primary.y))
                } else if (mapGuide != null) {
                    overlay?.clearTargetGuide()
                    overlay?.showRotationHint(mapGuide.dx, mapGuide.dy, "TOURNE ${mapGuide.direction}")
                } else if (now - lastChangeAt > 1200L) {
                    overlay?.clearMarkers()
                }

                if (now - lastUiUpdate >= UI_INTERVAL_MS) {
                    lastUiUpdate = now
                    val state = decisionEngine.humanReadable(decision)
                    val advice = buildString {
                        append(decision.reason)
                        append("\nÉchantillon #")
                        append(sampledFrames)
                        append(" • journal CSV actif")
                        if (detections.isNotEmpty()) {
                            val primary = detections.maxByOrNull { it.score }!!
                            append("\n")
                            append(actionHintFor(primary.x, primary.y).text)
                        } else if (mapGuide != null) {
                            append("\nMAPA → ")
                            append(mapGuide.direction)
                        }
                    }
                    overlay?.update(state, advice)
                }
            } catch (t: Throwable) {
                t.printStackTrace()
            } finally {
                image.close()
            }
        }, mainHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "BoltFireScreenCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            mainHandler
        ) ?: throw IllegalStateException("VirtualDisplay unavailable")

        overlay?.update(
            "● BOT EXPÉRIMENTAL PRÊT",
            "Capture connectée.\nDécisions observables + journal CSV actif."
        )
        updateNotification()
    }

    private data class VisualCue(val x: Float, val y: Float, val score: Int)

    private data class MapGuide(
        val direction: String,
        val distance: String,
        val dx: Float,
        val dy: Float
    )

    private data class ActionHint(val text: String, val x: Float, val y: Float)

    private fun actionHintFor(x: Float, y: Float): ActionHint {
        val horizontal = when {
            x < 0.35f -> "GAUCHE"
            x > 0.65f -> "DROITE"
            else -> "CENTRE"
        }
        return when {
            horizontal == "DROITE" -> ActionHint("TOURNE À DROITE → TIRER", 0.78f, 0.64f)
            horizontal == "GAUCHE" -> ActionHint("TOURNE À GAUCHE → DÉPLACER", 0.34f, 0.68f)
            y < 0.38f -> ActionHint("VISE EN HAUT → TIRER", 0.66f, 0.52f)
            else -> ActionHint("VISE → TIRER", 0.76f, 0.64f)
        }
    }

    private fun rotationText(x: Float, y: Float): String {
        val dx = x - 0.5f
        val dy = y - 0.5f
        if (kotlin.math.abs(dx) < 0.08f && kotlin.math.abs(dy) < 0.10f) return "CIBLE AU CENTRE"
        val vertical = when {
            dy < -0.12f -> "HAUT"
            dy > 0.12f -> "BAS"
            else -> ""
        }
        val horizontal = when {
            dx < -0.10f -> "GAUCHE"
            dx > 0.10f -> "DROITE"
            else -> ""
        }
        return "TOURNE " + listOf(vertical, horizontal).filter { it.isNotEmpty() }.joinToString("-")
    }

    private fun cueLabel(x: Float, y: Float): String {
        val horizontal = when {
            x < 0.38f -> "GAUCHE"
            x > 0.62f -> "DROITE"
            else -> "CENTRE"
        }
        val vertical = when {
            y < 0.34f -> "HAUT"
            y > 0.66f -> "BAS"
            else -> "MILIEU"
        }
        return "SIGNAL $horizontal/$vertical"
    }

    /**
     * Lecture heuristique de la mini-carte.
     * Elle cherche une zone lumineuse colorée distincte du centre du radar et
     * transforme son déplacement relatif en direction de déplacement.
     * Ce n'est pas encore une reconnaissance sémantique de la carte.
     */
    private fun analyzeMinimap(
        buffer: ByteBuffer, width: Int, height: Int, pixelStride: Int, rowStride: Int
    ): MapGuide? {
        val mw = (width * 0.22f).toInt().coerceAtLeast(80)
        val mh = (height * 0.24f).toInt().coerceAtLeast(80)
        val ox = (width * 0.02f).toInt()
        val oy = (height * 0.03f).toInt()
        var sumX = 0f; var sumY = 0f; var hits = 0
        for (gy in 0 until 12) {
            for (gx in 0 until 12) {
                val x = ox + ((gx + 0.5f) * mw / 12f).toInt()
                val y = oy + ((gy + 0.5f) * mh / 12f).toInt()
                val off = y * rowStride + x * pixelStride
                if (off < 0 || off + 3 >= buffer.limit()) continue
                val r = buffer.get(off).toInt() and 255
                val g = buffer.get(off + 1).toInt() and 255
                val b = buffer.get(off + 2).toInt() and 255
                val bright = maxOf(r,g,b)
                val sat = bright - minOf(r,g,b)
                if (bright > 175 && sat > 45) {
                    sumX += gx / 11f
                    sumY += gy / 11f
                    hits++
                }
            }
        }
        if (hits < 3) return null
        val tx = sumX / hits
        val ty = sumY / hits
        val dx = tx - 0.5f
        val dy = ty - 0.5f
        if (kotlin.math.abs(dx) < 0.10f && kotlin.math.abs(dy) < 0.10f) return null
        val horiz = when { dx < -0.12f -> "GAUCHE"; dx > 0.12f -> "DROITE"; else -> "CENTRE" }
        val vert = when { dy < -0.12f -> "HAUT"; dy > 0.12f -> "BAS"; else -> "CENTRE" }
        val direction = if (horiz == "CENTRE") vert else if (vert == "CENTRE") horiz else "$vert-$horiz"
        val magnitude = kotlin.math.sqrt(dx*dx + dy*dy)
        val distance = when { magnitude < 0.22f -> "petit ajustement"; magnitude < 0.38f -> "déplacement moyen"; else -> "déplacement important" }
        return MapGuide(
            direction = direction,
            distance = distance,
            dx = dx.coerceIn(-1f,1f),
            dy = dy.coerceIn(-1f,1f)
        )
    }

    /**
     * Détection locale très légère de signaux rouges/orangés fortement saturés.
     * Ce n'est pas un modèle de reconnaissance d'ennemis : le résultat est une
     * indication visuelle à vérifier par le joueur.
     */
    private fun detectVisualCues(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int
    ): List<VisualCue> {
        val gridW = 32
        val gridH = 18
        val active = Array(gridH) { BooleanArray(gridW) }

        fun isRedAt(x: Int, y: Int): Boolean {
            val offset = y * rowStride + x * pixelStride
            if (offset < 0 || offset + 3 >= buffer.limit()) return false
            val r = buffer.get(offset).toInt() and 0xff
            val g = buffer.get(offset + 1).toInt() and 0xff
            val b = buffer.get(offset + 2).toInt() and 0xff
            val max = maxOf(r, g, b)
            val min = minOf(r, g, b)
            return r >= 155 && r >= g + 55 && r >= b + 55 && max - min >= 80
        }

        for (gy in 0 until gridH) {
            for (gx in 0 until gridW) {
                val cx = ((gx + 0.5f) * width / gridW).toInt().coerceIn(0, width - 1)
                val cy = ((gy + 0.5f) * height / gridH).toInt().coerceIn(0, height - 1)

                // Ignore the common minimap and bottom control zones to reduce UI false positives.
                val nx = cx.toFloat() / width
                val ny = cy.toFloat() / height
                if ((nx < 0.22f && ny < 0.25f) || ny > 0.82f || (nx > 0.82f && ny < 0.20f)) continue

                var hits = 0
                for (oy in -1..1) {
                    for (ox in -1..1) {
                        val x = (cx + ox * maxOf(1, width / 220)).coerceIn(0, width - 1)
                        val y = (cy + oy * maxOf(1, height / 120)).coerceIn(0, height - 1)
                        if (isRedAt(x, y)) hits++
                    }
                }
                active[gy][gx] = hits >= 3
            }
        }

        val visited = Array(gridH) { BooleanArray(gridW) }
        val result = mutableListOf<VisualCue>()
        val dirs = arrayOf(
            intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1),
            intArrayOf(1, 1), intArrayOf(-1, -1), intArrayOf(1, -1), intArrayOf(-1, 1)
        )

        for (sy in 0 until gridH) {
            for (sx in 0 until gridW) {
                if (!active[sy][sx] || visited[sy][sx]) continue
                val queue = ArrayDeque<Pair<Int, Int>>()
                queue.add(sx to sy)
                visited[sy][sx] = true
                var count = 0
                var sumX = 0f
                var sumY = 0f

                while (queue.isNotEmpty()) {
                    val (x, y) = queue.removeFirst()
                    count++
                    sumX += (x + 0.5f) / gridW
                    sumY += (y + 0.5f) / gridH
                    for (d in dirs) {
                        val nx = x + d[0]
                        val ny = y + d[1]
                        if (nx in 0 until gridW && ny in 0 until gridH && active[ny][nx] && !visited[ny][nx]) {
                            visited[ny][nx] = true
                            queue.add(nx to ny)
                        }
                    }
                }

                if (count >= 2) {
                    result.add(VisualCue(sumX / count, sumY / count, count))
                }
            }
        }

        return result.sortedByDescending { it.score }.take(3)
    }

    private fun quickSignature(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int
    ): Long {
        val sampleW = 12
        val sampleH = 12
        var hash = 1469598103934665603L
        for (sy in 0 until sampleH) {
            val y = (sy * height) / sampleH
            for (sx in 0 until sampleW) {
                val x = (sx * width) / sampleW
                val offset = y * rowStride + x * pixelStride
                if (offset < 0 || offset + 3 >= buffer.limit()) continue
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                hash = (hash xor (r * 31L + g * 17L + b * 13L)) * 1099511628211L
            }
        }
        return hash
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BoltFire Lab",
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Capture écran et décisions expérimentales BoltFire"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun actionPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, ScreenAnalysisService::class.java).setAction(action)
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("BoltFire Lab V12.1")
            .setContentText(if (analysisEnabled) "Bot expérimental en observation" else "Analyse en pause")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    null,
                    "Afficher",
                    actionPendingIntent(ACTION_SHOW, 10)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    null,
                    "Arrêter BoltFire",
                    actionPendingIntent(ACTION_STOP, 11)
                ).build()
            )
            .build()

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    private fun stopProjection() {
        if (stopping) return
        stopping = true
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null
        mediaProjection?.unregisterCallback(projectionCallback)
        mediaProjection?.stop()
        mediaProjection = null
        overlay?.clearMarkers()
        overlay?.hide()
        overlay = null
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopProjection()
            stopSelf()
        }
    }

    override fun onDestroy() {
        stopProjection()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
