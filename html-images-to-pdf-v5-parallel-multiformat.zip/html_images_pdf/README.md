HTML Images vers PDF — V5 parallèle

Nouveautés :
- Conversion de plusieurs pages simultanément (1 à 8, 3 par défaut).
- Recherche récursive dans les sous-dossiers.
- Formats reconnus : HTML, HTM, XHTML, XHT, SHTML, SHTM, MHT, MHTML.
- Détection par contenu de certains fichiers BIN/TXT/DAT/EML mal nommés s'ils contiennent réellement du HTML/MHTML.
- Conservation des images locales, Base64 et images intégrées aux MHT/MHTML.
- Vérification Internet optionnelle pour les images HTTP/HTTPS.
- Classement automatique dans PDF_CONVERTIS/ avec renommage 001_, 002_, etc.
- INDEX_CONVERSIONS.csv et ERREURS_IMAGES.txt en cas de problème.

Utilisation : ouvre index.html dans un navigateur moderne, choisis un fichier ou un dossier, puis lance la conversion.
