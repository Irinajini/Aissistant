package com.boltfire.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onAnalysisEnabledChanged(enabled: Boolean)
        fun onStopRequested()
    }

    data class Marker(
        val x: Float,
        val y: Float,
        val label: String = "ALERTE"
    )

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: LinearLayout? = null
    private var markerView: MarkerView? = null
    private var statusText: TextView? = null
    private var adviceText: TextView? = null
    private var toggleButton: Button? = null
    private var params: WindowManager.LayoutParams? = null
    private var analysisEnabled = true

    fun show() {
        if (root != null) return

        showMarkerLayer()

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.argb(235, 15, 18, 24))
        }

        val title = TextView(context).apply {
            text = "⚡ BOLTFIRE  ⋮⋮"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, 0, dp(2))
        }
        makeDraggable(title)

        statusText = TextView(context).apply {
            text = "● ANALYSE ACTIVE"
            setTextColor(Color.GREEN)
            textSize = 12f
        }

        adviceText = TextView(context).apply {
            text = "Capture connectée."
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(6))
        }

        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }

        toggleButton = Button(context).apply {
            text = "Pause"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                analysisEnabled = !analysisEnabled
                text = if (analysisEnabled) "Pause" else "Reprendre"
                if (!analysisEnabled) clearMarkers()
                listener.onAnalysisEnabledChanged(analysisEnabled)
            }
        }

        val hide = Button(context).apply {
            text = "Masquer"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { hide() }
        }

        val stop = Button(context).apply {
            text = "Arrêter"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { listener.onStopRequested() }
        }

        actions.addView(toggleButton, weightParams())
        actions.addView(hide, weightParams())
        actions.addView(stop, weightParams())
        panel.addView(title)
        panel.addView(statusText)
        panel.addView(adviceText)
        panel.addView(actions)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            dp(300),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(70)
        }

        try {
            windowManager.addView(panel, params)
            root = panel
        } catch (t: Throwable) {
            t.printStackTrace()
            root = null
        }
    }

    private fun showMarkerLayer() {
        if (markerView != null) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val markerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val view = MarkerView(context)
        try {
            windowManager.addView(view, markerParams)
            markerView = view
        } catch (t: Throwable) {
            t.printStackTrace()
            markerView = null
        }
    }

    fun updateMarkers(markers: List<Marker>) {
        markerView?.setMarkers(markers)
    }

    fun clearMarkers() {
        markerView?.setMarkers(emptyList())
    }

    private fun makeDraggable(handle: View) {
        handle.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = params ?: return false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = p.x
                        startY = p.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (downX - event.rawX).toInt()
                        p.y = startY + (event.rawY - downY).toInt()
                        root?.let { view -> runCatching { windowManager.updateViewLayout(view, p) } }
                        return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(40), 1f).apply {
        marginEnd = dp(3)
    }

    fun update(status: String, advice: String) {
        if (root == null) show()
        statusText?.text = status
        adviceText?.text = advice
    }

    fun showError(message: String) {
        if (root == null) show()
        statusText?.text = "● ERREUR"
        statusText?.setTextColor(Color.RED)
        adviceText?.text = message
        clearMarkers()
    }

    fun hide() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        markerView?.let { runCatching { windowManager.removeView(it) } }
        markerView = null
        statusText = null
        adviceText = null
        toggleButton = null
    }

    fun isVisible(): Boolean = root != null

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    private class MarkerView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var markers: List<Marker> = emptyList()

        init {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f * resources.displayMetrics.density
            paint.color = Color.RED
            textPaint.color = Color.WHITE
            textPaint.textSize = 14f * resources.displayMetrics.scaledDensity
            textPaint.style = Paint.Style.FILL
        }

        fun setMarkers(value: List<Marker>) {
            markers = value
            postInvalidateOnAnimation()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val radius = 24f * resources.displayMetrics.density
            for (marker in markers) {
                val x = marker.x.coerceIn(0f, 1f) * w
                val y = marker.y.coerceIn(0f, 1f) * h
                canvas.drawCircle(x, y, radius, paint)
                canvas.drawLine(x - radius - 10f, y, x + radius + 10f, y, paint)
                canvas.drawLine(x, y - radius - 10f, x, y + radius + 10f, paint)
                val box = RectF(x - radius, y + radius + 6f, x + radius + 90f, y + radius + 34f)
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(190, 180, 0, 0)
                canvas.drawRoundRect(box, 8f, 8f, paint)
                canvas.drawText(marker.label, box.left + 8f, box.bottom - 8f, textPaint)
                paint.style = Paint.Style.STROKE
                paint.color = Color.RED
            }
        }
    }
}
