package com.boltfire.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    companion object {
        private const val PROJECTION_REQUEST = 1001
        private const val NOTIFICATION_REQUEST = 1002
    }

    private lateinit var status: TextView
    private lateinit var overlayButton: Button
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.statusText)
        overlayButton = findViewById(R.id.overlayButton)
        startButton = findViewById(R.id.startButton)

        overlayButton.setOnClickListener { requestOverlayPermission() }
        startButton.setOnClickListener { startObservation() }

        requestNotificationPermissionIfNeeded()
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun refreshUi() {
        if (Settings.canDrawOverlays(this)) {
            overlayButton.text = "Overlay autorisé ✓"
            startButton.isEnabled = true
            status.text = "Prêt. Appuie sur « Démarrer » puis autorise la capture d'écran."
        } else {
            overlayButton.text = "Autoriser l'overlay"
            startButton.isEnabled = false
            status.text = "Étape 1 : autorise l'affichage par-dessus les autres applications."
        }
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            refreshUi()
            return
        }
        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
    }

    private fun startObservation() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        status.text = "Étape 2 : autorise la capture de l'écran."
        startActivityForResult(manager.createScreenCaptureIntent(), PROJECTION_REQUEST)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                NOTIFICATION_REQUEST
            )
        }
    }

    @Deprecated("Retained for compatibility with this project.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PROJECTION_REQUEST) return

        if (resultCode != Activity.RESULT_OK || data == null) {
            status.text = "Capture refusée. Aucun assistant n'est lancé."
            return
        }

        val serviceIntent = Intent(this, ScreenAnalysisService::class.java).apply {
            putExtra(ScreenAnalysisService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenAnalysisService.EXTRA_PROJECTION_DATA, data)
        }

        try {
            ContextCompat.startForegroundService(this, serviceIntent)
            status.text = "BoltFire démarre. Passe ensuite dans Free Fire."
        } catch (t: Throwable) {
            status.text = "Impossible de démarrer BoltFire : ${t.javaClass.simpleName}"
        }
    }
}
