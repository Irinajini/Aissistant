package com.boltfire.ai

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.nio.ByteBuffer

class ScreenAnalysisService : Service(), OverlayController.Listener {

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_PROJECTION_DATA = "projectionData"
        private const val CHANNEL_ID = "boltfire_analysis"
        private const val NOTIFICATION_ID = 7
        private const val ACTION_STOP = "com.boltfire.ai.STOP"
        private const val ACTION_SHOW = "com.boltfire.ai.SHOW"
        private const val SAMPLE_INTERVAL_MS = 450L
        private const val UI_INTERVAL_MS = 900L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: OverlayController? = null
    private var lastSignature = Long.MIN_VALUE
    private var receivedFrames = 0L
    private var sampledFrames = 0L
    private var lastSampleAt = 0L
    private var lastUiUpdate = 0L
    private var lastChangeAt = 0L
    private var analysisEnabled = true
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SHOW) {
            overlay?.show()
            return START_NOT_STICKY
        }

        stopProjection()
        stopping = false

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = readProjectionIntent(intent)

        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        return try {
            startForegroundCompat()
            overlay = OverlayController(this, this).also {
                it.show()
                it.update("● DÉMARRAGE", "Capture en préparation…")
            }
            startProjection(resultCode, data)
            START_NOT_STICKY
        } catch (t: Throwable) {
            t.printStackTrace()
            overlay?.showError("Démarrage impossible : ${t.javaClass.simpleName}")
            mainHandler.postDelayed({ stopSelf(startId) }, 2500L)
            START_NOT_STICKY
        }
    }

    override fun onAnalysisEnabledChanged(enabled: Boolean) {
        analysisEnabled = enabled
        if (enabled) {
            lastSignature = Long.MIN_VALUE
            lastSampleAt = 0L
            overlay?.update("● ANALYSE ACTIVE", "Analyse adaptative activée.")
        } else {
            overlay?.update("● ANALYSE EN PAUSE", "Capture conservée, analyse arrêtée.")
        }
        updateNotification()
    }

    override fun onStopRequested() {
        stopSelf()
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun readProjectionIntent(intent: Intent?): Intent? {
        if (intent == null) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
        }
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = manager.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("MediaProjection unavailable")

        mediaProjection = projection
        projection.registerCallback(projectionCallback, mainHandler)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(320)
        val height = metrics.heightPixels.coerceAtLeast(320)
        val density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        reader.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                receivedFrames++
                if (!analysisEnabled) return@setOnImageAvailableListener

                val now = System.currentTimeMillis()
                if (now - lastSampleAt < SAMPLE_INTERVAL_MS) return@setOnImageAvailableListener
                lastSampleAt = now
                sampledFrames++

                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                val signature = quickSignature(
                    plane.buffer,
                    image.width,
                    image.height,
                    plane.pixelStride,
                    plane.rowStride
                )
                val changed = signature != lastSignature
                if (changed) {
                    lastSignature = signature
                    lastChangeAt = now
                }

                if (now - lastUiUpdate >= UI_INTERVAL_MS) {
                    lastUiUpdate = now
                    val state = if (changed || now - lastChangeAt < 1600L) {
                        "● CHANGEMENT VISUEL"
                    } else {
                        "● ÉCRAN STABLE"
                    }
                    val advice = if (changed) {
                        "Zone visuelle modifiée.\nAnalyse locale limitée à ~2 échantillons/s."
                    } else {
                        "Aucun changement visuel important détecté.\nAnalyse en veille adaptative."
                    }
                    overlay?.update(
                        "$state • $sampledFrames échantillons",
                        advice
                    )
                }
            } catch (t: Throwable) {
                t.printStackTrace()
            } finally {
                image.close()
            }
        }, mainHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "BoltFireScreenCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            mainHandler
        ) ?: throw IllegalStateException("VirtualDisplay unavailable")

        overlay?.update(
            "● ANALYSE ACTIVE • 0 échantillon",
            "Capture connectée.\nTu peux ouvrir Free Fire."
        )
        updateNotification()
    }

    private fun quickSignature(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int
    ): Long {
        val sampleW = 12
        val sampleH = 12
        var hash = 1469598103934665603L
        for (sy in 0 until sampleH) {
            val y = (sy * height) / sampleH
            for (sx in 0 until sampleW) {
                val x = (sx * width) / sampleW
                val offset = y * rowStride + x * pixelStride
                if (offset < 0 || offset + 3 >= buffer.limit()) continue
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                hash = (hash xor (r * 31L + g * 17L + b * 13L)) * 1099511628211L
            }
        }
        return hash
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BoltFire AI",
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Capture locale utilisée par BoltFire"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun actionPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, ScreenAnalysisService::class.java).setAction(action)
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("BoltFire AI")
            .setContentText(if (analysisEnabled) "Analyse adaptative active" else "Analyse en pause")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    null,
                    "Afficher",
                    actionPendingIntent(ACTION_SHOW, 10)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    null,
                    "Arrêter BoltFire",
                    actionPendingIntent(ACTION_STOP, 11)
                ).build()
            )
            .build()

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    private fun stopProjection() {
        if (stopping) return
        stopping = true
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null
        mediaProjection?.unregisterCallback(projectionCallback)
        mediaProjection?.stop()
        mediaProjection = null
        overlay?.hide()
        overlay = null
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopProjection()
            stopSelf()
        }
    }

    override fun onDestroy() {
        stopProjection()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
