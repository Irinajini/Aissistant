package com.boltfire.ai

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onAnalysisEnabledChanged(enabled: Boolean)
        fun onStopRequested()
    }

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: LinearLayout? = null
    private var statusText: TextView? = null
    private var adviceText: TextView? = null
    private var toggleButton: Button? = null
    private var params: WindowManager.LayoutParams? = null
    private var analysisEnabled = true

    fun show() {
        if (root != null) return

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.argb(235, 15, 18, 24))
        }

        val title = TextView(context).apply {
            text = "⚡ BOLTFIRE  ⋮⋮"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, 0, dp(2))
        }
        makeDraggable(title)

        statusText = TextView(context).apply {
            text = "● ANALYSE ACTIVE"
            setTextColor(Color.GREEN)
            textSize = 12f
        }

        adviceText = TextView(context).apply {
            text = "Capture connectée."
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(6))
        }

        val actions = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        toggleButton = Button(context).apply {
            text = "Pause"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                analysisEnabled = !analysisEnabled
                text = if (analysisEnabled) "Pause" else "Reprendre"
                listener.onAnalysisEnabledChanged(analysisEnabled)
            }
        }

        val hide = Button(context).apply {
            text = "Masquer"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { hide() }
        }

        val stop = Button(context).apply {
            text = "Arrêter"
            setTextSize(11f)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { listener.onStopRequested() }
        }

        actions.addView(toggleButton, weightParams())
        actions.addView(hide, weightParams())
        actions.addView(stop, weightParams())
        panel.addView(title)
        panel.addView(statusText)
        panel.addView(adviceText)
        panel.addView(actions)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            dp(280),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(70)
        }

        try {
            windowManager.addView(panel, params)
            root = panel
        } catch (t: Throwable) {
            t.printStackTrace()
            root = null
        }
    }

    private fun makeDraggable(handle: View) {
        handle.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = params ?: return false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = p.x
                        startY = p.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (downX - event.rawX).toInt()
                        p.y = startY + (event.rawY - downY).toInt()
                        root?.let { view -> runCatching { windowManager.updateViewLayout(view, p) } }
                        return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(40), 1f).apply {
        marginEnd = dp(3)
    }

    fun update(status: String, advice: String) {
        if (root == null) show()
        statusText?.text = status
        adviceText?.text = advice
    }

    fun showError(message: String) {
        if (root == null) show()
        statusText?.text = "● ERREUR"
        statusText?.setTextColor(Color.RED)
        adviceText?.text = message
    }

    fun hide() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        statusText = null
        adviceText = null
        toggleButton = null
    }

    fun isVisible(): Boolean = root != null

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
