package com.boltfire.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    companion object {
        private const val PROJECTION_REQUEST = 1001
        private const val NOTIFICATION_REQUEST = 1002
    }

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.statusText)

        findViewById<Button>(R.id.overlayButton).setOnClickListener {
            requestOverlayPermission()
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            startObservation()
        }

        requestNotificationPermissionIfNeeded()
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            status.text = "Overlay déjà autorisé."
            return
        }

        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
    }

    private fun startObservation() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Autorise d'abord l'overlay."
            requestOverlayPermission()
            return
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        status.text = "Demande d'autorisation de capture d'écran..."
        startActivityForResult(manager.createScreenCaptureIntent(), PROJECTION_REQUEST)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                NOTIFICATION_REQUEST
            )
        }
    }

    @Deprecated("Deprecated in Android SDK; retained for compatibility with this V1 flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != PROJECTION_REQUEST) return

        if (resultCode != RESULT_OK || data == null) {
            status.text = "Capture d'écran refusée."
            return
        }

        val serviceIntent = Intent(this, ScreenAnalysisService::class.java).apply {
            putExtra(ScreenAnalysisService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenAnalysisService.EXTRA_PROJECTION_DATA, data)
        }

        ContextCompat.startForegroundService(this, serviceIntent)
        status.text = "Observation écran démarrée."
    }
}
