package com.colorbolt.assistant

/**
 * Représentation indépendante du jeu.
 *
 * À compléter quand les règles exactes du plateau sont modélisées.
 */
data class Bolt(
    val id: Int,
    val color: Int,
    val x: Float,
    val y: Float,
    val accessible: Boolean
)

data class PuzzleState(
    val bolts: List<Bolt>,
    val width: Int,
    val height: Int
)
