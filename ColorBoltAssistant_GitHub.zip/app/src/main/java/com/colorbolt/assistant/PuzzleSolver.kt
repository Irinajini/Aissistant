package com.colorbolt.assistant

/**
 * Solveur indépendant de l'interface Android.
 *
 * Objectif :
 * trouver une séquence de mouvements légale et courte.
 *
 * IMPORTANT : ce module conseille le joueur ; il n'envoie aucun clic
 * à l'application de jeu.
 */
class PuzzleSolver {

    fun solve(initial: PuzzleState): List<Bolt> {
        // TODO V2 : BFS/A*/IDA* ou recherche spécialisée.
        return emptyList()
    }
}
