package com.colorbolt.assistant

/**
 * V1 : interface volontairement simple.
 *
 * Le prochain module transformera les pixels capturés en PuzzleState :
 * - localisation des boulons
 * - classification de couleur
 * - accessibilité
 * - zones/obstacles
 */
class BoardDetector {

    fun detect(bitmap: Any): PuzzleState? {
        // TODO: implémenter la vision du plateau.
        return null
    }
}
