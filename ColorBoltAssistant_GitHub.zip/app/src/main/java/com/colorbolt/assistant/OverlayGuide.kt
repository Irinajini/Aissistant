package com.colorbolt.assistant

/**
 * À utiliser pour dessiner une flèche, un cercle ou un repère
 * au-dessus du jeu après que le solveur a choisi le prochain mouvement.
 */
data class Guide(
    val targetX: Float,
    val targetY: Float,
    val label: String = "Joue ici"
)
